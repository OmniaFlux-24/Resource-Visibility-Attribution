# 0011 Rollback Review

## Reviewed sequence

```text
Stop Phase 13A writes
Disable resource mutation and event append routes
Drain in-flight requests
Export and hash idempotency_records
Confirm no consumer depends on revision ETags
Run 0011 down
Run 0010 down only if full Phase 13A removal is intended
Run Step 12 tenant and identity gates
Restore prior application artifact
Reopen traffic only after verification
```

## Findings

### Dependency order: PASS
`idempotency_records.resource_id` references `resources`, so the idempotency table must be dropped before resource ontology tables. The 0011 down migration does this before the optional 0010 down migration.

### Transactionality: PASS
Both down migrations use explicit transactions. A failure prevents partial migration commit.

### Data loss: HIGH RISK
Dropping `idempotency_records` destroys replay evidence and can permit a retried request to execute again after rollback. Dropping `revision` invalidates revision-based ETags and removes optimistic-concurrency state. Production rollback must therefore prefer application rollback with schema retention. Destructive SQL rollback requires an approved backup/export and an idempotency replay-risk decision.

### Client compatibility: HIGH RISK
Clients holding `"rN"` ETags cannot safely patch through an older created-at-based implementation. Mutation routes must remain disabled across mixed versions. There is no safe rolling downgrade without a compatibility adapter.

### Restore compatibility: CONDITIONAL PASS
A pre-0011 backup can restore the old schema. A post-0011 backup requires the 0011 schema or an explicit transformation. Restore tests must use the matching application artifact.

### RLS and privileges: PASS
Dropping the table removes its RLS policy and grants with it. After rollback, verify that no residual privileges, policy records or application references remain.

### Recommended production rollback
1. Disable writes using the feature flag.
2. Deploy the last compatible application while retaining 0011 schema.
3. Keep revision and idempotency data until the retry horizon expires.
4. Use destructive `0011 down` only for failed pre-production deployment or full backup restore.

## Post-rollback assertions

```sql
SELECT to_regclass('rva.idempotency_records') IS NULL;
SELECT NOT EXISTS (
  SELECT 1 FROM information_schema.columns
  WHERE table_schema='rva' AND table_name='resources' AND column_name='revision'
);
```

Then rerun Step 12 role, RLS, tenant-isolation, identity-isolation and backup/restore gates.
