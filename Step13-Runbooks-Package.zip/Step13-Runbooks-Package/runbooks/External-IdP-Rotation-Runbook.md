# External IdP Rotation Runbook

Phase 1 Old Key Validation
Phase 2 Overlap Validation (old + new)
Phase 3 Retirement Validation
Phase 4 Controlled JWKS Outage
Phase 5 Evidence Collection

Capture timestamps, KIDs, JWKS hashes and verifier outcomes.
Never store bearer tokens or private keys.
