# Step 8 Idempotency and Audit Model

> Production baseline. Acceptance requires executed evidence from the target environment.

## Lifecycle

RESERVED → COMPLETED or FAILED_RETRYABLE/FAILED_FINAL. Store tenant, route, method, key, request hash, response status/hash/reference, creation and expiry.

## Audit

Append-only tenant/principal/command/object/request/correlation/policy version and payload/result hashes. No secrets or unrestricted bodies.

## Outbox

Business result and event commit together. Leased worker, bounded retries, dead letter, authoritative external receipt.

## Retention

Expire replay payload after policy period while retaining required hashes/evidence. Cleanup is tenant-scoped and monitored.
