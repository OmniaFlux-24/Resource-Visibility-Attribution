# Phase 13A Authorization Boundary

## Invariants

1. The authentication middleware alone validates JWT/JWKS and resolves active tenant membership.
2. The client tenant header is only a selector. The resolved membership supplies authority.
3. Every handler requires a frozen `req.auth` containing tenant, principal, membership, permissions and ABAC attributes.
4. Every database operation executes inside one Step 12 transaction with transaction-local tenant and principal context.
5. RBAC grants a candidate permission; ABAC can still deny by domain, sensitivity, purpose, ownership or step-up.
6. RLS and composite tenant foreign keys remain mandatory defence in depth. Handlers never accept tenant IDs in path, query or body.
7. Authorization is evaluated before existence is disclosed. A caller receives the same not-found response for an absent or non-visible resource.
8. Append-only facets and events are never updated or deleted. Corrections and supersession create new events.
9. Authorization decisions and mutation audit entries are persisted in the same transaction as the protected mutation where available.
10. Tokens, private claims, SQL errors and cross-tenant identifiers are never returned or logged.

## Operation policy matrix

| Operation | Permission | ABAC context | Additional control |
|---|---|---|---|
| list/get resource | `resource:read` | resource domain/sensitivity when known | bounded page |
| create/patch resource | `resource:write` | requested domain/sensitivity | idempotency or strong `If-Match` |
| list facets/events/mappings | `resource:read` | history/export purpose | temporal bounds and page limits |
| append facet/event | `resource:write` | payload domain/sensitivity | append-only; idempotency for events |
| create source mapping | `connector:admin` | connector domain | connector ownership and uniqueness |

## Component ownership

- Authentication middleware: token and membership validity.
- Authorization service: RBAC plus ABAC decision and stable reason code.
- HTTP handler: input mapping, required preconditions, safe response shape.
- Repository: parameterized SQL only; no authorization policy decisions.
- Tenant transaction helper: database session context, commit, rollback and release.
- PostgreSQL: RLS, constraints, append-only triggers and referential integrity.
