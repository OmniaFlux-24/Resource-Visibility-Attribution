# Create Command Sequence

> Production baseline. Acceptance requires executed evidence from the target environment.

## Sequence

```mermaid
sequenceDiagram
 participant C as Client
 participant A as API
 participant V as Contract Validator
 participant Z as Authorization
 participant I as Idempotency
 participant H as Command Handler
 participant D as Database
 C->>A: POST JWT Idempotency-Key
 A->>V: validate request
 V-->>A: typed DTO
 A->>Z: scope domain sensitivity fields
 Z-->>A: allow
 A->>I: reserve key plus request hash
 alt matching completed request
  I-->>A: stored response
  A-->>C: exact replay
 else new
  A->>H: typed command
  H->>D: BEGIN plus tenant context
  H->>D: domain audit outbox idempotency
  D-->>H: COMMIT
  H-->>A: result DTO
  A->>V: validate response
  A-->>C: 201
 end
```

## Failure

Schema/auth failure before persistence; transaction rollback is atomic; same key/different hash conflicts; unknown external outcome is explicit.
