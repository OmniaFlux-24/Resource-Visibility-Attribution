CREATE TYPE public.ai_retention_mode AS ENUM ('STANDARD','MODIFIED_ABUSE_MONITORING','ZERO_DATA_RETENTION');
CREATE TYPE public.release_gate_state AS ENUM ('PENDING','PASSED','FAILED','WAIVED');

CREATE TABLE public.identity_provider_configs (
 tenant_id uuid NOT NULL, identity_provider_id uuid NOT NULL DEFAULT gen_random_uuid(), issuer text NOT NULL, audience text NOT NULL,
 allowed_jwks_origins jsonb NOT NULL, cache_ttl_seconds integer NOT NULL, refresh_cooldown_seconds integer NOT NULL,
 enabled boolean NOT NULL DEFAULT true, configuration_version integer NOT NULL, approved_by_actor_id uuid NOT NULL,
 valid_from timestamptz NOT NULL, valid_to timestamptz, recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 PRIMARY KEY(tenant_id,identity_provider_id), UNIQUE(tenant_id,issuer,configuration_version), FOREIGN KEY(tenant_id) REFERENCES public.tenants(tenant_id),
 FOREIGN KEY(tenant_id,approved_by_actor_id) REFERENCES public.actors(tenant_id,actor_id),
 CONSTRAINT idp_https_issuer CHECK(issuer ~ '^https://[^/]+/?$'), CONSTRAINT idp_cache_bounds CHECK(cache_ttl_seconds BETWEEN 30 AND 86400 AND refresh_cooldown_seconds BETWEEN 1 AND cache_ttl_seconds),
 CONSTRAINT idp_version_positive CHECK(configuration_version>0), CONSTRAINT idp_validity CHECK(valid_to IS NULL OR valid_to>valid_from)
);

CREATE TABLE public.quota_policies (
 tenant_id uuid NOT NULL, quota_policy_id uuid NOT NULL DEFAULT gen_random_uuid(), operation text NOT NULL, principal_type public.principal_type,
 window_seconds integer NOT NULL, unit_limit bigint NOT NULL, enabled boolean NOT NULL DEFAULT true, version integer NOT NULL,
 effective_from timestamptz NOT NULL, effective_to timestamptz, approved_by_actor_id uuid NOT NULL,
 PRIMARY KEY(tenant_id,quota_policy_id), UNIQUE(tenant_id,operation,principal_type,version), FOREIGN KEY(tenant_id) REFERENCES public.tenants(tenant_id),
 FOREIGN KEY(tenant_id,approved_by_actor_id) REFERENCES public.actors(tenant_id,actor_id),
 CONSTRAINT quota_positive CHECK(window_seconds>0 AND unit_limit>0 AND version>0), CONSTRAINT quota_validity CHECK(effective_to IS NULL OR effective_to>effective_from)
);
CREATE TABLE public.quota_counters (
 tenant_id uuid NOT NULL, principal_id uuid NOT NULL, operation text NOT NULL, window_start timestamptz NOT NULL,
 used_units bigint NOT NULL, updated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 PRIMARY KEY(tenant_id,principal_id,operation,window_start), FOREIGN KEY(tenant_id,principal_id) REFERENCES public.principals(tenant_id,principal_id),
 CONSTRAINT quota_units_nonnegative CHECK(used_units>=0)
);

CREATE TABLE public.access_policy_versions (
 tenant_id uuid NOT NULL, access_policy_id uuid NOT NULL DEFAULT gen_random_uuid(), policy_code text NOT NULL, version integer NOT NULL,
 permission text NOT NULL, allowed_domains public.resource_domain[], max_sensitivity integer, read_fields text[] NOT NULL, write_fields text[] NOT NULL,
 effective_from timestamptz NOT NULL, effective_to timestamptz, approved_by_actor_id uuid NOT NULL, policy_hash char(64) NOT NULL,
 PRIMARY KEY(tenant_id,access_policy_id), UNIQUE(tenant_id,policy_code,version), FOREIGN KEY(tenant_id) REFERENCES public.tenants(tenant_id),
 FOREIGN KEY(tenant_id,approved_by_actor_id) REFERENCES public.actors(tenant_id,actor_id),
 CONSTRAINT access_policy_version_positive CHECK(version>0), CONSTRAINT access_policy_hash CHECK(policy_hash ~ '^[0-9a-f]{64}$'),
 CONSTRAINT access_policy_validity CHECK(effective_to IS NULL OR effective_to>effective_from)
);

CREATE TABLE public.ai_governance_profiles (
 tenant_id uuid NOT NULL, ai_governance_profile_id uuid NOT NULL DEFAULT gen_random_uuid(), profile_code text NOT NULL, version integer NOT NULL,
 enabled boolean NOT NULL DEFAULT false, allowed_purposes text[] NOT NULL, allowed_models text[] NOT NULL, allowed_classifications text[] NOT NULL,
 allowed_regions text[] NOT NULL, retention_mode public.ai_retention_mode NOT NULL, requires_human_review boolean NOT NULL DEFAULT true,
 max_input_bytes integer NOT NULL, max_output_tokens integer NOT NULL, max_cost_units_per_window bigint NOT NULL, window_seconds integer NOT NULL,
 configuration_hash char(64) NOT NULL, privacy_approval_reference text, security_approval_reference text,
 effective_from timestamptz NOT NULL, effective_to timestamptz, approved_by_actor_id uuid NOT NULL, recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 PRIMARY KEY(tenant_id,ai_governance_profile_id), UNIQUE(tenant_id,profile_code,version), FOREIGN KEY(tenant_id) REFERENCES public.tenants(tenant_id),
 FOREIGN KEY(tenant_id,approved_by_actor_id) REFERENCES public.actors(tenant_id,actor_id),
 CONSTRAINT ai_profile_positive CHECK(version>0 AND max_input_bytes>0 AND max_output_tokens>0 AND max_cost_units_per_window>0 AND window_seconds>0),
 CONSTRAINT ai_profile_hash CHECK(configuration_hash ~ '^[0-9a-f]{64}$'), CONSTRAINT ai_profile_validity CHECK(effective_to IS NULL OR effective_to>effective_from),
 CONSTRAINT ai_profile_approval CHECK(NOT enabled OR (privacy_approval_reference IS NOT NULL AND security_approval_reference IS NOT NULL)),
 CONSTRAINT ai_profile_human_review CHECK(requires_human_review)
);
CREATE TABLE public.ai_evaluation_runs (
 tenant_id uuid NOT NULL, ai_evaluation_run_id uuid NOT NULL DEFAULT gen_random_uuid(), ai_governance_profile_id uuid NOT NULL,
 dataset_hash char(64) NOT NULL, evaluator_version text NOT NULL, metrics jsonb NOT NULL, thresholds jsonb NOT NULL, passed boolean NOT NULL,
 executed_at timestamptz NOT NULL DEFAULT clock_timestamp(), executed_by_actor_id uuid NOT NULL,
 PRIMARY KEY(tenant_id,ai_evaluation_run_id), FOREIGN KEY(tenant_id,ai_governance_profile_id) REFERENCES public.ai_governance_profiles(tenant_id,ai_governance_profile_id),
 FOREIGN KEY(tenant_id,executed_by_actor_id) REFERENCES public.actors(tenant_id,actor_id), CONSTRAINT ai_eval_dataset_hash CHECK(dataset_hash ~ '^[0-9a-f]{64}$')
);

CREATE TABLE public.release_gate_evidence (
 release_gate_evidence_id uuid PRIMARY KEY DEFAULT gen_random_uuid(), release_version text NOT NULL, gate_code text NOT NULL,
 state public.release_gate_state NOT NULL, artifact_hash char(64), evidence_reference text, recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 recorded_by text NOT NULL, UNIQUE(release_version,gate_code), CONSTRAINT release_evidence_hash CHECK(artifact_hash IS NULL OR artifact_hash ~ '^[0-9a-f]{64}$'),
 CONSTRAINT release_passed_evidence CHECK(state<>'PASSED' OR (artifact_hash IS NOT NULL AND evidence_reference IS NOT NULL)),
 CONSTRAINT release_waiver_reference CHECK(state<>'WAIVED' OR evidence_reference IS NOT NULL)
);

CREATE FUNCTION public.prevent_governance_mutation() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'Governance records are immutable; create a new version'; END; $$;
CREATE TRIGGER idp_configs_immutable BEFORE UPDATE OR DELETE ON public.identity_provider_configs FOR EACH ROW EXECUTE FUNCTION public.prevent_governance_mutation();
CREATE TRIGGER quota_policies_immutable BEFORE UPDATE OR DELETE ON public.quota_policies FOR EACH ROW EXECUTE FUNCTION public.prevent_governance_mutation();
CREATE TRIGGER access_policies_immutable BEFORE UPDATE OR DELETE ON public.access_policy_versions FOR EACH ROW EXECUTE FUNCTION public.prevent_governance_mutation();
CREATE TRIGGER ai_profiles_immutable BEFORE UPDATE OR DELETE ON public.ai_governance_profiles FOR EACH ROW EXECUTE FUNCTION public.prevent_governance_mutation();
CREATE TRIGGER ai_evaluations_immutable BEFORE UPDATE OR DELETE ON public.ai_evaluation_runs FOR EACH ROW EXECUTE FUNCTION public.prevent_governance_mutation();

ALTER TABLE public.identity_provider_configs ENABLE ROW LEVEL SECURITY; ALTER TABLE public.identity_provider_configs FORCE ROW LEVEL SECURITY;
ALTER TABLE public.quota_policies ENABLE ROW LEVEL SECURITY; ALTER TABLE public.quota_policies FORCE ROW LEVEL SECURITY;
ALTER TABLE public.quota_counters ENABLE ROW LEVEL SECURITY; ALTER TABLE public.quota_counters FORCE ROW LEVEL SECURITY;
ALTER TABLE public.access_policy_versions ENABLE ROW LEVEL SECURITY; ALTER TABLE public.access_policy_versions FORCE ROW LEVEL SECURITY;
ALTER TABLE public.ai_governance_profiles ENABLE ROW LEVEL SECURITY; ALTER TABLE public.ai_governance_profiles FORCE ROW LEVEL SECURITY;
ALTER TABLE public.ai_evaluation_runs ENABLE ROW LEVEL SECURITY; ALTER TABLE public.ai_evaluation_runs FORCE ROW LEVEL SECURITY;
CREATE POLICY idp_configs_tenant ON public.identity_provider_configs USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY quota_policies_tenant ON public.quota_policies USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY quota_counters_tenant ON public.quota_counters USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY access_policies_tenant ON public.access_policy_versions USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY ai_profiles_tenant ON public.ai_governance_profiles USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY ai_evaluations_tenant ON public.ai_evaluation_runs USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE INDEX quota_policy_lookup_idx ON public.quota_policies(tenant_id,operation,effective_from);
CREATE INDEX ai_profile_lookup_idx ON public.ai_governance_profiles(tenant_id,enabled,effective_from);
CREATE INDEX ai_evaluation_profile_idx ON public.ai_evaluation_runs(tenant_id,ai_governance_profile_id,executed_at DESC);
