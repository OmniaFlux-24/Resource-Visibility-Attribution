# Development status

## Source-complete stages

- Step 0: repository foundation, HTTP health host, migration harness and CI skeleton.
- Step 1: canonical resource, evidence, bitemporal facts, units, measurements, ontology governance, actors, relationships and immutable evidence.
- Step 2: versioned baselines/rules, immutable evaluations, findings, evidence lineage and guarded workflow history.
- Step 3: cases, exact-payload approvals, emergency stops, controlled actions, durable outbox/attempts/receipts, reconciliation states and append-only ValueEvents with serialized partial allocations.

## Production-readiness status

Release blocked. Static source and archive checks pass, but production readiness requires executable evidence from PostgreSQL 17 and the Node toolchain.

### Passed in this environment

- Package manifest parsing
- Six paired forward/rollback migrations
- Placeholder and unimplemented-branch scan
- Static tenant RLS coverage
- Static composite-key and rollback coverage
- Static approval binding, independent approval, emergency stop and action-state controls
- Static idempotency, outbox, retries, unknown outcome and authoritative receipt controls
- Static immutable ValueEvent and allocation serialization controls
- ZIP integrity and exclusion of node_modules/build output

### Not run and therefore not passed

- npm dependency installation, lint, formatting check, strict TypeScript compile, Vitest and build, because package-registry access timed out
- PostgreSQL 17 migration execution, upgrade, rollback/reapply, restricted-role RLS, concurrency and failure-injection tests, because PostgreSQL/Docker is unavailable
- deployment restore drill, load test, SAST/DAST, SBOM signing and independent penetration testing

No production-ready claim is made until all release blockers pass.
