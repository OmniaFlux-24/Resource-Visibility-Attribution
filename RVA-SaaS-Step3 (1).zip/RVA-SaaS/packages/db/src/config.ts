import path from 'node:path';
import { fileURLToPath } from 'node:url';
export const packageRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const defaultMigrationsDir = path.join(packageRoot, 'migrations');
export function resolveDatabaseUrl(env: NodeJS.ProcessEnv = process.env): string {
  const value = env['RVA_DATABASE_URL'] ?? env['DATABASE_URL'];
  if (value === undefined || value.trim() === '') throw new Error('Set RVA_DATABASE_URL or DATABASE_URL.');
  return value;
}
