# AI governance acceptance criteria

AI use is accepted only when all criteria below pass.

## Tenant and purpose governance

- AI is disabled by default per tenant.
- Every invocation matches an active, effective-dated governance profile.
- Purpose, model, data classification and processing region are allowlisted.
- High-impact purposes cannot be configured to bypass human review.

## Data and privacy

- Input minimization and approved redaction run before provider transmission.
- Provider retention mode is explicitly recorded as STANDARD, MODIFIED_ABUSE_MONITORING or ZERO_DATA_RETENTION.
- `store: false` is always sent, but is not treated as proof of Zero Data Retention.
- Legal/privacy approval evidence is recorded for restricted or personal data.
- Raw prompts and responses are not written to ordinary application logs.

## Safety and security

- Untrusted evidence is delimited and cannot supply system instructions, tools, URLs or credentials.
- Provider origin is HTTPS and allowlisted; egress is restricted independently of application checks.
- Input bytes, output tokens, requests, cost units and concurrency are bounded per tenant and principal.
- Structured output is validated against the approved runtime schema.
- Refusals, timeouts, malformed output and moderation failures fail closed.

## Quality and change control

- Model, prompt/configuration, schema, evaluator and test-dataset versions are immutable and hashed.
- Offline evaluation passes approved thresholds for schema validity, groundedness, false-positive/negative tolerances, injection resistance and refusal behavior.
- Model or prompt changes require regression comparison and explicit approval before promotion.
- Production quality and safety metrics support rollback to the last approved profile.

## Human review and audit

- Every proposal requiring review records reviewer, decision, reason and evidence.
- AI never creates authoritative facts, findings, approvals, actions or ValueEvents directly.
- Invocation metadata, policy decision, hashes, provider response ID, usage and review are tenant scoped and auditable.
