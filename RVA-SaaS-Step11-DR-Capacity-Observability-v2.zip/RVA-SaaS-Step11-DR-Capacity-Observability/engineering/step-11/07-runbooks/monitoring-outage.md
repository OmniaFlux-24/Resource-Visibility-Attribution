# Monitoring Outage Runbook

> Production engineering baseline. Runtime certification requires executed evidence from the target environment.

## Detect

Independent black-box check or missing-scrape/rule-evaluation alert.

## Contain

Declare degraded observability, freeze risky releases, use platform-native logs/health checks and increase manual checks.

## Recover

Restore Prometheus/Grafana/Alertmanager dependencies, validate targets/rules/dashboards/routes, send test notification and record evidence.

## Rollback

Revert last monitoring configuration if validation fails. Do not disable application security controls to recover monitoring.
