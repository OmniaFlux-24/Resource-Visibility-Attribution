#!/usr/bin/env bash
set -euo pipefail
root="${1:-$(cd "$(dirname "$0")/.." && pwd)}"
command -v promtool >/dev/null || { echo 'promtool is required' >&2; exit 127; }
promtool check config --lint=all --lint-fatal "$root/prometheus/prometheus.yml"
promtool check rules --lint=all --lint-fatal "$root/prometheus/rules/"*.yml
(cd "$root/prometheus/tests" && promtool test rules rules.test.yml)
