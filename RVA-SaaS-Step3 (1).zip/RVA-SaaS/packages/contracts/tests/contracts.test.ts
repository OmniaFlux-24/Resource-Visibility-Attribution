import { describe,expect,it } from 'vitest';
import { isResourceDomain, resourceDomains } from '../src/index.js';
describe('RVA ontology contracts',()=>{
 it('contains all eight governed domains',()=>{expect(resourceDomains).toHaveLength(8);});
 it('rejects ungoverned domain labels',()=>{expect(isResourceDomain('FINANCIAL')).toBe(true); expect(isResourceDomain('OTHER')).toBe(false);});
});
