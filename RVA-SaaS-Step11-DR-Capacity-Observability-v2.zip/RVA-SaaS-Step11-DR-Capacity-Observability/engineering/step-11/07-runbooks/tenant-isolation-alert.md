# Tenant Isolation Alert Runbook

> Production engineering baseline. Runtime certification requires executed evidence from the target environment.

## Severity

SEV1 and non-waivable release blocker.

## Contain

Stop affected writes and controlled actions, preserve evidence, identify release/route/principal, restrict traffic, engage incident commander and security lead.

## Investigate

Confirm metric source; inspect RLS/app role/config changes; avoid querying unrelated tenant data; determine affected objects and exposure window.

## Recover

Deploy last attested artifact or policy, verify application role `NOSUPERUSER NOBYPASSRLS`, run adversarial isolation suite and reconcile audit logs before reopening.

## Close

Incident report, tenant/legal notification decision, corrective controls and regression test.
