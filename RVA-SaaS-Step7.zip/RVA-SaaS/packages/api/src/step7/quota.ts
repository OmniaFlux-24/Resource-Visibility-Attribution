export interface QuotaRequest{tenantId:string;principalId:string;operation:string;units:number;limit:number;windowStart:string;}
export interface QuotaResult{allowed:boolean;used:number;remaining:number;}
export interface QuotaStore{consume(request:QuotaRequest):Promise<QuotaResult>;}
export class QuotaGuard{constructor(private readonly store:QuotaStore){}async require(request:QuotaRequest):Promise<QuotaResult>{if(!Number.isSafeInteger(request.units)||request.units<=0||!Number.isSafeInteger(request.limit)||request.limit<=0)throw new Error('Invalid quota request');const r=await this.store.consume(request);if(!r.allowed)throw new Error('Rate limit exceeded');return r;}}
