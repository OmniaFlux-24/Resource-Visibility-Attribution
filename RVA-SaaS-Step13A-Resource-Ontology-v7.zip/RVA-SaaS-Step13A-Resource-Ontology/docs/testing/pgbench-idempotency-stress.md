# pgbench Idempotency Stress Gate

This is a bounded CI stress check, not a capacity benchmark or production SLO claim.

## Workloads

1. Same-key contention: all clients repeatedly attempt the same tenant/key reservation. Acceptance requires exactly one persisted key row and zero failed pgbench transactions.
2. Distributed keys: clients generate bounded random keys and reserve them using prepared mode. Acceptance requires at least one persisted row and zero failed pgbench transactions.

Defaults are 16 clients, 4 threads and 50 transactions per client. CI may override these through positive-integer environment variables. Logs and assertions are retained under `evidence/pgbench/`.

The gate does not measure HTTP handler throughput, idempotency response replay latency or production durability configuration. Those require a separate representative performance environment.
