export type ConnectorMode='READ_ONLY'|'CONTROLLED_WRITE';
export interface ConnectorCommand{readonly operation:string;readonly target:string;readonly payload:unknown;readonly approvalId?:string;readonly dryRun:boolean;}
export interface ConnectorPolicy{readonly mode:ConnectorMode;readonly allowedOperations:readonly string[];}
export function authorizeConnectorCommand(policy:ConnectorPolicy,command:ConnectorCommand):void{
 if(command.dryRun) return;
 if(policy.mode!=='CONTROLLED_WRITE') throw new Error('Connector is read-only');
 if(!policy.allowedOperations.includes(command.operation)) throw new Error('Connector operation is not allowlisted');
 if(command.approvalId===undefined) throw new Error('Controlled write requires approval');
}
