# Phase 13A Threat Model

Threats include cross-tenant references, omitted tenant filters, facet-schema confusion, backdated overwrite, correction-chain cycles, canonical-ID collision, source mapping takeover, unbounded JSON payloads and malicious provenance values. Controls include composite keys and foreign keys, forced RLS, append-only triggers, typed facet families and schema versions, timestamp range checks, hash constraints, source identifier limits, restrictive role grants and adversarial tests.
