# SLO and Error Budget Standard

> Production engineering baseline. Runtime certification requires executed evidence from the target environment.

## Indicators

Availability uses successful eligible API requests. Latency uses server-side histograms. Correctness includes zero tenant-isolation violations and zero duplicate controlled actions. Do not count expected client validation errors as service failures.

## Objectives

Values in configuration are proposed defaults only. Business and service owners approve production objectives and exclusions.

## Burn rates

Use fast and slow windows to detect rapid and sustained budget consumption. Page only actionable conditions; ticket lower urgency trends.

## Cardinality

Labels are bounded to service, route template, method, status class, operation and deployment environment. Never use tenant ID, user ID, request ID or raw URI as metric labels.

## Review

Monthly SLO review and post-incident reassessment. Changes require traceability and dashboard/alert/test updates.
