CREATE TYPE public.case_state AS ENUM ('OPEN','INVESTIGATING','APPROVAL_PENDING','ACTION_IN_PROGRESS','OUTCOME_PENDING','RESOLVED','CANCELLED','REOPENED','CLOSED');
CREATE TYPE public.approval_decision AS ENUM ('APPROVED','REJECTED','CANCELLED','EXPIRED');
CREATE TYPE public.action_state AS ENUM ('DRAFT','READY','LEASED','EXECUTING','OUTCOME_UNKNOWN','SUCCEEDED','FAILED','CANCELLED','RECONCILED');
CREATE TYPE public.value_event_kind AS ENUM ('CREDIT','COLLECTION','CORRECTED_CHARGE','AVOIDED_EXPENDITURE','NON_FINANCIAL_GAIN','ADJUSTMENT','REVERSAL');
CREATE TYPE public.value_classification AS ENUM ('RECOVERED_CASH','REALIZED_BENEFIT','PREVENTED_LOSS','NON_FINANCIAL');

CREATE TABLE public.cases (
 tenant_id uuid NOT NULL, case_id uuid NOT NULL DEFAULT gen_random_uuid(), case_number bigint GENERATED ALWAYS AS IDENTITY,
 title text NOT NULL, description text NOT NULL, state public.case_state NOT NULL DEFAULT 'OPEN', owner_actor_id uuid NOT NULL,
 created_by_actor_id uuid NOT NULL, created_at timestamptz NOT NULL DEFAULT clock_timestamp(), updated_at timestamptz NOT NULL DEFAULT clock_timestamp(), closed_at timestamptz,
 PRIMARY KEY(tenant_id,case_id), UNIQUE(tenant_id,case_number), FOREIGN KEY(tenant_id) REFERENCES public.tenants(tenant_id),
 FOREIGN KEY(tenant_id,owner_actor_id) REFERENCES public.actors(tenant_id,actor_id), FOREIGN KEY(tenant_id,created_by_actor_id) REFERENCES public.actors(tenant_id,actor_id),
 CONSTRAINT case_title_not_blank CHECK(length(btrim(title))>0), CONSTRAINT case_closed_consistency CHECK((state='CLOSED' AND closed_at IS NOT NULL) OR state<>'CLOSED')
);
CREATE TABLE public.case_findings (
 tenant_id uuid NOT NULL, case_id uuid NOT NULL, finding_id uuid NOT NULL, linked_by_actor_id uuid NOT NULL, linked_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 PRIMARY KEY(tenant_id,case_id,finding_id), FOREIGN KEY(tenant_id,case_id) REFERENCES public.cases(tenant_id,case_id),
 FOREIGN KEY(tenant_id,finding_id) REFERENCES public.findings(tenant_id,finding_id), FOREIGN KEY(tenant_id,linked_by_actor_id) REFERENCES public.actors(tenant_id,actor_id)
);
CREATE TABLE public.emergency_stops (
 tenant_id uuid NOT NULL, emergency_stop_id uuid NOT NULL DEFAULT gen_random_uuid(), domain public.resource_domain, connector_code text,
 reason text NOT NULL, enabled boolean NOT NULL DEFAULT true, enabled_by_actor_id uuid NOT NULL, enabled_at timestamptz NOT NULL DEFAULT clock_timestamp(), disabled_by_actor_id uuid, disabled_at timestamptz,
 PRIMARY KEY(tenant_id,emergency_stop_id), FOREIGN KEY(tenant_id) REFERENCES public.tenants(tenant_id),
 FOREIGN KEY(tenant_id,enabled_by_actor_id) REFERENCES public.actors(tenant_id,actor_id), FOREIGN KEY(tenant_id,disabled_by_actor_id) REFERENCES public.actors(tenant_id,actor_id),
 CONSTRAINT emergency_stop_disable_consistency CHECK((enabled AND disabled_at IS NULL AND disabled_by_actor_id IS NULL) OR (NOT enabled AND disabled_at IS NOT NULL AND disabled_by_actor_id IS NOT NULL))
);
CREATE UNIQUE INDEX emergency_stops_active_scope_idx ON public.emergency_stops(tenant_id,domain,connector_code) NULLS NOT DISTINCT WHERE enabled;

CREATE TABLE public.approval_grants (
 tenant_id uuid NOT NULL, approval_id uuid NOT NULL DEFAULT gen_random_uuid(), case_id uuid NOT NULL, decision public.approval_decision NOT NULL,
 target_reference text NOT NULL, operation text NOT NULL, payload_hash char(64) NOT NULL, maximum_impact numeric(38,18), impact_unit_code text REFERENCES public.units(unit_code),
 policy_version text NOT NULL, approved_by_actor_id uuid NOT NULL, decided_at timestamptz NOT NULL DEFAULT clock_timestamp(), expires_at timestamptz NOT NULL,
 independence_key text NOT NULL, requires_independent_approval boolean NOT NULL DEFAULT true, reason text NOT NULL,
 PRIMARY KEY(tenant_id,approval_id), FOREIGN KEY(tenant_id,case_id) REFERENCES public.cases(tenant_id,case_id), FOREIGN KEY(tenant_id,approved_by_actor_id) REFERENCES public.actors(tenant_id,actor_id),
 CONSTRAINT approval_payload_hash CHECK(payload_hash ~ '^[0-9a-f]{64}$'), CONSTRAINT approval_expiry_after_decision CHECK(expires_at>decided_at),
 CONSTRAINT approval_impact_pair CHECK((maximum_impact IS NULL AND impact_unit_code IS NULL) OR (maximum_impact IS NOT NULL AND impact_unit_code IS NOT NULL))
);

CREATE TABLE public.actions (
 tenant_id uuid NOT NULL, action_id uuid NOT NULL DEFAULT gen_random_uuid(), case_id uuid NOT NULL, approval_id uuid,
 domain public.resource_domain NOT NULL, connector_code text NOT NULL, target_reference text NOT NULL, operation text NOT NULL, exact_payload jsonb NOT NULL, payload_hash char(64) NOT NULL,
 idempotency_key text NOT NULL, requested_impact numeric(38,18), impact_unit_code text REFERENCES public.units(unit_code), state public.action_state NOT NULL DEFAULT 'DRAFT',
 dry_run boolean NOT NULL DEFAULT true, precondition_snapshot jsonb NOT NULL, requested_by_actor_id uuid NOT NULL, created_at timestamptz NOT NULL DEFAULT clock_timestamp(), expires_at timestamptz NOT NULL,
 PRIMARY KEY(tenant_id,action_id), UNIQUE(tenant_id,connector_code,idempotency_key), FOREIGN KEY(tenant_id,case_id) REFERENCES public.cases(tenant_id,case_id),
 FOREIGN KEY(tenant_id,approval_id) REFERENCES public.approval_grants(tenant_id,approval_id), FOREIGN KEY(tenant_id,requested_by_actor_id) REFERENCES public.actors(tenant_id,actor_id),
 CONSTRAINT action_payload_hash CHECK(payload_hash ~ '^[0-9a-f]{64}$'), CONSTRAINT action_expiry_future CHECK(expires_at>created_at),
 CONSTRAINT action_impact_pair CHECK((requested_impact IS NULL AND impact_unit_code IS NULL) OR (requested_impact IS NOT NULL AND impact_unit_code IS NOT NULL))
);

CREATE FUNCTION public.guard_action_ready() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE approval public.approval_grants; stopped boolean;
BEGIN
 IF NEW.state='READY' AND OLD.state<>'READY' THEN
  IF NEW.dry_run THEN RAISE EXCEPTION 'Dry-run action cannot become READY'; END IF;
  SELECT * INTO approval FROM public.approval_grants a WHERE a.tenant_id=NEW.tenant_id AND a.approval_id=NEW.approval_id;
  IF NOT FOUND OR approval.decision<>'APPROVED' OR approval.expires_at<=clock_timestamp() THEN RAISE EXCEPTION 'Valid unexpired approval required'; END IF;
  IF approval.requires_independent_approval AND approval.approved_by_actor_id=NEW.requested_by_actor_id THEN RAISE EXCEPTION 'Independent approval required'; END IF;
  IF approval.target_reference<>NEW.target_reference OR approval.operation<>NEW.operation OR approval.payload_hash<>NEW.payload_hash THEN RAISE EXCEPTION 'Approval does not bind exact action'; END IF;
  IF approval.maximum_impact IS NOT NULL AND (NEW.requested_impact IS NULL OR NEW.requested_impact>approval.maximum_impact OR NEW.impact_unit_code<>approval.impact_unit_code) THEN RAISE EXCEPTION 'Action exceeds approved impact'; END IF;
  SELECT EXISTS(SELECT 1 FROM public.emergency_stops s WHERE s.tenant_id=NEW.tenant_id AND s.enabled AND (s.domain IS NULL OR s.domain=NEW.domain) AND (s.connector_code IS NULL OR s.connector_code=NEW.connector_code)) INTO stopped;
  IF stopped THEN RAISE EXCEPTION 'Execution blocked by emergency stop'; END IF;
 END IF;
 RETURN NEW;
END; $$;
CREATE TRIGGER actions_guard_ready BEFORE UPDATE OF state ON public.actions FOR EACH ROW EXECUTE FUNCTION public.guard_action_ready();

CREATE TABLE public.allowed_action_transitions (
 from_state public.action_state NOT NULL, to_state public.action_state NOT NULL, PRIMARY KEY(from_state,to_state)
);
INSERT INTO public.allowed_action_transitions(from_state,to_state) VALUES
('DRAFT','READY'),('DRAFT','CANCELLED'),('READY','LEASED'),('READY','CANCELLED'),('LEASED','EXECUTING'),
('LEASED','READY'),('EXECUTING','SUCCEEDED'),('EXECUTING','FAILED'),('EXECUTING','OUTCOME_UNKNOWN'),
('OUTCOME_UNKNOWN','RECONCILED'),('OUTCOME_UNKNOWN','FAILED'),('SUCCEEDED','RECONCILED');
CREATE FUNCTION public.guard_action_transition() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
 IF NEW.state=OLD.state THEN RETURN NEW; END IF;
 IF NOT EXISTS(SELECT 1 FROM public.allowed_action_transitions t WHERE t.from_state=OLD.state AND t.to_state=NEW.state)
 THEN RAISE EXCEPTION 'Invalid action transition: % -> %',OLD.state,NEW.state; END IF;
 RETURN NEW;
END; $$;
CREATE TRIGGER actions_guard_transition BEFORE UPDATE OF state ON public.actions FOR EACH ROW EXECUTE FUNCTION public.guard_action_transition();

CREATE TABLE public.action_outbox (
 tenant_id uuid NOT NULL, outbox_id uuid NOT NULL DEFAULT gen_random_uuid(), action_id uuid NOT NULL, available_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 lease_owner text, leased_until timestamptz, attempt_count integer NOT NULL DEFAULT 0, max_attempts integer NOT NULL DEFAULT 8, dead_lettered_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT clock_timestamp(), PRIMARY KEY(tenant_id,outbox_id), UNIQUE(tenant_id,action_id),
 FOREIGN KEY(tenant_id,action_id) REFERENCES public.actions(tenant_id,action_id), CONSTRAINT outbox_attempts_valid CHECK(attempt_count>=0 AND max_attempts>0 AND attempt_count<=max_attempts),
 CONSTRAINT outbox_lease_pair CHECK((lease_owner IS NULL AND leased_until IS NULL) OR (lease_owner IS NOT NULL AND leased_until IS NOT NULL))
);
CREATE TABLE public.action_attempts (
 tenant_id uuid NOT NULL, attempt_id uuid NOT NULL DEFAULT gen_random_uuid(), action_id uuid NOT NULL, attempt_number integer NOT NULL,
 request_hash char(64) NOT NULL, started_at timestamptz NOT NULL DEFAULT clock_timestamp(), completed_at timestamptz, transport_status text NOT NULL,
 external_correlation_id text, response_metadata jsonb NOT NULL DEFAULT '{}'::jsonb, error_code text,
 PRIMARY KEY(tenant_id,attempt_id), UNIQUE(tenant_id,action_id,attempt_number), FOREIGN KEY(tenant_id,action_id) REFERENCES public.actions(tenant_id,action_id),
 CONSTRAINT attempt_number_positive CHECK(attempt_number>0), CONSTRAINT attempt_hash_format CHECK(request_hash ~ '^[0-9a-f]{64}$')
);
CREATE TABLE public.action_receipts (
 tenant_id uuid NOT NULL, receipt_id uuid NOT NULL DEFAULT gen_random_uuid(), action_id uuid NOT NULL, authoritative_source text NOT NULL,
 external_reference text NOT NULL, outcome text NOT NULL, evidence_id uuid NOT NULL, observed_at timestamptz NOT NULL, recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(), verified_by_actor_id uuid NOT NULL,
 PRIMARY KEY(tenant_id,receipt_id), UNIQUE(tenant_id,authoritative_source,external_reference), FOREIGN KEY(tenant_id,action_id) REFERENCES public.actions(tenant_id,action_id),
 FOREIGN KEY(tenant_id,evidence_id) REFERENCES public.evidence_objects(tenant_id,evidence_id), FOREIGN KEY(tenant_id,verified_by_actor_id) REFERENCES public.actors(tenant_id,actor_id)
);

CREATE TABLE public.value_events (
 tenant_id uuid NOT NULL, value_event_id uuid NOT NULL DEFAULT gen_random_uuid(), economic_event_key text NOT NULL, kind public.value_event_kind NOT NULL,
 classification public.value_classification NOT NULL, resource_id uuid NOT NULL, amount numeric(38,18) NOT NULL, unit_code text NOT NULL REFERENCES public.units(unit_code),
 effective_at timestamptz NOT NULL, recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(), evidence_id uuid NOT NULL, verified_by_actor_id uuid NOT NULL,
 supersedes_value_event_id uuid, counterfactual_basis jsonb, source_reference text NOT NULL,
 PRIMARY KEY(tenant_id,value_event_id), UNIQUE(tenant_id,economic_event_key), FOREIGN KEY(tenant_id,resource_id) REFERENCES public.resources(tenant_id,resource_id),
 FOREIGN KEY(tenant_id,evidence_id) REFERENCES public.evidence_objects(tenant_id,evidence_id), FOREIGN KEY(tenant_id,verified_by_actor_id) REFERENCES public.actors(tenant_id,actor_id),
 FOREIGN KEY(tenant_id,supersedes_value_event_id) REFERENCES public.value_events(tenant_id,value_event_id),
 CONSTRAINT value_amount_nonzero CHECK(amount<>0), CONSTRAINT prevented_requires_basis CHECK(classification<>'PREVENTED_LOSS' OR counterfactual_basis IS NOT NULL)
);
CREATE TABLE public.value_event_allocations (
 tenant_id uuid NOT NULL, allocation_id uuid NOT NULL DEFAULT gen_random_uuid(), value_event_id uuid NOT NULL, finding_id uuid NOT NULL,
 allocated_amount numeric(38,18) NOT NULL, rationale text NOT NULL, allocated_by_actor_id uuid NOT NULL, recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 PRIMARY KEY(tenant_id,allocation_id), UNIQUE(tenant_id,value_event_id,finding_id), FOREIGN KEY(tenant_id,value_event_id) REFERENCES public.value_events(tenant_id,value_event_id),
 FOREIGN KEY(tenant_id,finding_id) REFERENCES public.findings(tenant_id,finding_id), FOREIGN KEY(tenant_id,allocated_by_actor_id) REFERENCES public.actors(tenant_id,actor_id),
 CONSTRAINT allocation_nonzero CHECK(allocated_amount<>0)
);
CREATE FUNCTION public.guard_value_allocation() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE total numeric(38,18); event_amount numeric(38,18);
BEGIN
 PERFORM pg_advisory_xact_lock(hashtextextended(NEW.tenant_id::text || ':' || NEW.value_event_id::text,0));
 SELECT amount INTO event_amount FROM public.value_events WHERE tenant_id=NEW.tenant_id AND value_event_id=NEW.value_event_id;
 SELECT coalesce(sum(abs(allocated_amount)),0) INTO total FROM public.value_event_allocations WHERE tenant_id=NEW.tenant_id AND value_event_id=NEW.value_event_id AND allocation_id<>NEW.allocation_id;
 IF total+abs(NEW.allocated_amount)>abs(event_amount) THEN RAISE EXCEPTION 'Allocations exceed ValueEvent amount'; END IF;
 RETURN NEW;
END; $$;
CREATE TRIGGER allocations_guard_total BEFORE INSERT OR UPDATE ON public.value_event_allocations FOR EACH ROW EXECUTE FUNCTION public.guard_value_allocation();
CREATE FUNCTION public.prevent_resolution_ledger_mutation() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'Ledger record is immutable; append adjustment or reversal'; END; $$;
CREATE TRIGGER value_events_immutable BEFORE UPDATE OR DELETE ON public.value_events FOR EACH ROW EXECUTE FUNCTION public.prevent_resolution_ledger_mutation();
CREATE TRIGGER allocations_immutable BEFORE UPDATE OR DELETE ON public.value_event_allocations FOR EACH ROW EXECUTE FUNCTION public.prevent_resolution_ledger_mutation();
CREATE TRIGGER receipts_immutable BEFORE UPDATE OR DELETE ON public.action_receipts FOR EACH ROW EXECUTE FUNCTION public.prevent_resolution_ledger_mutation();
CREATE TRIGGER approvals_immutable BEFORE UPDATE OR DELETE ON public.approval_grants FOR EACH ROW EXECUTE FUNCTION public.prevent_resolution_ledger_mutation();

ALTER TABLE public.cases ENABLE ROW LEVEL SECURITY; ALTER TABLE public.cases FORCE ROW LEVEL SECURITY;
ALTER TABLE public.case_findings ENABLE ROW LEVEL SECURITY; ALTER TABLE public.case_findings FORCE ROW LEVEL SECURITY;
ALTER TABLE public.emergency_stops ENABLE ROW LEVEL SECURITY; ALTER TABLE public.emergency_stops FORCE ROW LEVEL SECURITY;
ALTER TABLE public.approval_grants ENABLE ROW LEVEL SECURITY; ALTER TABLE public.approval_grants FORCE ROW LEVEL SECURITY;
ALTER TABLE public.actions ENABLE ROW LEVEL SECURITY; ALTER TABLE public.actions FORCE ROW LEVEL SECURITY;
ALTER TABLE public.action_outbox ENABLE ROW LEVEL SECURITY; ALTER TABLE public.action_outbox FORCE ROW LEVEL SECURITY;
ALTER TABLE public.action_attempts ENABLE ROW LEVEL SECURITY; ALTER TABLE public.action_attempts FORCE ROW LEVEL SECURITY;
ALTER TABLE public.action_receipts ENABLE ROW LEVEL SECURITY; ALTER TABLE public.action_receipts FORCE ROW LEVEL SECURITY;
ALTER TABLE public.value_events ENABLE ROW LEVEL SECURITY; ALTER TABLE public.value_events FORCE ROW LEVEL SECURITY;
ALTER TABLE public.value_event_allocations ENABLE ROW LEVEL SECURITY; ALTER TABLE public.value_event_allocations FORCE ROW LEVEL SECURITY;
CREATE POLICY cases_tenant ON public.cases USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY case_findings_tenant ON public.case_findings USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY emergency_stops_tenant ON public.emergency_stops USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY approval_grants_tenant ON public.approval_grants USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY actions_tenant ON public.actions USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY action_outbox_tenant ON public.action_outbox USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY action_attempts_tenant ON public.action_attempts USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY action_receipts_tenant ON public.action_receipts USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY value_events_tenant ON public.value_events USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY value_allocations_tenant ON public.value_event_allocations USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE INDEX cases_queue_idx ON public.cases(tenant_id,state,updated_at);
CREATE INDEX actions_queue_idx ON public.actions(tenant_id,state,created_at);
CREATE INDEX action_outbox_claim_idx ON public.action_outbox(tenant_id,available_at) WHERE dead_lettered_at IS NULL;
CREATE INDEX value_events_report_idx ON public.value_events(tenant_id,classification,effective_at);
