import { readFile } from 'node:fs/promises';
import { describe, expect, it } from 'vitest';
import { defaultMigrationsDir } from '../src/config.js';
import path from 'node:path';
const migration = async (): Promise<string> => readFile(path.join(defaultMigrationsDir,'0003_canonical_ontology.up.sql'),'utf8');
describe('Step 1 ontology migration contracts',()=>{
 it('uses composite tenant foreign keys for tenant-owned entities',async()=>{const sql=await migration(); expect(sql).toContain('FOREIGN KEY (tenant_id, resource_id)'); expect(sql).toContain('FOREIGN KEY (tenant_id, evidence_id)');});
 it('forces RLS on every tenant-owned ontology table',async()=>{const sql=await migration(); for(const table of ['resources','evidence_objects','resource_source_mappings','resource_facts','measurements']) expect(sql).toContain(`ALTER TABLE public.${table} FORCE ROW LEVEL SECURITY`);});
 it('provides bitemporal as-known-at reconstruction',async()=>{const sql=await migration(); expect(sql).toContain('p_effective_at timestamptz'); expect(sql).toContain('p_recorded_at timestamptz'); expect(sql).toContain('fact.recorded_to > p_recorded_at');});
 it('protects one current source mapping per source identity',async()=>{const sql=await migration(); expect(sql).toContain('WHERE recorded_to IS NULL');});
});
