import {describe,it,expect} from 'vitest';
import {readFileSync} from 'node:fs';
describe('tenant isolation hardening',()=>{
 const sql=readFileSync('packages/db/migrations/0008_api_policy_surface.up.sql','utf8');
 it('forces RLS',()=>expect((sql.match(/FORCE ROW LEVEL SECURITY/g)||[]).length).toBe(3));
 it('contains tenant policies',()=>expect(sql).toContain('rva_current_tenant')); 
});
