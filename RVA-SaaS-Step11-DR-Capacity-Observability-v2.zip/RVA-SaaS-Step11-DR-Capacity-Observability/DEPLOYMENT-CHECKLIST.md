# Step 11 Deployment Checklist

## Before change

- [ ] Approved SLO, RTO, RPO, capacity thresholds and owners recorded.
- [ ] Metrics endpoint authenticated, encrypted and restricted to monitoring networks.
- [ ] No tenant IDs, users, emails, request IDs, raw URIs, prompts or evidence payloads in labels.
- [ ] Prometheus/Grafana/Alertmanager credentials supplied through a managed secret store.
- [ ] Last known-good monitoring bundle and rollback command available.
- [ ] Change window, on-call staff and incident channel confirmed.

## Validate configuration

- [ ] `python3 scripts/validate_suite.py .` passes.
- [ ] `promtool check config --lint=all --lint-fatal prometheus/prometheus.yml` passes.
- [ ] `promtool check rules --lint=all --lint-fatal prometheus/rules/*.yml` passes.
- [ ] `promtool test rules prometheus/tests/rules.test.yml` passes from the expected working directory.
- [ ] Grafana provisioning YAML and dashboard JSON parse and use unique UIDs.
- [ ] SHA-256 manifest generated and retained.

## Deploy and verify

- [ ] Prometheus reload succeeds and all expected targets are UP.
- [ ] Rule groups evaluate without errors.
- [ ] Grafana datasource health succeeds.
- [ ] Both provisioned dashboards load and return data or expected explicit no-data states.
- [ ] Synthetic alert reaches the correct route, is acknowledged and resolves.
- [ ] Tenant-isolation alert is treated as SEV1 and cannot be waived.
- [ ] Monitoring components are independently monitored.

## DR and capacity certification

- [ ] Backup selected by identifier and checksum.
- [ ] Restore occurs in an isolated recovery environment.
- [ ] Migrations, forced RLS, tenant isolation and application smoke checks pass.
- [ ] Measured RPO and RTO meet the approved policy.
- [ ] Capacity evidence covers current use and 3, 6, 12 and 24-month forecasts.
- [ ] No resource reaches the approved critical threshold during the certification profile.
- [ ] Service owner and SRE approve capacity evidence.

## Go/No-Go

- [ ] No critical/high unresolved observability or DR security finding.
- [ ] Alert routing, restore validation and rollback rehearsal pass.
- [ ] Evidence is release/environment bound, hashed and retained.
- [ ] Two-person approval recorded for production promotion.
