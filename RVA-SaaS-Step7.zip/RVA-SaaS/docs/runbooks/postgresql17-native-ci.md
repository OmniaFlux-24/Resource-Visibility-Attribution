# Native PostgreSQL 17 CI

The GitHub job runs on Ubuntu 24.04 and does not use Docker or service containers.

It installs `postgresql-17` and `postgresql-client-17` from the PostgreSQL Global Development Group APT repository, starts the native `17/main` cluster, creates a disposable CI superuser/database, runs migrations and adversarial integration tests, then proves schema backup and restore.

Local use requires an already installed and running PostgreSQL 17 instance. Set `PGHOST`, `PGPORT`, `PGUSER`, `PGPASSWORD` and `PGDATABASE`, then run `npm run test:postgres17:native`.
