SELECT rolname, rolsuper, rolbypassrls FROM pg_roles WHERE rolname='rva_app';
