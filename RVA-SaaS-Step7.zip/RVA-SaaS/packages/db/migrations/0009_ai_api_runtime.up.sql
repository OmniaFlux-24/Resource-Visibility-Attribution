CREATE TYPE public.ai_invocation_state AS ENUM ('REQUESTED','SUCCEEDED','REFUSED','FAILED','REVIEWED','REJECTED');
ALTER TABLE public.api_idempotency_keys ADD COLUMN method text NOT NULL DEFAULT 'POST', ADD COLUMN route text NOT NULL DEFAULT '/', ADD COLUMN status_code integer, ADD COLUMN response_body jsonb, ADD CONSTRAINT idempotency_hash_format CHECK(request_hash ~ '^[0-9a-f]{64}$' AND (response_hash IS NULL OR response_hash ~ '^[0-9a-f]{64}$')), ADD CONSTRAINT idempotency_response_pair CHECK((status_code IS NULL AND response_body IS NULL AND response_hash IS NULL) OR (status_code IS NOT NULL AND response_body IS NOT NULL AND response_hash IS NOT NULL));
CREATE TABLE public.ai_invocations (
 tenant_id uuid NOT NULL, ai_invocation_id uuid NOT NULL DEFAULT gen_random_uuid(), purpose text NOT NULL, model text NOT NULL,
 configuration_hash char(64) NOT NULL, input_hash char(64) NOT NULL, schema_hash char(64) NOT NULL, state public.ai_invocation_state NOT NULL,
 provider_response_id text, requested_by_actor_id uuid NOT NULL, requested_at timestamptz NOT NULL DEFAULT clock_timestamp(), completed_at timestamptz,
 PRIMARY KEY(tenant_id,ai_invocation_id), FOREIGN KEY(tenant_id) REFERENCES public.tenants(tenant_id), FOREIGN KEY(tenant_id,requested_by_actor_id) REFERENCES public.actors(tenant_id,actor_id),
 CONSTRAINT ai_hashes CHECK(configuration_hash ~ '^[0-9a-f]{64}$' AND input_hash ~ '^[0-9a-f]{64}$' AND schema_hash ~ '^[0-9a-f]{64}$')
);
CREATE TABLE public.ai_proposals (
 tenant_id uuid NOT NULL, ai_proposal_id uuid NOT NULL DEFAULT gen_random_uuid(), ai_invocation_id uuid NOT NULL, proposal jsonb NOT NULL,
 evidence_id uuid, reviewed_by_actor_id uuid, reviewed_at timestamptz, accepted boolean, review_reason text,
 PRIMARY KEY(tenant_id,ai_proposal_id), UNIQUE(tenant_id,ai_invocation_id), FOREIGN KEY(tenant_id,ai_invocation_id) REFERENCES public.ai_invocations(tenant_id,ai_invocation_id),
 FOREIGN KEY(tenant_id,evidence_id) REFERENCES public.evidence_objects(tenant_id,evidence_id), FOREIGN KEY(tenant_id,reviewed_by_actor_id) REFERENCES public.actors(tenant_id,actor_id),
 CONSTRAINT ai_review_consistency CHECK((reviewed_at IS NULL AND reviewed_by_actor_id IS NULL AND accepted IS NULL) OR (reviewed_at IS NOT NULL AND reviewed_by_actor_id IS NOT NULL AND accepted IS NOT NULL))
);
CREATE FUNCTION public.prevent_ai_source_mutation() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'AI invocation records are immutable'; END; $$;
CREATE TRIGGER ai_invocations_immutable BEFORE UPDATE OR DELETE ON public.ai_invocations FOR EACH ROW EXECUTE FUNCTION public.prevent_ai_source_mutation();
ALTER TABLE public.ai_invocations ENABLE ROW LEVEL SECURITY; ALTER TABLE public.ai_invocations FORCE ROW LEVEL SECURITY;
ALTER TABLE public.ai_proposals ENABLE ROW LEVEL SECURITY; ALTER TABLE public.ai_proposals FORCE ROW LEVEL SECURITY;
CREATE POLICY ai_invocations_tenant ON public.ai_invocations USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY ai_proposals_tenant ON public.ai_proposals USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE INDEX ai_invocations_operations_idx ON public.ai_invocations(tenant_id,state,requested_at);
