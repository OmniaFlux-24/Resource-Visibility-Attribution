import { randomUUID } from 'node:crypto';
import type {ApiRequest,ApiResponse,Authenticator,Authorizer,Repository} from './types.js';
const entities=new Set(['resources','findings','cases','actions','value-events']);
const json=(status:number,body:unknown,requestId:string):ApiResponse=>({status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff','x-request-id':requestId},body});
export class RestController{
 constructor(private readonly auth:Authenticator,private readonly authorizer:Authorizer,private readonly repository:Repository,private readonly writableEntities:ReadonlySet<string>=new Set()){}
 async handle(request:ApiRequest):Promise<ApiResponse>{const requestId=request.headers['x-request-id']??randomUUID();try{
  if(request.method==='GET'&&request.path==='/health')return json(200,{status:'ok'},requestId);
  if(!request.path.startsWith('/api/v1/'))return json(404,{code:'not_found',message:'Resource not found'},requestId);
  const bearer=request.headers.authorization;if(!bearer?.startsWith('Bearer '))return json(401,{code:'unauthorized',message:'Authentication required'},requestId);
  let claims;try{claims=await this.auth.verify(bearer.slice(7));}catch{return json(401,{code:'unauthorized',message:'Authentication failed'},requestId);}const tenantHeader=request.headers['x-tenant-id'];if(tenantHeader!==undefined&&tenantHeader!==claims.tenantId)return json(404,{code:'not_found',message:'Resource not found'},requestId);
  const parts=request.path.slice('/api/v1/'.length).split('/').filter(Boolean);const entity=parts[0];const id=parts[1];if(entity===undefined||!entities.has(entity)||parts.length>2)return json(404,{code:'not_found',message:'Resource not found'},requestId);
  if(request.method==='GET'){this.authorizer.authorize(claims,`${entity}:read`);if(id!==undefined){const item=await this.repository.get(entity,claims.tenantId,id);return item===undefined?json(404,{code:'not_found',message:'Resource not found'},requestId):json(200,item,requestId);}const page=await this.repository.list(entity,claims.tenantId,request.query?.cursor);return json(200,page,requestId);}
  if(request.method==='POST'&&id===undefined){if(!this.writableEntities.has(entity))return json(405,{code:'method_not_allowed',message:'Method not allowed'},requestId);this.authorizer.authorize(claims,`${entity}:write`);const key=request.headers['idempotency-key'];if(key===undefined||key.length<16)return json(400,{code:'idempotency_required',message:'A valid Idempotency-Key is required'},requestId);const created=await this.repository.create(entity,claims.tenantId,{body:request.body,idempotencyKey:key},claims);return json(201,created,requestId);}
  return json(405,{code:'method_not_allowed',message:'Method not allowed'},requestId);
 }catch(error){if(error instanceof Error&&error.message==='Forbidden')return json(403,{code:'forbidden',message:'Permission denied'},requestId);return json(500,{code:'internal_error',message:'Request could not be completed'},requestId);}}
}
