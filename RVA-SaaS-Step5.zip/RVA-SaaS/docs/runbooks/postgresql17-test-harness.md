# PostgreSQL 17 test harness

Prerequisites: Node 22, npm 10+, Docker with Compose v2.

Run `npm ci --ignore-scripts`, then `npm run test:postgres17`.

The harness starts disposable PostgreSQL 17.11, executes migration apply/rollback/reapply verification, runs restricted-role integration tests, exports the schema, restores it into a second database, and always removes containers and volumes.

The credentials are test-only and the database uses tmpfs. Never reuse them in a deployed environment.
