CREATE FUNCTION public.rva_current_tenant() RETURNS uuid
LANGUAGE sql STABLE AS $$ SELECT NULLIF(current_setting('rva.tenant_id', true), '')::uuid $$;
CREATE TABLE public.tenants (
  tenant_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  display_name text NOT NULL,
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  CONSTRAINT tenants_slug_format CHECK (slug ~ '^[a-z0-9]([a-z0-9-]{1,61}[a-z0-9])$'),
  CONSTRAINT tenants_display_name_not_blank CHECK (length(btrim(display_name)) > 0)
);
ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tenants FORCE ROW LEVEL SECURITY;
CREATE POLICY tenants_self_isolation ON public.tenants
  USING (tenant_id = public.rva_current_tenant())
  WITH CHECK (tenant_id = public.rva_current_tenant());
