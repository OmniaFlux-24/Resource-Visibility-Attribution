import { randomUUID } from 'node:crypto';
import { Client } from 'pg';
import { afterAll,beforeAll,describe,expect,it } from 'vitest';
import { Migrator } from '../src/migrator.js';
const url=process.env['RVA_DATABASE_URL'];
describe.skipIf(url===undefined)('PostgreSQL 17 production harness',()=>{
 const migrator=new Migrator(url??''); const admin=new Client({connectionString:url});
 beforeAll(async()=>{await admin.connect();await migrator.up();});
 afterAll(async()=>{await admin.query('RESET ROLE').catch(()=>undefined);await admin.query('DROP ROLE IF EXISTS rva_integration_app');await admin.end();});
 it('runs on PostgreSQL major version 17',async()=>{const r=await admin.query<{version:string}>("SELECT current_setting('server_version_num') AS version");expect(r.rows[0]?.version.startsWith('17')).toBe(true);});
 it('forces RLS on every tenant-owned application table',async()=>{const r=await admin.query<{relname:string;relrowsecurity:boolean;relforcerowsecurity:boolean}>(`SELECT c.relname,c.relrowsecurity,c.relforcerowsecurity FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relkind='r' AND EXISTS(SELECT 1 FROM information_schema.columns col WHERE col.table_schema='public' AND col.table_name=c.relname AND col.column_name='tenant_id')`);expect(r.rows.length).toBeGreaterThan(20);for(const row of r.rows){expect(row.relrowsecurity,`${row.relname} RLS`).toBe(true);expect(row.relforcerowsecurity,`${row.relname} FORCE RLS`).toBe(true);}});
 it('fails closed and rejects cross-tenant read/write as restricted role',async()=>{
  const a=randomUUID(),b=randomUUID(); await admin.query('CREATE ROLE rva_integration_app NOLOGIN'); await admin.query('GRANT USAGE ON SCHEMA public TO rva_integration_app'); await admin.query('GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO rva_integration_app'); await admin.query('GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA public TO rva_integration_app');
  await admin.query("INSERT INTO public.tenants(tenant_id,slug,display_name) VALUES($1,$2,'A'),($3,$4,'B')",[a,`a-${a.slice(0,8)}`,b,`b-${b.slice(0,8)}`]); await admin.query('SET ROLE rva_integration_app');
  const none=await admin.query('SELECT * FROM public.tenants');expect(none.rowCount).toBe(0); await admin.query("SELECT set_config('rva.tenant_id',$1,false)",[a]); const own=await admin.query('SELECT * FROM public.tenants');expect(own.rowCount).toBe(1);
  await expect(admin.query("INSERT INTO public.principals(tenant_id,principal_type,external_subject,issuer,display_name) VALUES($1,'USER','x','test','Cross')",[b])).rejects.toThrow(/row-level security/);
  await admin.query('RESET ROLE'); await admin.query('DELETE FROM public.tenants WHERE tenant_id=ANY($1::uuid[])',[[a,b]]); await admin.query('DROP ROLE rva_integration_app');
 });
 it('keeps migration apply idempotent',async()=>{expect(await migrator.up()).toEqual([]);});
});
