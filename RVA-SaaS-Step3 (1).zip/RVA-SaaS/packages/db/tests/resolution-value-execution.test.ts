import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { describe,expect,it } from 'vitest';
import { defaultMigrationsDir } from '../src/config.js';
const read=async(suffix:'up'|'down'):Promise<string>=>readFile(path.join(defaultMigrationsDir,`0006_resolution_value_execution.${suffix}.sql`),'utf8');
describe('Step 3 production contracts',()=>{
 it('binds approval to exact target, operation, payload, limit, policy and expiry',async()=>{const s=await read('up'); for(const x of ['target_reference','operation','payload_hash','maximum_impact','policy_version','expires_at']) expect(s).toContain(x); expect(s).toContain('Independent approval required');});
 it('provides durable idempotent execution records',async()=>{const s=await read('up'); for(const x of ['idempotency_key','action_outbox','leased_until','max_attempts','action_attempts','action_receipts']) expect(s).toContain(x);});
 it('blocks execution under emergency stop',async()=>{expect(await read('up')).toContain('Execution blocked by emergency stop');});
 it('serializes value allocation totals against concurrent writers',async()=>{const s=await read('up'); expect(s).toContain('pg_advisory_xact_lock'); expect(s).toContain('Allocations exceed ValueEvent amount');});
 it('keeps verified value separate and immutable',async()=>{const s=await read('up'); expect(s).toContain('CREATE TABLE public.value_events'); expect(s).toContain('value_events_immutable'); expect(s).toContain('PREVENTED_LOSS'); expect(s).toContain('counterfactual_basis');});
 it('forces tenant RLS on all ten Step 3 tables',async()=>{expect(((await read('up')).match(/FORCE ROW LEVEL SECURITY/g)??[])).toHaveLength(10);});
 it('has rollback coverage for every Step 3 table',async()=>{const s=await read('down'); for(const x of ['value_event_allocations','value_events','action_receipts','action_attempts','action_outbox','actions','approval_grants','emergency_stops','case_findings','cases']) expect(s).toContain(`DROP TABLE IF EXISTS public.${x}`);});
});
