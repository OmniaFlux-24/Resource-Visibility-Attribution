CREATE TYPE public.resource_domain AS ENUM ('FINANCIAL','CONTRACTUAL','WORKFORCE','PHYSICAL','DIGITAL','ENERGY','COMMERCIAL','OPERATIONAL');
CREATE TYPE public.measurement_method AS ENUM ('DIRECT','ESTIMATED','DERIVED');
CREATE TYPE public.data_quality AS ENUM ('VERIFIED','VALID','QUESTIONABLE','MISSING','CONTRADICTORY','STALE');

CREATE TABLE public.resources (
  tenant_id uuid NOT NULL,
  resource_id uuid NOT NULL DEFAULT gen_random_uuid(),
  canonical_urn text NOT NULL,
  domain public.resource_domain NOT NULL,
  resource_type text NOT NULL,
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (tenant_id, resource_id),
  UNIQUE (tenant_id, canonical_urn),
  FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id),
  CONSTRAINT resources_urn_format CHECK (canonical_urn LIKE 'urn:rva:%'),
  CONSTRAINT resources_type_not_blank CHECK (length(btrim(resource_type)) > 0)
);

CREATE TABLE public.evidence_objects (
  tenant_id uuid NOT NULL,
  evidence_id uuid NOT NULL DEFAULT gen_random_uuid(),
  storage_reference text NOT NULL,
  sha256 char(64) NOT NULL,
  media_type text NOT NULL,
  source_system text NOT NULL,
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (tenant_id, evidence_id),
  UNIQUE (tenant_id, sha256),
  FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id),
  CONSTRAINT evidence_sha256_format CHECK (sha256 ~ '^[0-9a-f]{64}$')
);

CREATE TABLE public.resource_source_mappings (
  tenant_id uuid NOT NULL,
  mapping_id uuid NOT NULL DEFAULT gen_random_uuid(),
  resource_id uuid NOT NULL,
  source_system text NOT NULL,
  source_identifier text NOT NULL,
  evidence_id uuid,
  valid_from timestamptz NOT NULL,
  valid_to timestamptz,
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  recorded_to timestamptz,
  supersedes_mapping_id uuid,
  PRIMARY KEY (tenant_id, mapping_id),
  FOREIGN KEY (tenant_id, resource_id) REFERENCES public.resources(tenant_id, resource_id),
  FOREIGN KEY (tenant_id, evidence_id) REFERENCES public.evidence_objects(tenant_id, evidence_id),
  FOREIGN KEY (tenant_id, supersedes_mapping_id) REFERENCES public.resource_source_mappings(tenant_id, mapping_id),
  CONSTRAINT mapping_effective_range CHECK (valid_to IS NULL OR valid_to > valid_from),
  CONSTRAINT mapping_recorded_range CHECK (recorded_to IS NULL OR recorded_to > recorded_at)
);

CREATE TABLE public.resource_facts (
  tenant_id uuid NOT NULL,
  fact_id uuid NOT NULL DEFAULT gen_random_uuid(),
  resource_id uuid NOT NULL,
  fact_type text NOT NULL,
  schema_version integer NOT NULL,
  value jsonb NOT NULL,
  effective_from timestamptz NOT NULL,
  effective_to timestamptz,
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  recorded_to timestamptz,
  supersedes_fact_id uuid,
  evidence_id uuid,
  actor text NOT NULL,
  PRIMARY KEY (tenant_id, fact_id),
  FOREIGN KEY (tenant_id, resource_id) REFERENCES public.resources(tenant_id, resource_id),
  FOREIGN KEY (tenant_id, supersedes_fact_id) REFERENCES public.resource_facts(tenant_id, fact_id),
  FOREIGN KEY (tenant_id, evidence_id) REFERENCES public.evidence_objects(tenant_id, evidence_id),
  CONSTRAINT facts_schema_version_positive CHECK (schema_version > 0),
  CONSTRAINT facts_effective_range CHECK (effective_to IS NULL OR effective_to > effective_from),
  CONSTRAINT facts_recorded_range CHECK (recorded_to IS NULL OR recorded_to > recorded_at),
  CONSTRAINT facts_actor_not_blank CHECK (length(btrim(actor)) > 0)
);

CREATE TABLE public.units (
  unit_code text PRIMARY KEY,
  dimension_code text NOT NULL,
  symbol text NOT NULL,
  scale_to_base numeric(38,18) NOT NULL,
  conversion_version integer NOT NULL,
  CONSTRAINT units_scale_positive CHECK (scale_to_base > 0),
  CONSTRAINT units_conversion_version_positive CHECK (conversion_version > 0)
);

CREATE TABLE public.measurements (
  tenant_id uuid NOT NULL,
  measurement_id uuid NOT NULL DEFAULT gen_random_uuid(),
  resource_id uuid NOT NULL,
  metric_code text NOT NULL,
  value numeric(38,18) NOT NULL,
  unit_code text NOT NULL,
  method public.measurement_method NOT NULL,
  quality public.data_quality NOT NULL,
  uncertainty numeric(38,18),
  effective_at timestamptz NOT NULL,
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  source_system text NOT NULL,
  evidence_id uuid,
  actor text NOT NULL,
  input_hash char(64) NOT NULL,
  PRIMARY KEY (tenant_id, measurement_id),
  FOREIGN KEY (tenant_id, resource_id) REFERENCES public.resources(tenant_id, resource_id),
  FOREIGN KEY (unit_code) REFERENCES public.units(unit_code),
  FOREIGN KEY (tenant_id, evidence_id) REFERENCES public.evidence_objects(tenant_id, evidence_id),
  CONSTRAINT measurements_uncertainty_nonnegative CHECK (uncertainty IS NULL OR uncertainty >= 0),
  CONSTRAINT measurements_input_hash_format CHECK (input_hash ~ '^[0-9a-f]{64}$'),
  CONSTRAINT measurements_actor_not_blank CHECK (length(btrim(actor)) > 0)
);

CREATE UNIQUE INDEX mappings_current_source_unique_idx ON public.resource_source_mappings(tenant_id, source_system, source_identifier) WHERE recorded_to IS NULL;
CREATE INDEX resources_tenant_domain_idx ON public.resources(tenant_id, domain, resource_type);
CREATE INDEX facts_as_known_idx ON public.resource_facts(tenant_id, resource_id, effective_from, recorded_at);
CREATE INDEX measurements_history_idx ON public.measurements(tenant_id, resource_id, effective_at, recorded_at);

ALTER TABLE public.resources ENABLE ROW LEVEL SECURITY; ALTER TABLE public.resources FORCE ROW LEVEL SECURITY;
ALTER TABLE public.evidence_objects ENABLE ROW LEVEL SECURITY; ALTER TABLE public.evidence_objects FORCE ROW LEVEL SECURITY;
ALTER TABLE public.resource_source_mappings ENABLE ROW LEVEL SECURITY; ALTER TABLE public.resource_source_mappings FORCE ROW LEVEL SECURITY;
ALTER TABLE public.resource_facts ENABLE ROW LEVEL SECURITY; ALTER TABLE public.resource_facts FORCE ROW LEVEL SECURITY;
ALTER TABLE public.measurements ENABLE ROW LEVEL SECURITY; ALTER TABLE public.measurements FORCE ROW LEVEL SECURITY;

CREATE POLICY resources_tenant_isolation ON public.resources USING (tenant_id=public.rva_current_tenant()) WITH CHECK (tenant_id=public.rva_current_tenant());
CREATE POLICY evidence_tenant_isolation ON public.evidence_objects USING (tenant_id=public.rva_current_tenant()) WITH CHECK (tenant_id=public.rva_current_tenant());
CREATE POLICY mappings_tenant_isolation ON public.resource_source_mappings USING (tenant_id=public.rva_current_tenant()) WITH CHECK (tenant_id=public.rva_current_tenant());
CREATE POLICY facts_tenant_isolation ON public.resource_facts USING (tenant_id=public.rva_current_tenant()) WITH CHECK (tenant_id=public.rva_current_tenant());
CREATE POLICY measurements_tenant_isolation ON public.measurements USING (tenant_id=public.rva_current_tenant()) WITH CHECK (tenant_id=public.rva_current_tenant());

CREATE FUNCTION public.resource_facts_as_known(p_effective_at timestamptz, p_recorded_at timestamptz)
RETURNS SETOF public.resource_facts
LANGUAGE sql STABLE SECURITY INVOKER AS $$
  SELECT fact.*
  FROM public.resource_facts fact
  WHERE fact.effective_from <= p_effective_at
    AND (fact.effective_to IS NULL OR fact.effective_to > p_effective_at)
    AND fact.recorded_at <= p_recorded_at
    AND (fact.recorded_to IS NULL OR fact.recorded_to > p_recorded_at)
    AND fact.tenant_id = public.rva_current_tenant()
$$;
