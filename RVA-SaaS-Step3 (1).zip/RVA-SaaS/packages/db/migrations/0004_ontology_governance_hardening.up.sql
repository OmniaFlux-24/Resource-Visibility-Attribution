CREATE TYPE public.actor_type AS ENUM ('HUMAN','SERVICE','CONNECTOR','AI_AGENT','SYSTEM');
CREATE TYPE public.relationship_type AS ENUM ('OWNS','CONTROLS','USES','CONSUMES','DEPENDS_ON','ALLOCATED_TO','GOVERNED_BY','EVIDENCED_BY','PARENT_OF');

CREATE TABLE public.actors (
  tenant_id uuid NOT NULL,
  actor_id uuid NOT NULL DEFAULT gen_random_uuid(),
  actor_type public.actor_type NOT NULL,
  display_name text NOT NULL,
  source_system text,
  source_identifier text,
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (tenant_id, actor_id),
  UNIQUE (tenant_id, source_system, source_identifier),
  FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id),
  CONSTRAINT actors_name_not_blank CHECK (length(btrim(display_name)) > 0)
);

CREATE TABLE public.fact_definitions (
  fact_type_code text NOT NULL,
  schema_version integer NOT NULL,
  domain public.resource_domain NOT NULL,
  display_name text NOT NULL,
  json_schema jsonb NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (fact_type_code, schema_version),
  CONSTRAINT fact_schema_version_positive CHECK (schema_version > 0),
  CONSTRAINT fact_code_not_blank CHECK (length(btrim(fact_type_code)) > 0)
);

CREATE TABLE public.metric_definitions (
  metric_code text PRIMARY KEY,
  domain public.resource_domain NOT NULL,
  dimension_code text NOT NULL,
  display_name text NOT NULL,
  base_unit_code text NOT NULL REFERENCES public.units(unit_code),
  is_active boolean NOT NULL DEFAULT true,
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  UNIQUE (metric_code, dimension_code)
);

CREATE TABLE public.metric_allowed_units (
  metric_code text NOT NULL REFERENCES public.metric_definitions(metric_code),
  unit_code text NOT NULL REFERENCES public.units(unit_code),
  PRIMARY KEY (metric_code, unit_code)
);

ALTER TABLE public.resource_facts
  ADD CONSTRAINT facts_definition_fk FOREIGN KEY (fact_type, schema_version)
  REFERENCES public.fact_definitions(fact_type_code, schema_version),
  ADD COLUMN effective_range tstzrange GENERATED ALWAYS AS (tstzrange(effective_from,effective_to,'[)')) STORED,
  ADD CONSTRAINT facts_supersedes_unique UNIQUE (tenant_id, supersedes_fact_id);

ALTER TABLE public.measurements
  ADD CONSTRAINT measurements_metric_fk FOREIGN KEY (metric_code)
  REFERENCES public.metric_definitions(metric_code),
  ADD COLUMN confidence_percent numeric(5,2),
  ADD CONSTRAINT measurements_confidence_range CHECK (confidence_percent IS NULL OR confidence_percent BETWEEN 0 AND 100);

CREATE FUNCTION public.validate_measurement_unit() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.metric_allowed_units allowed
    WHERE allowed.metric_code = NEW.metric_code AND allowed.unit_code = NEW.unit_code
  ) THEN RAISE EXCEPTION 'Unit % is not allowed for metric %', NEW.unit_code, NEW.metric_code;
  END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER measurements_validate_unit BEFORE INSERT OR UPDATE OF metric_code, unit_code ON public.measurements
FOR EACH ROW EXECUTE FUNCTION public.validate_measurement_unit();

CREATE TABLE public.resource_relationships (
  tenant_id uuid NOT NULL,
  relationship_id uuid NOT NULL DEFAULT gen_random_uuid(),
  subject_resource_id uuid NOT NULL,
  predicate public.relationship_type NOT NULL,
  object_resource_id uuid NOT NULL,
  effective_from timestamptz NOT NULL,
  effective_to timestamptz,
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  recorded_to timestamptz,
  supersedes_relationship_id uuid,
  evidence_id uuid,
  actor_id uuid NOT NULL,
  effective_range tstzrange GENERATED ALWAYS AS (tstzrange(effective_from,effective_to,'[)')) STORED,
  PRIMARY KEY (tenant_id, relationship_id),
  FOREIGN KEY (tenant_id, subject_resource_id) REFERENCES public.resources(tenant_id, resource_id),
  FOREIGN KEY (tenant_id, object_resource_id) REFERENCES public.resources(tenant_id, resource_id),
  FOREIGN KEY (tenant_id, supersedes_relationship_id) REFERENCES public.resource_relationships(tenant_id, relationship_id),
  FOREIGN KEY (tenant_id, evidence_id) REFERENCES public.evidence_objects(tenant_id, evidence_id),
  FOREIGN KEY (tenant_id, actor_id) REFERENCES public.actors(tenant_id, actor_id),
  CONSTRAINT relationship_no_self CHECK (subject_resource_id <> object_resource_id),
  CONSTRAINT relationship_effective_range CHECK (effective_to IS NULL OR effective_to > effective_from),
  CONSTRAINT relationship_recorded_range CHECK (recorded_to IS NULL OR recorded_to > recorded_at)
);

ALTER TABLE public.resource_facts
  ADD COLUMN actor_id uuid,
  ADD CONSTRAINT facts_actor_fk FOREIGN KEY (tenant_id,actor_id) REFERENCES public.actors(tenant_id,actor_id);
ALTER TABLE public.measurements
  ADD COLUMN actor_id uuid,
  ADD CONSTRAINT measurements_actor_fk FOREIGN KEY (tenant_id,actor_id) REFERENCES public.actors(tenant_id,actor_id);

CREATE FUNCTION public.reject_fact_overlap() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM public.resource_facts f
    WHERE f.tenant_id=NEW.tenant_id AND f.resource_id=NEW.resource_id AND f.fact_type=NEW.fact_type
      AND f.recorded_to IS NULL AND f.fact_id<>NEW.fact_id AND f.effective_range && NEW.effective_range)
  THEN RAISE EXCEPTION 'Current resource fact effective ranges overlap'; END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER facts_reject_overlap BEFORE INSERT OR UPDATE OF effective_from,effective_to,recorded_to ON public.resource_facts
FOR EACH ROW EXECUTE FUNCTION public.reject_fact_overlap();

CREATE FUNCTION public.reject_relationship_overlap() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM public.resource_relationships r
    WHERE r.tenant_id=NEW.tenant_id AND r.subject_resource_id=NEW.subject_resource_id
      AND r.predicate=NEW.predicate AND r.object_resource_id=NEW.object_resource_id
      AND r.recorded_to IS NULL AND r.relationship_id<>NEW.relationship_id AND r.effective_range && NEW.effective_range)
  THEN RAISE EXCEPTION 'Current relationship effective ranges overlap'; END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER relationships_reject_overlap BEFORE INSERT OR UPDATE OF effective_from,effective_to,recorded_to ON public.resource_relationships
FOR EACH ROW EXECUTE FUNCTION public.reject_relationship_overlap();

CREATE FUNCTION public.prevent_evidence_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'Evidence records are immutable; append a new record'; END; $$;
CREATE TRIGGER evidence_no_update_delete BEFORE UPDATE OR DELETE ON public.evidence_objects
FOR EACH ROW EXECUTE FUNCTION public.prevent_evidence_mutation();

ALTER TABLE public.actors ENABLE ROW LEVEL SECURITY; ALTER TABLE public.actors FORCE ROW LEVEL SECURITY;
ALTER TABLE public.resource_relationships ENABLE ROW LEVEL SECURITY; ALTER TABLE public.resource_relationships FORCE ROW LEVEL SECURITY;
CREATE POLICY actors_tenant_isolation ON public.actors USING (tenant_id=public.rva_current_tenant()) WITH CHECK (tenant_id=public.rva_current_tenant());
CREATE POLICY relationships_tenant_isolation ON public.resource_relationships USING (tenant_id=public.rva_current_tenant()) WITH CHECK (tenant_id=public.rva_current_tenant());
CREATE INDEX relationships_traversal_idx ON public.resource_relationships(tenant_id,subject_resource_id,predicate,effective_from);
