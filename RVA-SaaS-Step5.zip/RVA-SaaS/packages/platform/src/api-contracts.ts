export interface ApiContext {tenantId:string;requestId:string;correlationId:string;apiVersion:string;}
export interface ApiError {code:string;message:string;}
export interface PagedResponse<T>{items:T[];nextCursor?:string;}
export function validateApiVersion(v:string){if(!/^v[0-9]+$/.test(v)) throw new Error('Invalid API version');}
