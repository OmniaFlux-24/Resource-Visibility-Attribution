# Disaster Recovery Certification Sequence

> Production engineering baseline. Runtime certification requires executed evidence from the target environment.

## Sequence

```mermaid
sequenceDiagram
 participant IC as Incident Commander
 participant B as Backup Catalog
 participant R as Recovery Environment
 participant V as Validation Suite
 participant T as Traffic Manager
 participant E as Evidence Store
 IC->>B: select approved recovery point
 B->>R: restore isolated environment
 R->>V: schema, migration, RLS, integrity and smoke tests
 V-->>IC: RPO and RTO evidence
 alt objectives met
  IC->>T: controlled cutover approval
  T-->>IC: health and traffic evidence
 else objectives missed
  IC->>E: NO-GO and corrective actions
 end
 IC->>E: drill timeline, hashes and approvals
```
