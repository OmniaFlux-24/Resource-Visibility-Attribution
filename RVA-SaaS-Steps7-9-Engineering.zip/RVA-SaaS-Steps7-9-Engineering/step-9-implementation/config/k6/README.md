# Performance profiles

Run smoke on each candidate, load at expected peak, stress to determine capacity, and soak for the approved operational duration. Thresholds in the sample are defaults, not contractual SLOs; service owners must approve real values. Use only synthetic staging accounts. Any tenant sentinel disclosure is an immediate NO-GO.
