CREATE TYPE public.principal_type AS ENUM ('USER','SERVICE_ACCOUNT','API_CLIENT');
CREATE TYPE public.connector_mode AS ENUM ('READ_ONLY','CONTROLLED_WRITE');
CREATE TYPE public.ingestion_state AS ENUM ('RECEIVED','SCANNING','VALIDATING','NORMALIZING','COMMITTED','QUARANTINED','FAILED');
CREATE TYPE public.job_state AS ENUM ('READY','LEASED','RUNNING','SUCCEEDED','FAILED','DEAD_LETTERED','CANCELLED');

CREATE TABLE public.principals (
 tenant_id uuid NOT NULL, principal_id uuid NOT NULL DEFAULT gen_random_uuid(), principal_type public.principal_type NOT NULL,
 external_subject text NOT NULL, issuer text NOT NULL, display_name text NOT NULL, disabled_at timestamptz, recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 PRIMARY KEY(tenant_id,principal_id), UNIQUE(tenant_id,issuer,external_subject), FOREIGN KEY(tenant_id) REFERENCES public.tenants(tenant_id)
);
CREATE TABLE public.role_assignments (
 tenant_id uuid NOT NULL, role_assignment_id uuid NOT NULL DEFAULT gen_random_uuid(), principal_id uuid NOT NULL, role_code text NOT NULL,
 domain public.resource_domain, sensitivity text, granted_by_actor_id uuid NOT NULL, valid_from timestamptz NOT NULL, valid_to timestamptz,
 PRIMARY KEY(tenant_id,role_assignment_id), UNIQUE(tenant_id,principal_id,role_code,domain,sensitivity),
 FOREIGN KEY(tenant_id,principal_id) REFERENCES public.principals(tenant_id,principal_id), FOREIGN KEY(tenant_id,granted_by_actor_id) REFERENCES public.actors(tenant_id,actor_id),
 CONSTRAINT role_validity CHECK(valid_to IS NULL OR valid_to>valid_from)
);
CREATE TABLE public.api_credentials (
 tenant_id uuid NOT NULL, credential_id uuid NOT NULL DEFAULT gen_random_uuid(), principal_id uuid NOT NULL, key_prefix text NOT NULL,
 secret_hash char(64) NOT NULL, scopes jsonb NOT NULL, expires_at timestamptz NOT NULL, revoked_at timestamptz, created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 PRIMARY KEY(tenant_id,credential_id), UNIQUE(tenant_id,key_prefix), FOREIGN KEY(tenant_id,principal_id) REFERENCES public.principals(tenant_id,principal_id),
 CONSTRAINT credential_hash_format CHECK(secret_hash ~ '^[0-9a-f]{64}$'), CONSTRAINT credential_expiry CHECK(expires_at>created_at)
);
CREATE TABLE public.connector_instances (
 tenant_id uuid NOT NULL, connector_instance_id uuid NOT NULL DEFAULT gen_random_uuid(), connector_code text NOT NULL, display_name text NOT NULL,
 mode public.connector_mode NOT NULL DEFAULT 'READ_ONLY', allowed_operations jsonb NOT NULL DEFAULT '[]'::jsonb, secret_reference text NOT NULL,
 configuration jsonb NOT NULL, schema_version integer NOT NULL, enabled boolean NOT NULL DEFAULT true, created_by_actor_id uuid NOT NULL,
 recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(), PRIMARY KEY(tenant_id,connector_instance_id), UNIQUE(tenant_id,connector_code,display_name),
 FOREIGN KEY(tenant_id) REFERENCES public.tenants(tenant_id), FOREIGN KEY(tenant_id,created_by_actor_id) REFERENCES public.actors(tenant_id,actor_id),
 CONSTRAINT connector_schema_positive CHECK(schema_version>0), CONSTRAINT connector_secret_is_reference CHECK(secret_reference !~* '(password|token|secret)='),
 CONSTRAINT connector_configuration_no_secrets CHECK(configuration::text !~* '"(password|token|secret|api_key|client_secret)"[[:space:]]*:')
);
CREATE TABLE public.webhook_deliveries (
 tenant_id uuid NOT NULL, delivery_id uuid NOT NULL DEFAULT gen_random_uuid(), connector_instance_id uuid NOT NULL, external_delivery_id text NOT NULL,
 payload_hash char(64) NOT NULL, signature_verified boolean NOT NULL, received_at timestamptz NOT NULL DEFAULT clock_timestamp(), replay_expires_at timestamptz NOT NULL,
 PRIMARY KEY(tenant_id,delivery_id), UNIQUE(tenant_id,connector_instance_id,external_delivery_id),
 FOREIGN KEY(tenant_id,connector_instance_id) REFERENCES public.connector_instances(tenant_id,connector_instance_id),
 CONSTRAINT webhook_hash_format CHECK(payload_hash ~ '^[0-9a-f]{64}$'), CONSTRAINT webhook_replay_window CHECK(replay_expires_at>received_at)
);

CREATE TABLE public.webhook_processing_events (
 tenant_id uuid NOT NULL, processing_event_id uuid NOT NULL DEFAULT gen_random_uuid(), delivery_id uuid NOT NULL,
 state text NOT NULL, details jsonb NOT NULL, recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(), worker_reference text NOT NULL,
 PRIMARY KEY(tenant_id,processing_event_id), FOREIGN KEY(tenant_id,delivery_id) REFERENCES public.webhook_deliveries(tenant_id,delivery_id)
);
CREATE TABLE public.ingestion_batches (
 tenant_id uuid NOT NULL, ingestion_batch_id uuid NOT NULL DEFAULT gen_random_uuid(), connector_instance_id uuid, source_reference text NOT NULL,
 state public.ingestion_state NOT NULL DEFAULT 'RECEIVED', source_hash char(64) NOT NULL, schema_version integer NOT NULL, record_count bigint,
 started_at timestamptz NOT NULL DEFAULT clock_timestamp(), completed_at timestamptz, quarantine_reason text, initiated_by_actor_id uuid NOT NULL,
 PRIMARY KEY(tenant_id,ingestion_batch_id), UNIQUE(tenant_id,source_reference,source_hash),
 FOREIGN KEY(tenant_id,connector_instance_id) REFERENCES public.connector_instances(tenant_id,connector_instance_id), FOREIGN KEY(tenant_id,initiated_by_actor_id) REFERENCES public.actors(tenant_id,actor_id),
 CONSTRAINT ingestion_hash_format CHECK(source_hash ~ '^[0-9a-f]{64}$'), CONSTRAINT ingestion_schema_positive CHECK(schema_version>0),
 CONSTRAINT ingestion_completion CHECK((state IN ('COMMITTED','QUARANTINED','FAILED') AND completed_at IS NOT NULL) OR state NOT IN ('COMMITTED','QUARANTINED','FAILED'))
);
CREATE TABLE public.worker_jobs (
 tenant_id uuid NOT NULL, job_id uuid NOT NULL DEFAULT gen_random_uuid(), job_type text NOT NULL, idempotency_key text NOT NULL, payload jsonb NOT NULL,
 state public.job_state NOT NULL DEFAULT 'READY', priority integer NOT NULL DEFAULT 100, available_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 lease_owner text, leased_until timestamptz, attempt_count integer NOT NULL DEFAULT 0, max_attempts integer NOT NULL DEFAULT 8, last_error_code text,
 created_at timestamptz NOT NULL DEFAULT clock_timestamp(), completed_at timestamptz,
 PRIMARY KEY(tenant_id,job_id), UNIQUE(tenant_id,job_type,idempotency_key), FOREIGN KEY(tenant_id) REFERENCES public.tenants(tenant_id),
 CONSTRAINT job_attempts CHECK(attempt_count>=0 AND max_attempts>0 AND attempt_count<=max_attempts),
 CONSTRAINT job_lease_pair CHECK((lease_owner IS NULL AND leased_until IS NULL) OR (lease_owner IS NOT NULL AND leased_until IS NOT NULL))
);

CREATE TABLE public.allowed_ingestion_transitions(from_state public.ingestion_state NOT NULL,to_state public.ingestion_state NOT NULL,PRIMARY KEY(from_state,to_state));
INSERT INTO public.allowed_ingestion_transitions VALUES
('RECEIVED','SCANNING'),('SCANNING','VALIDATING'),('SCANNING','QUARANTINED'),('SCANNING','FAILED'),('VALIDATING','NORMALIZING'),('VALIDATING','QUARANTINED'),('VALIDATING','FAILED'),('NORMALIZING','COMMITTED'),('NORMALIZING','QUARANTINED'),('NORMALIZING','FAILED');
CREATE FUNCTION public.guard_ingestion_transition() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN
 IF NEW.state<>OLD.state AND NOT EXISTS(SELECT 1 FROM public.allowed_ingestion_transitions t WHERE t.from_state=OLD.state AND t.to_state=NEW.state) THEN RAISE EXCEPTION 'Invalid ingestion transition'; END IF; RETURN NEW; END; $$;
CREATE TRIGGER ingestion_guard_state BEFORE UPDATE OF state ON public.ingestion_batches FOR EACH ROW EXECUTE FUNCTION public.guard_ingestion_transition();
CREATE TABLE public.allowed_job_transitions(from_state public.job_state NOT NULL,to_state public.job_state NOT NULL,PRIMARY KEY(from_state,to_state));
INSERT INTO public.allowed_job_transitions VALUES ('READY','LEASED'),('READY','CANCELLED'),('LEASED','RUNNING'),('LEASED','READY'),('RUNNING','SUCCEEDED'),('RUNNING','FAILED'),('FAILED','READY'),('FAILED','DEAD_LETTERED');
CREATE FUNCTION public.guard_job_transition() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN
 IF NEW.state<>OLD.state AND NOT EXISTS(SELECT 1 FROM public.allowed_job_transitions t WHERE t.from_state=OLD.state AND t.to_state=NEW.state) THEN RAISE EXCEPTION 'Invalid job transition'; END IF; RETURN NEW; END; $$;
CREATE TRIGGER jobs_guard_state BEFORE UPDATE OF state ON public.worker_jobs FOR EACH ROW EXECUTE FUNCTION public.guard_job_transition();
CREATE TABLE public.audit_events (
 tenant_id uuid NOT NULL, audit_event_id uuid NOT NULL DEFAULT gen_random_uuid(), event_type text NOT NULL, actor_id uuid,
 principal_id uuid, object_type text NOT NULL, object_id text NOT NULL, correlation_id uuid NOT NULL, request_id uuid NOT NULL,
 occurred_at timestamptz NOT NULL DEFAULT clock_timestamp(), details jsonb NOT NULL, previous_hash char(64), event_hash char(64) NOT NULL,
 PRIMARY KEY(tenant_id,audit_event_id), UNIQUE(tenant_id,event_hash), FOREIGN KEY(tenant_id) REFERENCES public.tenants(tenant_id),
 FOREIGN KEY(tenant_id,actor_id) REFERENCES public.actors(tenant_id,actor_id), FOREIGN KEY(tenant_id,principal_id) REFERENCES public.principals(tenant_id,principal_id),
 CONSTRAINT audit_event_hash CHECK(event_hash ~ '^[0-9a-f]{64}$'), CONSTRAINT audit_previous_hash CHECK(previous_hash IS NULL OR previous_hash ~ '^[0-9a-f]{64}$')
);
CREATE FUNCTION public.prevent_delivery_record_mutation() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'Security and audit records are immutable'; END; $$;
CREATE TRIGGER webhook_deliveries_immutable BEFORE UPDATE OR DELETE ON public.webhook_deliveries FOR EACH ROW EXECUTE FUNCTION public.prevent_delivery_record_mutation();

CREATE FUNCTION public.guard_audit_chain() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE latest char(64);
BEGIN
 PERFORM pg_advisory_xact_lock(hashtextextended(NEW.tenant_id::text,17));
 SELECT event_hash INTO latest FROM public.audit_events WHERE tenant_id=NEW.tenant_id ORDER BY occurred_at DESC,audit_event_id DESC LIMIT 1;
 IF NEW.previous_hash IS DISTINCT FROM latest THEN RAISE EXCEPTION 'Audit chain previous hash mismatch'; END IF;
 RETURN NEW;
END; $$;
CREATE TRIGGER audit_events_guard_chain BEFORE INSERT ON public.audit_events FOR EACH ROW EXECUTE FUNCTION public.guard_audit_chain();
CREATE TRIGGER audit_events_immutable BEFORE UPDATE OR DELETE ON public.audit_events FOR EACH ROW EXECUTE FUNCTION public.prevent_delivery_record_mutation();

ALTER TABLE public.principals ENABLE ROW LEVEL SECURITY; ALTER TABLE public.principals FORCE ROW LEVEL SECURITY;
ALTER TABLE public.role_assignments ENABLE ROW LEVEL SECURITY; ALTER TABLE public.role_assignments FORCE ROW LEVEL SECURITY;
ALTER TABLE public.api_credentials ENABLE ROW LEVEL SECURITY; ALTER TABLE public.api_credentials FORCE ROW LEVEL SECURITY;
ALTER TABLE public.connector_instances ENABLE ROW LEVEL SECURITY; ALTER TABLE public.connector_instances FORCE ROW LEVEL SECURITY;
ALTER TABLE public.webhook_deliveries ENABLE ROW LEVEL SECURITY; ALTER TABLE public.webhook_deliveries FORCE ROW LEVEL SECURITY;
ALTER TABLE public.webhook_processing_events ENABLE ROW LEVEL SECURITY; ALTER TABLE public.webhook_processing_events FORCE ROW LEVEL SECURITY;
ALTER TABLE public.ingestion_batches ENABLE ROW LEVEL SECURITY; ALTER TABLE public.ingestion_batches FORCE ROW LEVEL SECURITY;
ALTER TABLE public.worker_jobs ENABLE ROW LEVEL SECURITY; ALTER TABLE public.worker_jobs FORCE ROW LEVEL SECURITY;
ALTER TABLE public.audit_events ENABLE ROW LEVEL SECURITY; ALTER TABLE public.audit_events FORCE ROW LEVEL SECURITY;
CREATE POLICY principals_tenant ON public.principals USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY roles_tenant ON public.role_assignments USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY credentials_tenant ON public.api_credentials USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY connectors_tenant ON public.connector_instances USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY webhooks_tenant ON public.webhook_deliveries USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY webhook_processing_tenant ON public.webhook_processing_events USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY ingestion_tenant ON public.ingestion_batches USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY jobs_tenant ON public.worker_jobs USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY audit_tenant ON public.audit_events USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE INDEX roles_authorization_idx ON public.role_assignments(tenant_id,principal_id,role_code,valid_from);
CREATE INDEX webhook_processing_idx ON public.webhook_processing_events(tenant_id,delivery_id,recorded_at);
CREATE INDEX webhooks_replay_idx ON public.webhook_deliveries(tenant_id,connector_instance_id,received_at);
CREATE INDEX ingestion_operations_idx ON public.ingestion_batches(tenant_id,state,started_at);
CREATE INDEX worker_claim_idx ON public.worker_jobs(tenant_id,priority,available_at) WHERE state='READY';
CREATE INDEX audit_timeline_idx ON public.audit_events(tenant_id,occurred_at,audit_event_id);
