# Step 3 acceptance gates

- Cases aggregate but do not duplicate finding value.
- Approvals bind exact action target, operation, payload hash, maximum impact, policy and expiry.
- Sensitive execution requires an actor independent from the requester.
- Dry-run actions never execute.
- Emergency stop blocks readiness by tenant/domain/connector.
- Idempotency is unique per tenant and connector.
- Workers use leased outbox records with bounded retries and dead-letter state.
- Unknown external outcomes remain explicit until authoritative reconciliation.
- Receipts require external evidence and are immutable.
- ValueEvents are append-only, evidence-backed and unique by underlying economic event.
- Prevented loss requires a counterfactual basis and remains separately classified.
- Concurrent allocations are serialized and cannot exceed the event amount.
- All Step 3 tenant tables use composite keys, forced RLS and tenant-leading indexes.
- Apply, rollback and reapply yield stable schema fingerprints.
