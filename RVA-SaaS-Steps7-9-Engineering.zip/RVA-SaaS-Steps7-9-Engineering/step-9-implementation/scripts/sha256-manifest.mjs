import {createHash} from 'node:crypto';import {readFile,readdir,stat,writeFile} from 'node:fs/promises';import path from 'node:path';
const root=path.resolve(process.argv[2]??'evidence');const output=path.resolve(process.argv[3]??path.join(root,'sha256-manifest.json'));
async function walk(dir){const all=[];for(const name of (await readdir(dir)).sort()){const p=path.join(dir,name);const s=await stat(p);if(s.isDirectory())all.push(...await walk(p));else if(p!==output)all.push(p);}return all;}
const files=await walk(root);const artifacts=[];for(const file of files){const data=await readFile(file);artifacts.push({path:path.relative(root,file).replaceAll(path.sep,'/'),sha256:createHash('sha256').update(data).digest('hex'),bytes:data.length});}
await writeFile(output,JSON.stringify({schemaVersion:1,generatedAt:new Date().toISOString(),artifacts},null,2)+'\n');console.log(`Wrote ${artifacts.length} artifact hashes to ${output}`);
