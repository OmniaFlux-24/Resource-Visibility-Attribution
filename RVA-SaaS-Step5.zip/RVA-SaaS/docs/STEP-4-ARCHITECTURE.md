# Step 4 architecture: SaaS delivery, identity, acquisition and operations

## Purpose

Expose the shared RVA foundation safely as a multi-tenant SaaS platform without weakening database isolation or controlled-action authority.

## Components

- Identity boundary: OIDC/SAML subjects map to tenant principals; MFA and step-up remain identity-provider obligations enforced through claims and policy.
- Authorization: tenant role assignments support domain and sensitivity attributes; every request starts a database transaction and sets tenant context locally.
- API boundary: versioned REST/OpenAPI, strict validation, signed opaque pagination, request/correlation IDs, idempotency and rate-limiting adapter contracts.
- Connector SDK: read-only by default; controlled writes require allowlisted operations and Step 3 approval IDs.
- Acquisition: immutable webhook receipt metadata, source hashes, replay IDs, ingestion lifecycle, quarantine and schema version.
- Workers: durable tenant-scoped jobs with priority, lease, bounded retry and dead-letter state.
- Audit: immutable hash-linked tenant audit events containing actor/principal, object, request and correlation lineage.
- Operations: health/readiness, structured logs, metrics, traces, backup/restore proof, SLOs and incident runbooks.

## Trust boundaries

Raw documents and webhooks are untrusted. Secrets are referenced from a secret manager and are never stored in connector configuration. Identity claims are validated before tenant context is established. AI output cannot create authority, modify authoritative state or bypass deterministic validation.

## Production acceptance

Step 4 requires successful quality, PostgreSQL 17, security, dependency review and artifact-attestation workflows. Branch protection must require these checks. Deployment remains blocked without environment-specific restore, load, penetration and incident-response exercises.
