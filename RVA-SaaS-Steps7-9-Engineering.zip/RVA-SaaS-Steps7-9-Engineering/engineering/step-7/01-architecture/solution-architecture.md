# Step 7 Solution Architecture

> Production baseline. Acceptance requires executed evidence from the target environment.

## Context

JWT trust is established through issuer-bound OIDC discovery and JWKS. Authorization combines scopes, domain, sensitivity and field allowlists. PostgreSQL forced RLS remains the final tenant boundary. Quotas and AI governance fail closed.

## Components

OIDC/JWKS cache; JWT verifier; field-policy evaluator; atomic quota service; AI governance/evaluation service; immutable release evidence.

## Architecture

```mermaid
flowchart LR
 C[Client]-->G[Gateway TLS]
 G-->J[OIDC and JWKS Auth]
 J-->P[Scope Domain Sensitivity Fields]
 P-->Q[Distributed Quotas]
 Q-->A[Application]
 A-->DB[(PostgreSQL 17 FORCE RLS)]
 A-->AI[AI Governance]
 AI-->O[Allowlisted Provider]
 A-->E[Audit and Release Evidence]
 IDP[Trusted IdP]-->J
```

## NFRs

No tenant disclosure; bounded upstream calls; one refresh per cooldown; deterministic decisions; versioned policies; observable failures; AI disabled by default; rollback to last approved policy.

## Operations

Owners: Platform Engineering, Security Engineering, SRE, Data Engineering and the accountable service owner. Changes require code review, threat/test/rollback review, traceability updates and release-gate impact. Logs must exclude secrets, tokens, raw evidence and AI prompts/results.
