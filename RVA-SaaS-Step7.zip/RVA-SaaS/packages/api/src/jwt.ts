import { createPublicKey, verify as verifySignature } from 'node:crypto';
import type { Authenticator,Claims } from './types.js';
interface JwtHeader{alg?:unknown;typ?:unknown;kid?:unknown;} interface JwtPayload{iss?:unknown;aud?:unknown;sub?:unknown;exp?:unknown;nbf?:unknown;tenant_id?:unknown;scope?:unknown;}
const decode=<T>(part:string):T=>JSON.parse(Buffer.from(part,'base64url').toString('utf8')) as T;
export interface JwtVerifierOptions{readonly issuer:string;readonly audience:string;readonly publicKeyPem:string;readonly clock?:()=>number;readonly allowedClockSkewSeconds?:number;}
export class Rs256JwtAuthenticator implements Authenticator{
 constructor(private readonly options:JwtVerifierOptions){}
 async verify(token:string):Promise<Claims>{
  if(token.length>16_384)throw new Error('JWT size rejected');
  const parts=token.split('.');if(parts.length!==3)throw new Error('Invalid JWT');const [encodedHeader,encodedPayload,encodedSignature]=parts;if(encodedHeader===undefined||encodedPayload===undefined||encodedSignature===undefined)throw new Error('Invalid JWT');
  const header=decode<JwtHeader>(encodedHeader);if(header.alg!=='RS256'||header.typ!=='JWT')throw new Error('JWT algorithm or type rejected');
  const valid=verifySignature('RSA-SHA256',Buffer.from(`${encodedHeader}.${encodedPayload}`),createPublicKey(this.options.publicKeyPem),Buffer.from(encodedSignature,'base64url'));if(!valid)throw new Error('JWT signature rejected');
  const payload=decode<JwtPayload>(encodedPayload);const now=this.options.clock?.()??Math.floor(Date.now()/1000);const skew=this.options.allowedClockSkewSeconds??30;
  if(payload.iss!==this.options.issuer||!(payload.aud===this.options.audience||(Array.isArray(payload.aud)&&payload.aud.includes(this.options.audience))))throw new Error('JWT issuer or audience rejected');
  if(typeof payload.sub!=='string'||payload.sub.length===0||typeof payload.tenant_id!=='string'||!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(payload.tenant_id))throw new Error('JWT required claims missing');
  if(typeof payload.exp!=='number'||payload.exp<=now-skew||typeof payload.nbf==='number'&&payload.nbf>now+skew)throw new Error('JWT lifetime rejected');
  const scopes=typeof payload.scope==='string'?payload.scope.split(' ').filter(Boolean):[];return {subject:payload.sub,tenantId:payload.tenant_id,scopes,issuer:this.options.issuer,audience:this.options.audience};
 }
}
