#!/usr/bin/env bash
set -euo pipefail
base="$(cd "$(dirname "$0")/.." && pwd)"
node --test "$base/tests/live/idp-rotation.live.test.mjs"
