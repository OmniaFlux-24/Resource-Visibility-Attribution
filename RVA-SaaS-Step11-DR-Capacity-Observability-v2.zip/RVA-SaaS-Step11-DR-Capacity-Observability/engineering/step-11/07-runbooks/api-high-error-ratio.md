# api high error ratio

## Triage
Confirm the alert expression, affected service, release and dependency health. Preserve request and deployment evidence without recording secrets or tenant data.

## Containment
Freeze risky changes, apply the documented emergency control, and keep authentication and tenant isolation fail-closed.

## Recovery
Restore the last attested configuration or dependency, validate metrics and application behavior, then send an end-to-end test alert.

## Closure
Record timeline, root cause, corrective action, owner and regression test.
