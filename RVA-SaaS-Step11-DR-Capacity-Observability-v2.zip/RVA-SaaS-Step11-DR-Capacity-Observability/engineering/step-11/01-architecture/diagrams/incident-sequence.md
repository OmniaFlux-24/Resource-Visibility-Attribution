# Detection and Incident Sequence

> Production engineering baseline. Runtime certification requires executed evidence from the target environment.

## Sequence

```mermaid
sequenceDiagram
 participant A as Application
 participant P as Prometheus
 participant M as Alertmanager
 participant O as On-call
 participant R as Runbook
 participant E as Evidence Store
 A->>P: metrics scrape
 P->>P: evaluate recording and alert rules
 P->>M: firing alert with severity and runbook
 M->>O: routed notification
 O->>R: follow containment and recovery
 O->>E: timeline, actions and validation evidence
 E-->>O: immutable incident reference
```

## Requirement

Every page-capable alert has owner, service, severity, summary, description and runbook annotation. End-to-end notification tests prove routing, acknowledgement and resolution behavior.
