# Release blocker priorities after Step 6

## P0: release evidence and identity lifecycle

1. Execute all CI gates successfully and retain evidence.
2. Replace static JWT keys with trusted-issuer discovery, bounded JWKS caching and safe rotation.
3. Prove PostgreSQL 17 migration, tenant isolation, backup and restore.

## P1: production authority and abuse controls

4. Implement entity-specific write commands with schema and property authorization.
5. Implement distributed tenant/principal/IP/operation quotas and AI spend budgets.
6. Approve and enforce tenant AI policy, data classification, region, retention mode, models, purposes and human review.
7. Add runtime OpenAPI request/response validation and breaking-change detection.

## P2: operational release assurance

8. Prove TLS, secret management, egress control, logging redaction, CORS and proxy configuration.
9. Execute load, soak, chaos, migration interruption, connection exhaustion, PITR, DR, DAST and penetration tests.
10. Pin third-party CI actions to reviewed immutable revisions and complete privacy/security approvals.

No lower-priority item can waive a higher-priority blocker.
