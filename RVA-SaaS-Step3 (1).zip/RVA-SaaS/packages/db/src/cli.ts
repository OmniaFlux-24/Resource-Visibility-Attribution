import { Migrator } from './migrator.js';
const command=process.argv[2]; const migrator=new Migrator();
if(command==='up') console.log(await migrator.up()); else if(command==='down') console.log(await migrator.downAll()); else if(command==='status') console.log(await migrator.status()); else {console.error('usage: up|down|status'); process.exitCode=2;}
