# Step 6 security review and release blockers

## Review basis

The review maps Step 6 against JWT BCP controls, tenant isolation, OWASP API Security risks, AI data handling, supply-chain security and operational readiness.

## Closed in this hardening pass

- PostgreSQL CI no longer depends on Docker; it installs PostgreSQL 17 from PGDG on the Ubuntu runner and starts a native cluster.
- JWTs are size bounded, require explicit `typ: JWT`, pin RS256, verify signatures and validate issuer, audience, subject, UUID tenant, expiry and not-before.
- Generic writes are disabled by default and require an explicit entity allowlist plus entity-specific command handler.
- Authentication failures return 401, authorization failures 403, tenant mismatch 404, and unexpected internal failures 500 without stack details.
- AI upstreams require HTTPS and an explicit origin allowlist.
- AI Responses requests send `store: false`, use strict JSON Schema, enforce timeout/budgets and keep credentials out of request bodies.
- Request bodies are limited to 1 MiB and malformed JSON fails closed.
- PostgreSQL adversarial tests cover all tenant tables, missing/malformed context, cross-tenant select/insert/update/delete and `NOBYPASSRLS`.

## Critical release blockers

1. **Runtime gates have not passed.** npm install, lint, typecheck, unit/contract tests, build, native PostgreSQL 17 integration, CodeQL, dependency review, SBOM and attestations require execution in CI.
2. **Write command handlers are not implemented.** POST is intentionally disabled by default. Production write APIs require entity-specific schemas, property authorization, idempotent transaction handling, audit events and replay tests.
3. **Distributed rate limiting and quotas are absent.** The 1 MiB body limit and AI budgets are insufficient for multi-instance abuse protection. Add tenant, principal, IP and expensive-operation limits backed by shared state.
4. **JWT key rotation/JWKS is absent.** Current verification supports a configured static RSA public key. Production requires trusted HTTPS JWKS retrieval, issuer-bound key sets, `kid` selection, cache expiry, rotation and outage policy without token-header-controlled origins.
5. **Refresh/session/revocation policy is absent.** Define token lifetime, replay controls, revocation response, step-up/MFA claims and service-account credential rotation.
6. **Object/property authorization is incomplete.** Scopes and RLS cover function and tenant boundaries, but domain, sensitivity and field-level response filtering are not yet enforced in controllers.
7. **OpenAPI conformance is shallow.** Current tests parse and inspect the contract, but do not validate requests/responses against schemas or detect breaking changes.
8. **AI governance is incomplete.** A tenant policy decision, regional/data-classification gate, moderation policy, schema runtime validator, cost ledger, provider failover policy and model evaluation suite remain required. `store: false` does not itself establish Zero Data Retention eligibility or remove abuse-monitoring retention.
9. **Secrets and deployment transport require environment proof.** Enforce TLS at the ingress, mTLS/private networking to PostgreSQL where applicable, managed-secret injection, egress restrictions and log redaction tests.
10. **Operational resilience is unproven.** Load/soak tests, backup/point-in-time restore, migration interruption, connection-pool exhaustion, AI/provider timeout, chaos, DR and incident exercises remain outstanding.

## High-priority non-blocking follow-up

- Add CORS allowlist and proxy trust configuration at the deployment adapter.
- Add response DTO allowlists to replace database-row serialization.
- Add security headers at the ingress and application layer.
- Add DAST, API fuzzing and property-based tests.
- Pin third-party GitHub Actions by immutable commit SHA under organization policy.
- Add privacy impact, retention and deletion workflows for AI provenance and evidence metadata.

## Release decision

**NO-GO for production.** Source hardening is improved, but critical runtime, write-path, distributed abuse-control, identity-rotation, fine-grained authorization and AI-governance evidence is incomplete.
