# Identity Outage Runbook

Contain: keep unknown tokens fail-closed, preserve cached verified keys only within configured lifetime, stop sensitive actions, and do not disable issuer/audience/signature checks. Triage discovery/JWKS reachability, issuer binding, key rotation and clock conditions. Recover with the last approved identity configuration or provider key overlap. Verify valid/invalid token corpus, memberships, authorization and audit before reopening. Record incident and regression evidence.
