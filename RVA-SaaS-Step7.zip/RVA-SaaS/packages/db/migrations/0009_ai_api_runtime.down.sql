DROP INDEX IF EXISTS public.ai_invocations_operations_idx;
DROP TABLE IF EXISTS public.ai_proposals;
DROP TRIGGER IF EXISTS ai_invocations_immutable ON public.ai_invocations;
DROP FUNCTION IF EXISTS public.prevent_ai_source_mutation();
DROP TABLE IF EXISTS public.ai_invocations;
ALTER TABLE public.api_idempotency_keys DROP CONSTRAINT IF EXISTS idempotency_response_pair, DROP CONSTRAINT IF EXISTS idempotency_hash_format, DROP COLUMN IF EXISTS response_body, DROP COLUMN IF EXISTS status_code, DROP COLUMN IF EXISTS route, DROP COLUMN IF EXISTS method;
DROP TYPE IF EXISTS public.ai_invocation_state;
