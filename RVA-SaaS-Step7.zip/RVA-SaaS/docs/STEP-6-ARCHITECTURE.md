# Step 6 Architecture: Application API and AI-assisted evidence

## Scope

Step 6 turns the governed database into a deployable application service:

- versioned REST controllers for resources, findings, cases, actions and ValueEvents;
- JWT authentication with pinned algorithms, issuer, audience, subject, expiry and tenant claims;
- transaction-local tenant context and policy authorization before every repository call;
- idempotency for writes and signed cursor pagination for reads;
- OpenAPI 3.1 contracts and conformance tests;
- an AI evidence-assistance boundary with structured outputs, redaction, prompt-injection resistance, budgets, audit metadata and mandatory human review;
- adversarial PostgreSQL 17 tenant-isolation tests covering every tenant-owned table and CRUD operation.

## AI authority boundary

AI may classify, extract, summarize and propose. AI output is evidence metadata, never an accepted fact, finding, approval, action or ValueEvent. Outputs require schema validation, provenance, model/configuration version, input hash and human confirmation. AI cannot call controlled-action connectors directly.

## Production boundaries

- No model credentials in clients or database configuration.
- No raw evidence is sent without tenant policy and redaction.
- Response schemas are strict and refusals are explicit.
- Requests are bounded by input bytes, output tokens, timeout and tenant budget.
- REST errors never expose cross-tenant existence.
- Breaking API changes require a new major path.
