# Step 1 acceptance: ontology and contracts

Step 1 establishes shared contracts only. It does not implement findings, cases, rules, actions, value events, connectors, or domain engines.

## Acceptance gates

1. Stable requirement IDs map ontology controls to code and tests.
2. Canonical resource identifiers are unique per tenant, never globally.
3. Every tenant-owned foreign key includes tenant ID.
4. Resource facts support effective-time and recorded-time reconstruction with supersession links.
5. Measurements use decimal-safe values, governed units, method, quality, uncertainty, evidence, actor, source and input hash.
6. Evidence metadata is tenant scoped and content-addressed.
7. Forced RLS applies to every tenant-owned ontology table.
8. The migration is reversible against the actual pre-migration baseline.

## Step 1 Governance Hardening Addendum

Required before Step 2:

- fact_definitions controlled vocabulary
- metric_definitions controlled vocabulary
- metric_allowed_units governance bridge
- non-overlapping temporal fact enforcement
- resource relationship hierarchy model
- immutable evidence triggers
- actor registry and actor foreign keys
