# Step 6 acceptance gates

- REST routes require JWT except health.
- JWT validation pins RS256 and validates signature, type, issuer, audience, subject, tenant, expiry and not-before.
- A tenant header cannot override the signed tenant claim.
- Authorization scopes are enforced before repository access.
- Writes require idempotency keys and entity-specific command handlers.
- PostgreSQL repository sets transaction-local tenant context and uses allowlisted table metadata.
- OpenAPI 3.1 describes every exposed collection, bearer security, uniform errors and idempotency.
- AI inputs are purpose allowlisted, bounded, redacted and treated as untrusted.
- AI requests require structured JSON schema outputs and stable pseudonymous safety identifiers.
- AI refusals and upstream errors fail closed; proposals always require human review.
- AI invocation provenance is immutable and tenant scoped.
- Restricted database role sees zero rows without context on every tenant table.
- Restricted role cannot read, insert, update or delete another tenant's rows, including guessed identifiers.
