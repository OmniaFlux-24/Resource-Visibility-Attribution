# CI Troubleshooting Guide

## Pipeline Fails During Validation

### validate_suite.py

Symptoms:
- Engineering package validation fails
- Missing runbooks
- Dashboard UID errors

Actions:
1. Review validator output.
2. Fix missing files or metadata.
3. Re-run validation locally.
4. Commit corrected artifacts.

---

### Prometheus Validation Failure

Symptoms:
- promtool check config fails
- promtool check rules fails

Actions:
1. Execute:

   promtool check config prometheus/prometheus.yml

2. Validate rule files:

   promtool check rules prometheus/rules/*.yml

3. Correct syntax or rule defects.

4. Run:

   promtool test rules prometheus/tests/rules.test.yml

---

### Grafana Validation Failure

Symptoms:
- Dashboard provisioning errors
- Duplicate dashboard UID
- Invalid datasource reference

Actions:
1. Validate dashboard JSON.
2. Ensure UID uniqueness.
3. Verify datasource UID alignment.
4. Re-import into staging Grafana.

---

### DR Validation Failure

Symptoms:
- RPO exceeded.
- RTO exceeded.
- Restore test failure.

Actions:
1. Preserve restore logs.
2. Identify bottleneck.
3. Re-run isolated recovery exercise.
4. Update DR remediation plan.

---

### Capacity Validation Failure

Symptoms:
- Forecast exceeds threshold.
- Critical utilisation reached.

Actions:
1. Review forecast assumptions.
2. Scale infrastructure.
3. Tune application performance.
4. Re-run load validation.

---

### Release Gate Failure

Symptoms:
- GO/NO-GO engine returns NO-GO.

Actions:
1. Review missing evidence.
2. Resolve failed gate.
3. Re-generate evidence.
4. Re-execute certification workflow.

NO failed mandatory gate may be manually overridden.
