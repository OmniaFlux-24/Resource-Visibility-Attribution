export class PostgresMembershipRepository{
 constructor(queryable){this.db=queryable;}
 async findActiveMembership({issuer,subject,tenantId,at}){const q=`
 SELECT m.tenant_id AS "tenantId",m.principal_id AS "principalId",m.membership_id AS "membershipId",
        p.active AS "principalActive",m.status AS "membershipStatus",m.allowed_domains AS "allowedDomains",
        m.max_sensitivity AS "maxSensitivity",m.allowed_purposes AS "allowedPurposes",
        COALESCE(array_agg(DISTINCT r.role_code) FILTER (WHERE r.role_code IS NOT NULL),'{}') AS roles,
        COALESCE(array_agg(DISTINCT rp.permission_code) FILTER (WHERE rp.effect='ALLOW'),'{}') AS "roleAllows",
        COALESCE(array_agg(DISTINCT rp.permission_code) FILTER (WHERE rp.effect='DENY'),'{}') AS "roleDenies",
        COALESCE(array_agg(DISTINCT mpo.permission_code) FILTER (WHERE mpo.effect='ALLOW'),'{}') AS "directAllows",
        COALESCE(array_agg(DISTINCT mpo.permission_code) FILTER (WHERE mpo.effect='DENY'),'{}') AS "directDenies"
 FROM rva.external_identities ei
 JOIN rva.principals p ON (p.tenant_id,p.principal_id)=(ei.tenant_id,ei.principal_id)
 JOIN rva.memberships m ON (m.tenant_id,m.principal_id)=(p.tenant_id,p.principal_id)
 LEFT JOIN rva.membership_roles mr ON (mr.tenant_id,mr.membership_id)=(m.tenant_id,m.membership_id)
 LEFT JOIN rva.roles r ON (r.tenant_id,r.role_id)=(mr.tenant_id,mr.role_id)
 LEFT JOIN rva.role_permissions rp ON (rp.tenant_id,rp.role_id)=(r.tenant_id,r.role_id)
 LEFT JOIN rva.membership_permission_overrides mpo ON (mpo.tenant_id,mpo.membership_id)=(m.tenant_id,m.membership_id)
 WHERE ei.tenant_id=$1 AND ei.issuer=$2 AND ei.subject=$3 AND p.active=true AND m.status='ACTIVE'
   AND m.valid_from<=$4::timestamptz AND (m.valid_to IS NULL OR m.valid_to>$4::timestamptz)
 GROUP BY m.tenant_id,m.principal_id,m.membership_id,p.active,m.status,m.allowed_domains,m.max_sensitivity,m.allowed_purposes`;
 const result=await this.db.query(q,[tenantId,issuer,subject,at]);const row=result.rows[0];if(!row)return null;
 const deny=new Set([...(row.roleDenies??[]),...(row.directDenies??[])]);row.permissions=[...(new Set([...(row.roleAllows??[]),...(row.directAllows??[])]))].filter(x=>!deny.has(x)).sort();return row;
 }
}
