export const resourceDomains = ['FINANCIAL','CONTRACTUAL','WORKFORCE','PHYSICAL','DIGITAL','ENERGY','COMMERCIAL','OPERATIONAL'] as const;
export type ResourceDomain = (typeof resourceDomains)[number];
export const measurementMethods = ['DIRECT','ESTIMATED','DERIVED'] as const;
export type MeasurementMethod = (typeof measurementMethods)[number];
export const dataQualities = ['VERIFIED','VALID','QUESTIONABLE','MISSING','CONTRADICTORY','STALE'] as const;
export type DataQuality = (typeof dataQualities)[number];
export interface AsKnownAt { readonly effectiveAt: string; readonly recordedAt: string; }
export interface ResourceIdentity { readonly tenantId: string; readonly resourceId: string; readonly canonicalUrn: string; readonly domain: ResourceDomain; readonly resourceType: string; }
export interface TypedMeasurement { readonly measurementId: string; readonly resourceId: string; readonly metricCode: string; readonly value: string; readonly unitCode: string; readonly method: MeasurementMethod; readonly quality: DataQuality; readonly uncertainty?: string; readonly effectiveAt: string; readonly recordedAt: string; }
export function isResourceDomain(value:string):value is ResourceDomain{return (resourceDomains as readonly string[]).includes(value);}
