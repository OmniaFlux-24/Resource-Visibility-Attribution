import { createHash } from 'node:crypto';
import type { Client } from 'pg';
export interface SchemaState { readonly tables:string[]; readonly functions:string[]; readonly policies:string[]; readonly extensions:string[]; }
const queries:Record<keyof SchemaState,string>={
 tables:`SELECT c.relkind::text || ' ' || c.relname AS line FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relkind IN ('r','p','v','m','S') ORDER BY 1`,
 functions:`SELECT p.proname || '(' || pg_get_function_identity_arguments(p.oid) || ')' AS line FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='public' ORDER BY 1`,
 policies:`SELECT tablename || ' ' || policyname || ' ' || cmd || ' ' || coalesce(qual,'') || ' ' || coalesce(with_check,'') AS line FROM pg_policies WHERE schemaname='public' ORDER BY 1`,
 extensions:`SELECT extname || ' ' || extversion AS line FROM pg_extension ORDER BY 1`
};
export async function readSchemaState(client:Client):Promise<SchemaState>{const state:Partial<Record<keyof SchemaState,string[]>>={}; for(const [key,sql] of Object.entries(queries) as [keyof SchemaState,string][]){const r=await client.query<Record<string,string>>(sql); state[key]=r.rows.map(row=>row['line']??'');} return state as SchemaState;}
export function fingerprintState(state:SchemaState):string{const lines=Object.entries(state).flatMap(([k,v])=>(v as string[]).map(x=>`${k}\t${x}`)).sort(); return createHash('sha256').update(lines.join('\n')).digest('hex');}
export async function schemaFingerprint(client:Client):Promise<{state:SchemaState;sha256:string}>{const state=await readSchemaState(client); return {state,sha256:fingerprintState(state)};}
