DROP INDEX IF EXISTS public.authorization_policy_lookup_idx;
DROP INDEX IF EXISTS public.api_idempotency_expiry_idx;
DROP TABLE IF EXISTS public.authorization_policies;
DROP TABLE IF EXISTS public.api_idempotency_keys;
DROP TABLE IF EXISTS public.api_versions;
DROP TYPE IF EXISTS public.api_version_state;
