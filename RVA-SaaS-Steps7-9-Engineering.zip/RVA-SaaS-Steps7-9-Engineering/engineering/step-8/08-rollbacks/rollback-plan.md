# Step 8 Rollback Plan

> Production baseline. Acceptance requires executed evidence from the target environment.

## Triggers

Contract break, command corruption/duplication, property leak, idempotency/audit fault, latency or migration failure.

## Application

Disable commands; deploy prior attested release; retain safe reads; restart workers after outbox reconciliation.

## Data

Prefer compensating command and forward migration; preserve audit/evidence; down migration requires compatibility proof and restore point.

## Verify

Contracts, replay, RLS, audit/outbox and domain invariants before writes reopen.
