# Step 4 acceptance gates

- Identity maps external issuer/subject to one tenant principal.
- Tenant context is validated and transaction-local.
- Role assignments support domain and sensitivity constraints.
- API credentials are hashed, scoped, expiring and revocable.
- Pagination cursors and webhook signatures reject tampering.
- Connector mode defaults to read-only; writes require allowlist and approval.
- Webhook delivery IDs prevent replay and record verified signatures.
- Ingestion supports scan, validation, normalization, commit, quarantine and failure.
- Worker jobs are tenant-scoped, leased, idempotent, bounded and dead-letterable.
- Audit events are immutable and hash-linked.
- All nine Step 4 tenant tables have composite keys, forced RLS and tenant indexes.
- CI quality, PostgreSQL 17, CodeQL, dependency review, SBOM, provenance and package gates pass.
