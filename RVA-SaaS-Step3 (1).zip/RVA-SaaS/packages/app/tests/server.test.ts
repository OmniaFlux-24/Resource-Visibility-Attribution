import { once } from 'node:events';
import type { AddressInfo } from 'node:net';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { createAppServer } from '../src/server.js';
describe('rva app host', () => {
  const server = createAppServer({ now: () => new Date('2026-10-13T00:00:00.000Z') });
  let baseUrl = '';
  beforeAll(async () => { server.listen(0,'127.0.0.1'); await once(server,'listening'); baseUrl = `http://127.0.0.1:${String((server.address() as AddressInfo).port)}`; });
  afterAll(async () => { server.close(); await once(server,'close'); });
  it('reports liveness over HTTP', async () => { const r=await fetch(`${baseUrl}/health`); expect(r.status).toBe(200); expect(r.headers.get('cache-control')).toBe('no-store'); expect(await r.json()).toEqual({status:'ok',service:'rva-app',version:'0.0.0',recordedAt:'2026-10-13T00:00:00.000Z'}); });
  it('returns JSON 404', async () => { const r=await fetch(`${baseUrl}/missing`); expect(r.status).toBe(404); });
});
