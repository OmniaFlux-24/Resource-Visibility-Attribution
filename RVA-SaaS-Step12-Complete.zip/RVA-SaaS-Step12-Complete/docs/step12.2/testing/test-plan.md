# Step 12.2 Test Plan

JWT/JWKS: valid token, bad signature, algorithm/type substitution, issuer/audience mismatch, expired/not-before, missing subject, unknown `kid`, refresh, cooldown, overlap, duplicate key, foreign origin, embedded key and oversized token.

Membership: active, suspended, not-yet-effective, expired, wrong tenant and inactive principal.

RBAC: each role's positive and negative permissions, direct deny precedence, tenant scope.

ABAC: domain allowlist, sensitivity ceiling, allowed purpose, ownership-required, high-impact step-up and missing attributes.

PostgreSQL: migration up/down/reapply, no-context default denial, cross-tenant role/membership assignments and application-role RLS behavior.
