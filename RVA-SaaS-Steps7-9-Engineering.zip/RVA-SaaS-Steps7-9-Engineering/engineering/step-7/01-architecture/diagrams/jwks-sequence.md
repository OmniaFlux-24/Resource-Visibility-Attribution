# JWKS Rotation Sequence

> Production baseline. Acceptance requires executed evidence from the target environment.

## Sequence

```mermaid
sequenceDiagram
 participant C as Client
 participant A as API
 participant K as JWKS Cache
 participant I as Trusted IdP
 C->>A: JWT kid=new
 A->>K: resolve new
 K-->>A: miss
 A->>K: refresh if cooldown allows
 K->>I: trusted discovery
 I-->>K: exact issuer plus jwks_uri
 K->>K: verify issuer HTTPS and allowed origin
 K->>I: fetch JWKS
 I-->>K: old and new keys
 K->>K: filter RSA RS256 sig and unique kid
 K-->>A: key
 A->>A: signature and claims
 A-->>C: continue or 401
```

## Failure

Issuer/origin mismatch, duplicate `kid`, unsupported key, token `jku`/`jwk`, refresh error or unknown key fails authentication.
