# Step 7 Threat Model

> Production baseline. Acceptance requires executed evidence from the target environment.

## Assets

Tenant data, signing trust, access policies, quota capacity, AI input/output, approvals and release evidence.

## Threats

Key substitution and SSRF; algorithm confusion; refresh flood; BOLA/BOPLA; quota race; prompt injection and data loss; governance/evidence tampering; privileged misuse.

## Controls

Trusted HTTPS issuer/origin; reject token key URLs; RS256/type pinning; cache cooldown and coalescing; RLS plus field policy; atomic counters; classification/redaction/schema/human review; immutable versions and hashes.

## Residual risks

IdP compromise, operator privilege abuse, provider contract breach and deployment misconfiguration require access review, monitoring, contractual controls and independent testing.
