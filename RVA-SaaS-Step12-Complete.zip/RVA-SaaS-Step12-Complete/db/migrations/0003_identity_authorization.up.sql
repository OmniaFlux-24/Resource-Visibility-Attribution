BEGIN;
CREATE TYPE rva.membership_status AS ENUM('INVITED','ACTIVE','SUSPENDED','REVOKED');
CREATE TABLE rva.external_identities(
 tenant_id uuid NOT NULL, external_identity_id uuid NOT NULL DEFAULT gen_random_uuid(), principal_id uuid NOT NULL,
 issuer text NOT NULL CHECK(issuer ~ '^https://[^/]+/?$'), subject text NOT NULL CHECK(length(subject) BETWEEN 1 AND 512),
 created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 PRIMARY KEY(tenant_id,external_identity_id), UNIQUE(tenant_id,issuer,subject),
 FOREIGN KEY(tenant_id,principal_id) REFERENCES rva.principals(tenant_id,principal_id)
);
CREATE TABLE rva.memberships(
 tenant_id uuid NOT NULL, membership_id uuid NOT NULL DEFAULT gen_random_uuid(), principal_id uuid NOT NULL,
 status rva.membership_status NOT NULL DEFAULT 'INVITED', valid_from timestamptz NOT NULL, valid_to timestamptz,
 allowed_domains text[] NOT NULL DEFAULT '{}', max_sensitivity integer NOT NULL DEFAULT 0 CHECK(max_sensitivity BETWEEN 0 AND 10),
 allowed_purposes text[] NOT NULL DEFAULT '{}', created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 PRIMARY KEY(tenant_id,membership_id), UNIQUE(tenant_id,principal_id),
 FOREIGN KEY(tenant_id,principal_id) REFERENCES rva.principals(tenant_id,principal_id), CHECK(valid_to IS NULL OR valid_to>valid_from)
);
CREATE TABLE rva.roles(tenant_id uuid NOT NULL,role_id uuid NOT NULL DEFAULT gen_random_uuid(),role_code text NOT NULL,description text NOT NULL,system_role boolean NOT NULL DEFAULT false,PRIMARY KEY(tenant_id,role_id),UNIQUE(tenant_id,role_code),FOREIGN KEY(tenant_id) REFERENCES rva.tenants(tenant_id));
CREATE TABLE rva.permissions(permission_code text PRIMARY KEY,description text NOT NULL,high_impact boolean NOT NULL DEFAULT false);
CREATE TABLE rva.role_permissions(tenant_id uuid NOT NULL,role_id uuid NOT NULL,permission_code text NOT NULL,effect text NOT NULL CHECK(effect IN('ALLOW','DENY')),PRIMARY KEY(tenant_id,role_id,permission_code),FOREIGN KEY(tenant_id,role_id) REFERENCES rva.roles(tenant_id,role_id),FOREIGN KEY(permission_code) REFERENCES rva.permissions(permission_code));
CREATE TABLE rva.membership_roles(tenant_id uuid NOT NULL,membership_id uuid NOT NULL,role_id uuid NOT NULL,PRIMARY KEY(tenant_id,membership_id,role_id),FOREIGN KEY(tenant_id,membership_id) REFERENCES rva.memberships(tenant_id,membership_id),FOREIGN KEY(tenant_id,role_id) REFERENCES rva.roles(tenant_id,role_id));
CREATE TABLE rva.membership_permission_overrides(tenant_id uuid NOT NULL,membership_id uuid NOT NULL,permission_code text NOT NULL,effect text NOT NULL CHECK(effect IN('ALLOW','DENY')),PRIMARY KEY(tenant_id,membership_id,permission_code),FOREIGN KEY(tenant_id,membership_id) REFERENCES rva.memberships(tenant_id,membership_id),FOREIGN KEY(permission_code) REFERENCES rva.permissions(permission_code));
CREATE TABLE rva.authorization_decisions(tenant_id uuid NOT NULL,decision_id uuid NOT NULL DEFAULT gen_random_uuid(),principal_id uuid NOT NULL,membership_id uuid NOT NULL,permission_code text NOT NULL,allowed boolean NOT NULL,reason_code text NOT NULL,resource_type text,resource_id uuid,domain text,sensitivity integer,purpose text,policy_version text NOT NULL,request_id text NOT NULL,recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),PRIMARY KEY(tenant_id,decision_id),FOREIGN KEY(tenant_id,principal_id) REFERENCES rva.principals(tenant_id,principal_id),FOREIGN KEY(tenant_id,membership_id) REFERENCES rva.memberships(tenant_id,membership_id),FOREIGN KEY(permission_code) REFERENCES rva.permissions(permission_code));

ALTER TABLE rva.external_identities ENABLE ROW LEVEL SECURITY; ALTER TABLE rva.external_identities FORCE ROW LEVEL SECURITY;
ALTER TABLE rva.memberships ENABLE ROW LEVEL SECURITY; ALTER TABLE rva.memberships FORCE ROW LEVEL SECURITY;
ALTER TABLE rva.roles ENABLE ROW LEVEL SECURITY; ALTER TABLE rva.roles FORCE ROW LEVEL SECURITY;
ALTER TABLE rva.role_permissions ENABLE ROW LEVEL SECURITY; ALTER TABLE rva.role_permissions FORCE ROW LEVEL SECURITY;
ALTER TABLE rva.membership_roles ENABLE ROW LEVEL SECURITY; ALTER TABLE rva.membership_roles FORCE ROW LEVEL SECURITY;
ALTER TABLE rva.membership_permission_overrides ENABLE ROW LEVEL SECURITY; ALTER TABLE rva.membership_permission_overrides FORCE ROW LEVEL SECURITY;
ALTER TABLE rva.authorization_decisions ENABLE ROW LEVEL SECURITY; ALTER TABLE rva.authorization_decisions FORCE ROW LEVEL SECURITY;
CREATE POLICY external_identity_tenant ON rva.external_identities USING(tenant_id=rva.current_tenant_id()) WITH CHECK(tenant_id=rva.current_tenant_id());
CREATE POLICY memberships_tenant ON rva.memberships USING(tenant_id=rva.current_tenant_id()) WITH CHECK(tenant_id=rva.current_tenant_id());
CREATE POLICY roles_tenant ON rva.roles USING(tenant_id=rva.current_tenant_id()) WITH CHECK(tenant_id=rva.current_tenant_id());
CREATE POLICY role_permissions_tenant ON rva.role_permissions USING(tenant_id=rva.current_tenant_id()) WITH CHECK(tenant_id=rva.current_tenant_id());
CREATE POLICY membership_roles_tenant ON rva.membership_roles USING(tenant_id=rva.current_tenant_id()) WITH CHECK(tenant_id=rva.current_tenant_id());
CREATE POLICY membership_overrides_tenant ON rva.membership_permission_overrides USING(tenant_id=rva.current_tenant_id()) WITH CHECK(tenant_id=rva.current_tenant_id());
CREATE POLICY auth_decisions_tenant ON rva.authorization_decisions USING(tenant_id=rva.current_tenant_id()) WITH CHECK(tenant_id=rva.current_tenant_id() AND principal_id=rva.current_principal_id());
CREATE TRIGGER authorization_decisions_append_only BEFORE UPDATE OR DELETE ON rva.authorization_decisions FOR EACH ROW EXECUTE FUNCTION rva.block_mutation();
CREATE INDEX memberships_active_idx ON rva.memberships(tenant_id,principal_id,status,valid_from);
CREATE INDEX identities_lookup_idx ON rva.external_identities(tenant_id,issuer,subject);
COMMIT;
