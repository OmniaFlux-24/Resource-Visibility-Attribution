#!/usr/bin/env bash
set -euo pipefail
compose="docker compose -f docker-compose.test.yml"
cleanup(){ $compose down --volumes --remove-orphans >/dev/null 2>&1 || true; }
trap cleanup EXIT INT TERM
cleanup
$compose up -d --wait postgres17
export RVA_DATABASE_URL="postgres://rva_admin:rva_test_only@127.0.0.1:55432/rva_test"
npm run migration:verify
npm run test:integration
$compose exec -T postgres17 pg_dump -U rva_admin -d rva_test --schema-only --no-owner --no-privileges > /tmp/rva-schema.sql
$compose exec -T postgres17 createdb -U rva_admin rva_restore
cat /tmp/rva-schema.sql | $compose exec -T postgres17 psql -v ON_ERROR_STOP=1 -U rva_admin -d rva_restore
$compose exec -T postgres17 dropdb -U rva_admin rva_restore
echo "PostgreSQL 17 migration, integration and schema restore harness PASSED"
