BEGIN;
DELETE FROM rva.permissions WHERE permission_code IN('tenant:read','tenant:admin','identity:read','identity:admin','resource:read','resource:write','measurement:read','measurement:write','finding:read','finding:triage','finding:validate','case:read','case:write','approval:read','approval:decide','action:preview','action:execute','value-event:read','value-event:verify','connector:read','connector:admin','evidence:read','evidence:write','audit:read','export:create');
COMMIT;
