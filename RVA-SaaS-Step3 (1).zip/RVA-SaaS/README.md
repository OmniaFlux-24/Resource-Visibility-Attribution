# RVA SaaS

Step 0 engineering foundation for the Resource Value Assurance platform.

## Current scope

- TypeScript/Node modular-monolith host
- PostgreSQL 17 reversible migration harness
- Tenant isolation primitives with forced RLS
- Baseline-aware migration reversibility verification
- Whole-run migration serialization
- CI quality and database gates

No domain engine is represented as complete.

## Commands

```bash
npm ci
npm run lint
npm run format:check
npm run typecheck
npm run test
npm run build
npm run migration:verify
```
