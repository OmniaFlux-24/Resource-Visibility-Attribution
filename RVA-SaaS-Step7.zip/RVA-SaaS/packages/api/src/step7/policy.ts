import type {Claims} from '../types.js';
export interface AccessPolicy{permission:string;domains?:readonly string[];maxSensitivity?:number;readFields:readonly string[];writeFields:readonly string[];}
export interface AccessContext{claims:Claims;permission:string;domain?:string;sensitivity?:number;}
export class FieldPolicy{
 authorize(context:AccessContext,policy:AccessPolicy):void{if(!context.claims.scopes.includes(context.permission)||policy.permission!==context.permission)throw new Error('Forbidden');if(context.domain!==undefined&&policy.domains!==undefined&&!policy.domains.includes(context.domain))throw new Error('Forbidden');if(context.sensitivity!==undefined&&policy.maxSensitivity!==undefined&&context.sensitivity>policy.maxSensitivity)throw new Error('Forbidden');}
 project(value:Record<string,unknown>,fields:readonly string[]):Record<string,unknown>{return Object.fromEntries(fields.filter(x=>Object.hasOwn(value,x)).map(x=>[x,value[x]]));}
 validateWrite(value:Record<string,unknown>,allowed:readonly string[]):void{const denied=Object.keys(value).filter(x=>!allowed.includes(x));if(denied.length>0)throw new Error(`Forbidden properties: ${denied.join(',')}`);}
}
