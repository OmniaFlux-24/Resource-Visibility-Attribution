CREATE TYPE public.baseline_kind AS ENUM ('CONTRACTUAL','PLANNED','REGULATORY','HISTORICAL','MODEL_ESTIMATED');
CREATE TYPE public.rule_outcome AS ENUM ('PASS','CANDIDATE','INSUFFICIENT_EVIDENCE','INVALID_INPUT','ERROR');
CREATE TYPE public.finding_state AS ENUM ('DETECTED','TRIAGED','INVESTIGATING','VALIDATED','FALSE_POSITIVE','INSUFFICIENT_EVIDENCE','DISPUTED','APPROVAL_PENDING','APPROVED','REJECTED','CANCELLED','ACTION_IN_PROGRESS','PARTIAL','OUTCOME_PENDING','FAILED','VERIFIED','UNVERIFIED','REOPENED','CLOSED');
CREATE TYPE public.finding_severity AS ENUM ('INFO','LOW','MEDIUM','HIGH','CRITICAL');

CREATE TABLE public.baseline_definitions (
  tenant_id uuid NOT NULL,
  baseline_id uuid NOT NULL DEFAULT gen_random_uuid(),
  baseline_code text NOT NULL,
  version integer NOT NULL,
  domain public.resource_domain NOT NULL,
  metric_code text NOT NULL REFERENCES public.metric_definitions(metric_code),
  kind public.baseline_kind NOT NULL,
  expected_value numeric(38,18),
  lower_bound numeric(38,18),
  upper_bound numeric(38,18),
  unit_code text NOT NULL REFERENCES public.units(unit_code),
  rationale text NOT NULL,
  source_reference text NOT NULL,
  effective_from timestamptz NOT NULL,
  effective_to timestamptz,
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  owner_actor_id uuid NOT NULL,
  input_hash char(64) NOT NULL,
  PRIMARY KEY (tenant_id, baseline_id),
  UNIQUE (tenant_id, baseline_code, version),
  FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id),
  FOREIGN KEY (tenant_id,owner_actor_id) REFERENCES public.actors(tenant_id,actor_id),
  CONSTRAINT baseline_version_positive CHECK (version > 0),
  CONSTRAINT baseline_range_order CHECK (lower_bound IS NULL OR upper_bound IS NULL OR lower_bound <= upper_bound),
  CONSTRAINT baseline_has_expectation CHECK (expected_value IS NOT NULL OR lower_bound IS NOT NULL OR upper_bound IS NOT NULL),
  CONSTRAINT baseline_effective_range CHECK (effective_to IS NULL OR effective_to > effective_from),
  CONSTRAINT baseline_hash_format CHECK (input_hash ~ '^[0-9a-f]{64}$')
);

CREATE TABLE public.rule_definitions (
  tenant_id uuid NOT NULL,
  rule_definition_id uuid NOT NULL DEFAULT gen_random_uuid(),
  rule_id text NOT NULL,
  version integer NOT NULL,
  domain public.resource_domain NOT NULL,
  display_name text NOT NULL,
  description text NOT NULL,
  effective_from timestamptz NOT NULL,
  effective_to timestamptz,
  required_inputs jsonb NOT NULL,
  output_schema jsonb NOT NULL,
  deterministic_expression jsonb NOT NULL,
  exceptions jsonb NOT NULL DEFAULT '[]'::jsonb,
  severity public.finding_severity NOT NULL,
  owner_actor_id uuid NOT NULL,
  definition_hash char(64) NOT NULL,
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (tenant_id, rule_definition_id),
  UNIQUE (tenant_id, rule_id, version),
  FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id),
  FOREIGN KEY (tenant_id,owner_actor_id) REFERENCES public.actors(tenant_id,actor_id),
  CONSTRAINT rule_version_positive CHECK (version > 0),
  CONSTRAINT rule_effective_range CHECK (effective_to IS NULL OR effective_to > effective_from),
  CONSTRAINT rule_hash_format CHECK (definition_hash ~ '^[0-9a-f]{64}$')
);

CREATE TABLE public.rule_evaluations (
  tenant_id uuid NOT NULL,
  evaluation_id uuid NOT NULL DEFAULT gen_random_uuid(),
  resource_id uuid NOT NULL,
  rule_definition_id uuid NOT NULL,
  baseline_id uuid,
  outcome public.rule_outcome NOT NULL,
  observed_measurement_id uuid,
  observed_value numeric(38,18),
  expected_value numeric(38,18),
  delta_value numeric(38,18),
  unit_code text REFERENCES public.units(unit_code),
  input_snapshot jsonb NOT NULL,
  input_hash char(64) NOT NULL,
  calculation_trace jsonb NOT NULL,
  evaluated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  effective_at timestamptz NOT NULL,
  evaluator_actor_id uuid NOT NULL,
  error_code text,
  PRIMARY KEY (tenant_id, evaluation_id),
  FOREIGN KEY (tenant_id,resource_id) REFERENCES public.resources(tenant_id,resource_id),
  FOREIGN KEY (tenant_id,rule_definition_id) REFERENCES public.rule_definitions(tenant_id,rule_definition_id),
  FOREIGN KEY (tenant_id,baseline_id) REFERENCES public.baseline_definitions(tenant_id,baseline_id),
  FOREIGN KEY (tenant_id,observed_measurement_id) REFERENCES public.measurements(tenant_id,measurement_id),
  FOREIGN KEY (tenant_id,evaluator_actor_id) REFERENCES public.actors(tenant_id,actor_id),
  CONSTRAINT evaluation_hash_format CHECK (input_hash ~ '^[0-9a-f]{64}$'),
  CONSTRAINT evaluation_error_consistency CHECK ((outcome='ERROR' AND error_code IS NOT NULL) OR (outcome<>'ERROR' AND error_code IS NULL))
);

CREATE TABLE public.findings (
  tenant_id uuid NOT NULL,
  finding_id uuid NOT NULL DEFAULT gen_random_uuid(),
  resource_id uuid NOT NULL,
  evaluation_id uuid NOT NULL,
  state public.finding_state NOT NULL DEFAULT 'DETECTED',
  severity public.finding_severity NOT NULL,
  title text NOT NULL,
  summary text NOT NULL,
  observed_value numeric(38,18),
  expected_value numeric(38,18),
  delta_value numeric(38,18),
  unit_code text REFERENCES public.units(unit_code),
  potential_exposure numeric(38,18),
  validated_discrepancy numeric(38,18),
  approved_recovery numeric(38,18),
  prevented_recurrence numeric(38,18),
  assigned_actor_id uuid,
  created_by_actor_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  closed_at timestamptz,
  PRIMARY KEY (tenant_id, finding_id),
  UNIQUE (tenant_id, evaluation_id),
  FOREIGN KEY (tenant_id,resource_id) REFERENCES public.resources(tenant_id,resource_id),
  FOREIGN KEY (tenant_id,evaluation_id) REFERENCES public.rule_evaluations(tenant_id,evaluation_id),
  FOREIGN KEY (tenant_id,assigned_actor_id) REFERENCES public.actors(tenant_id,actor_id),
  FOREIGN KEY (tenant_id,created_by_actor_id) REFERENCES public.actors(tenant_id,actor_id),
  CONSTRAINT finding_title_not_blank CHECK (length(btrim(title)) > 0),
  CONSTRAINT finding_closed_consistency CHECK ((state='CLOSED' AND closed_at IS NOT NULL) OR state<>'CLOSED')
);

CREATE TABLE public.finding_evidence (
  tenant_id uuid NOT NULL,
  finding_id uuid NOT NULL,
  evidence_id uuid NOT NULL,
  evidence_role text NOT NULL,
  added_by_actor_id uuid NOT NULL,
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (tenant_id,finding_id,evidence_id,evidence_role),
  FOREIGN KEY (tenant_id,finding_id) REFERENCES public.findings(tenant_id,finding_id),
  FOREIGN KEY (tenant_id,evidence_id) REFERENCES public.evidence_objects(tenant_id,evidence_id),
  FOREIGN KEY (tenant_id,added_by_actor_id) REFERENCES public.actors(tenant_id,actor_id)
);

CREATE TABLE public.finding_state_transitions (
  tenant_id uuid NOT NULL,
  transition_id uuid NOT NULL DEFAULT gen_random_uuid(),
  finding_id uuid NOT NULL,
  from_state public.finding_state NOT NULL,
  to_state public.finding_state NOT NULL,
  reason text NOT NULL,
  actor_id uuid NOT NULL,
  policy_version text NOT NULL,
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (tenant_id,transition_id),
  FOREIGN KEY (tenant_id,finding_id) REFERENCES public.findings(tenant_id,finding_id),
  FOREIGN KEY (tenant_id,actor_id) REFERENCES public.actors(tenant_id,actor_id),
  CONSTRAINT transition_changes_state CHECK (from_state <> to_state),
  CONSTRAINT transition_reason_not_blank CHECK (length(btrim(reason)) > 0)
);

CREATE TABLE public.allowed_finding_transitions (
  from_state public.finding_state NOT NULL,
  to_state public.finding_state NOT NULL,
  requires_reason boolean NOT NULL DEFAULT true,
  PRIMARY KEY (from_state,to_state)
);
INSERT INTO public.allowed_finding_transitions(from_state,to_state) VALUES
('DETECTED','TRIAGED'),('TRIAGED','INVESTIGATING'),
('INVESTIGATING','VALIDATED'),('INVESTIGATING','FALSE_POSITIVE'),('INVESTIGATING','INSUFFICIENT_EVIDENCE'),('INVESTIGATING','DISPUTED'),
('VALIDATED','APPROVAL_PENDING'),('DISPUTED','INVESTIGATING'),
('APPROVAL_PENDING','APPROVED'),('APPROVAL_PENDING','REJECTED'),('APPROVAL_PENDING','CANCELLED'),
('APPROVED','ACTION_IN_PROGRESS'),
('ACTION_IN_PROGRESS','PARTIAL'),('ACTION_IN_PROGRESS','OUTCOME_PENDING'),('ACTION_IN_PROGRESS','FAILED'),
('PARTIAL','OUTCOME_PENDING'),('OUTCOME_PENDING','VERIFIED'),('OUTCOME_PENDING','UNVERIFIED'),
('FAILED','REOPENED'),('UNVERIFIED','REOPENED'),('VERIFIED','CLOSED'),('FALSE_POSITIVE','CLOSED'),('INSUFFICIENT_EVIDENCE','CLOSED'),('REJECTED','CLOSED'),('CANCELLED','CLOSED'),
('REOPENED','INVESTIGATING'),('CLOSED','REOPENED');

CREATE FUNCTION public.guard_finding_state_transition() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.state = OLD.state THEN RETURN NEW; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.allowed_finding_transitions t WHERE t.from_state=OLD.state AND t.to_state=NEW.state) THEN
    RAISE EXCEPTION 'Invalid finding transition: % -> %', OLD.state, NEW.state;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM public.finding_state_transitions h
    WHERE h.tenant_id=OLD.tenant_id AND h.finding_id=OLD.finding_id
      AND h.from_state=OLD.state AND h.to_state=NEW.state
      AND h.recorded_at >= transaction_timestamp()
  ) THEN RAISE EXCEPTION 'Record transition history before changing finding state'; END IF;
  IF NEW.state='CLOSED' AND NEW.closed_at IS NULL THEN NEW.closed_at=clock_timestamp(); END IF;
  IF NEW.state<>'CLOSED' THEN NEW.closed_at=NULL; END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER findings_guard_state BEFORE UPDATE OF state ON public.findings
FOR EACH ROW EXECUTE FUNCTION public.guard_finding_state_transition();

CREATE FUNCTION public.prevent_assurance_record_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'Assurance evaluation and transition records are immutable'; END; $$;
CREATE TRIGGER evaluations_immutable BEFORE UPDATE OR DELETE ON public.rule_evaluations FOR EACH ROW EXECUTE FUNCTION public.prevent_assurance_record_mutation();
CREATE TRIGGER transitions_immutable BEFORE UPDATE OR DELETE ON public.finding_state_transitions FOR EACH ROW EXECUTE FUNCTION public.prevent_assurance_record_mutation();

ALTER TABLE public.baseline_definitions ENABLE ROW LEVEL SECURITY; ALTER TABLE public.baseline_definitions FORCE ROW LEVEL SECURITY;
ALTER TABLE public.rule_definitions ENABLE ROW LEVEL SECURITY; ALTER TABLE public.rule_definitions FORCE ROW LEVEL SECURITY;
ALTER TABLE public.rule_evaluations ENABLE ROW LEVEL SECURITY; ALTER TABLE public.rule_evaluations FORCE ROW LEVEL SECURITY;
ALTER TABLE public.findings ENABLE ROW LEVEL SECURITY; ALTER TABLE public.findings FORCE ROW LEVEL SECURITY;
ALTER TABLE public.finding_evidence ENABLE ROW LEVEL SECURITY; ALTER TABLE public.finding_evidence FORCE ROW LEVEL SECURITY;
ALTER TABLE public.finding_state_transitions ENABLE ROW LEVEL SECURITY; ALTER TABLE public.finding_state_transitions FORCE ROW LEVEL SECURITY;
CREATE POLICY baselines_tenant ON public.baseline_definitions USING (tenant_id=public.rva_current_tenant()) WITH CHECK (tenant_id=public.rva_current_tenant());
CREATE POLICY rules_tenant ON public.rule_definitions USING (tenant_id=public.rva_current_tenant()) WITH CHECK (tenant_id=public.rva_current_tenant());
CREATE POLICY evaluations_tenant ON public.rule_evaluations USING (tenant_id=public.rva_current_tenant()) WITH CHECK (tenant_id=public.rva_current_tenant());
CREATE POLICY findings_tenant ON public.findings USING (tenant_id=public.rva_current_tenant()) WITH CHECK (tenant_id=public.rva_current_tenant());
CREATE POLICY finding_evidence_tenant ON public.finding_evidence USING (tenant_id=public.rva_current_tenant()) WITH CHECK (tenant_id=public.rva_current_tenant());
CREATE POLICY finding_transitions_tenant ON public.finding_state_transitions USING (tenant_id=public.rva_current_tenant()) WITH CHECK (tenant_id=public.rva_current_tenant());

CREATE INDEX baselines_lookup_idx ON public.baseline_definitions(tenant_id,metric_code,effective_from);
CREATE INDEX rules_lookup_idx ON public.rule_definitions(tenant_id,domain,effective_from);
CREATE INDEX evaluations_resource_idx ON public.rule_evaluations(tenant_id,resource_id,evaluated_at DESC);
CREATE INDEX findings_work_queue_idx ON public.findings(tenant_id,state,severity,created_at);
CREATE INDEX finding_transitions_history_idx ON public.finding_state_transitions(tenant_id,finding_id,recorded_at);
