const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
export function requireTenantId(value:string|undefined):string{if(value===undefined||!UUID.test(value)) throw new Error('A valid tenant UUID is required'); return value.toLowerCase();}
export interface TransactionClient{query(sql:string,values?:readonly unknown[]):Promise<unknown>;}
export async function setTenantContext(client:TransactionClient,tenantId:string):Promise<void>{await client.query("SELECT set_config('rva.tenant_id',$1,true)",[requireTenantId(tenantId)]);}
