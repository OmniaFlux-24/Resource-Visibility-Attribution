import { createHash } from 'node:crypto';
import { readFile, readdir } from 'node:fs/promises';
import path from 'node:path';
export interface Migration { readonly version:string; readonly name:string; readonly upSql:string; readonly downSql:string; readonly upChecksum:string; readonly downChecksum:string; }
const pattern=/^(?<version>\d{4})_(?<name>[a-z0-9]+(?:_[a-z0-9]+)*)\.(?<direction>up|down)\.sql$/;
export const checksum=(sql:string):string=>createHash('sha256').update(sql,'utf8').digest('hex');
export async function discoverMigrations(dir:string):Promise<Migration[]> {
  const files=(await readdir(dir,{withFileTypes:true})).filter(e=>e.isFile()&&e.name.endsWith('.sql')).map(e=>e.name).sort();
  const parts=new Map<string,{name:string;up?:string;down?:string}>();
  for(const file of files){const match=pattern.exec(file); const g=match?.groups; if(g===undefined) throw new Error(`Unrecognised migration file ${file}`); const version=String(g['version']); const name=String(g['name']); const direction=String(g['direction']); const current=parts.get(version)??{name}; if(current.name!==name) throw new Error(`Migration version ${version} has multiple names`); if(direction==='up') current.up=path.join(dir,file); else current.down=path.join(dir,file); parts.set(version,current);}
  const result:Migration[]=[];
  for(const [version,p] of [...parts.entries()].sort()){if(p.up===undefined||p.down===undefined) throw new Error(`Migration ${version}_${p.name} requires up and down scripts`); const upSql=await readFile(p.up,'utf8'); const downSql=await readFile(p.down,'utf8'); result.push({version,name:p.name,upSql,downSql,upChecksum:checksum(upSql),downChecksum:checksum(downSql)});}
  return result;
}
