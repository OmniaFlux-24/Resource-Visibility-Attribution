#!/usr/bin/env bash
set -euo pipefail
for command in psql postgres initdb; do if ! command -v "$command" >/dev/null; then echo "BLOCKED: $command is not installed" >&2; exit 127; fi; done
echo 'PostgreSQL runtime available'
