# Step 9 Evidence Model

> Production baseline. Acceptance requires executed evidence from the target environment.

## Fields

Release/environment/gate, state, produced/expiry times, producer/workflow/commit, artifact/report paths and SHA-256 hashes, tool/version, summary, approver/waiver and immutable decision.

## States

PENDING, PASSED, FAILED, WAIVED, NOT_APPLICABLE. Required gates cannot be NOT_APPLICABLE unless the catalogue permits it. Non-waivable gates cannot be WAIVED.

## Retention

Retain certification bundle, SBOM, provenance, test and approval evidence under release/compliance policy. Evidence storage is write-protected and access audited.

## Privacy

Reports are sanitized and must not contain secrets, tokens, raw evidence, prompts or unrestricted customer data.
