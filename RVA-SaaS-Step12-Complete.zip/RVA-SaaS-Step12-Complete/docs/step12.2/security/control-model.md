# Identity Security Model

- Start from a configured HTTPS issuer and require exact discovery issuer binding.
- Allowlist JWKS origins; reject token `jku`, embedded `jwk` and unsupported algorithms.
- Match `kid`, refresh once under cooldown, de-duplicate concurrent refresh and reject unknown keys.
- Validate signature, issuer, audience, subject, expiry and not-before with bounded clock skew.
- Distinguish access-token use from ID-token login use. Nonce belongs to the login transaction and is not fabricated by the API.
- Map `(issuer, subject)` to a local principal. Resolve an active, effective-dated tenant membership before authorization.
- RBAC grants candidate permissions; ABAC restricts by domain, sensitivity, purpose, ownership and step-up status.
- Deny by default and return stable reason codes without exposing other tenants.
