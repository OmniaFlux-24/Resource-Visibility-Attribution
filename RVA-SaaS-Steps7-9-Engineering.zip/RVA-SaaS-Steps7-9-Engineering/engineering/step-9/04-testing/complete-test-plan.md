# Step 9 Complete Test Plan

> Production baseline. Acceptance requires executed evidence from the target environment.

## Decision engine

All pass; one fail; missing; stale; bad hash; wrong release/environment; non-waivable waiver; expired waiver; dual approval; unknown gate; duplicate gate; malformed JSON.

## DAST

OpenAPI import; auth success; BOLA/BOPLA/mass assignment/rate/SSRF/injection; high/critical fail; target allowlist; scanner timeout and sanitized reports.

## Performance

Smoke/load/stress/soak profiles; SLO thresholds; error/latency; tenant isolation under load; quota behavior; connection saturation; recovery.

## Resilience

API restart, PostgreSQL connection interruption, JWKS outage/rotation, AI timeout, worker restart/outbox backlog. Verify no data loss, duplicate command or tenant leak.

## Backup

Logical schema/data restore plus base-backup manifest verification and test restore. Backup verifier does not replace restore testing.

## Exit

Every mandatory gate has current evidence; decision tests pass; active tests only in staging; rollback rehearsal passes; certification bundle hash recorded.
