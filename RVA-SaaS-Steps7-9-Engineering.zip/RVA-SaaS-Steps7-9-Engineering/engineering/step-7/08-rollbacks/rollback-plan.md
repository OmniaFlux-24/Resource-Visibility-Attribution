# Step 7 Rollback Plan

> Production baseline. Acceptance requires executed evidence from the target environment.

## Triggers

Authentication outage, invalid trust, authorization regression, quota fault, AI bypass, migration fault or tenant anomaly.

## Application

Redeploy last attested artifact; restore prior immutable policy versions; disable AI and writes; keep emergency stop.

## Database

Prefer forward correction. Down migration only with compatibility proof and restore point. Preserve audit/evidence.

## Verify

Health, old/new JWT, RLS, quota separation, audit continuity and reconciliation.
