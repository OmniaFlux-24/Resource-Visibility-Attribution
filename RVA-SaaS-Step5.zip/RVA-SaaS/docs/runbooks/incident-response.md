# Incident response baseline

1. Declare incident severity and incident commander.
2. Preserve request, correlation, actor, audit and external receipt evidence.
3. Use tenant/domain/connector emergency stop before disabling unrelated tenants.
4. Rotate affected credentials through the secret manager and revoke API credentials.
5. Reconcile every leased, executing or unknown-outcome action with authoritative external evidence.
6. Restore service from a tested release and verify tenant isolation before reopening writes.
7. Record timeline, impact, containment, recovery, root cause and preventive actions.
