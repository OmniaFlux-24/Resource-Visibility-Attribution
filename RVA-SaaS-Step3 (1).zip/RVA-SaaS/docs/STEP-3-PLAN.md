# Step 3 plan: Resolution, controlled execution and verified value

## Objective

Convert validated findings into governed cases, exact-payload approvals, durable external actions, authoritative outcome reconciliation and append-only verified value without granting AI or workers independent authority.

## Production scope

1. Cases aggregate findings without owning their economic value.
2. Approval grants bind actor, operation, target, payload hash, impact limit, policy version and expiry.
3. Actions are created read-only by default and require a valid approval grant before execution eligibility.
4. Durable outbox rows support leased workers, retries, idempotency and dead-letter handling.
5. Attempt and receipt records distinguish accepted requests from verified external outcomes.
6. Emergency stops operate by tenant, domain and connector.
7. ValueEvents remain append-only and independent from findings.
8. Explicit allocations prevent cross-domain double counting and permit partial overlap.

## Release blockers

Step 3 is not production-ready until live PostgreSQL tests prove tenant isolation, approval expiry, payload binding, idempotency, worker concurrency, unknown outcomes, append-only value, allocation limits, rollback and restore.
