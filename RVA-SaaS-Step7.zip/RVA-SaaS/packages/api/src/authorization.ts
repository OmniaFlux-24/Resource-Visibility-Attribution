import type {Authorizer,Claims} from './types.js';
export class ScopeAuthorizer implements Authorizer{authorize(claims:Claims,permission:string):void{if(!claims.scopes.includes(permission))throw new Error('Forbidden');}}
