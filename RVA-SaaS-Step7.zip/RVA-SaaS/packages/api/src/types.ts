export interface Claims{readonly subject:string;readonly tenantId:string;readonly scopes:readonly string[];readonly issuer:string;readonly audience:string;}
export interface ApiRequest{readonly method:string;readonly path:string;readonly headers:Readonly<Record<string,string|undefined>>;readonly body?:unknown;readonly query?:Readonly<Record<string,string|undefined>>;}
export interface ApiResponse{readonly status:number;readonly headers:Readonly<Record<string,string>>;readonly body:unknown;}
export interface Repository{list(entity:string,tenantId:string,cursor?:string):Promise<{items:unknown[];nextCursor?:string}>;get(entity:string,tenantId:string,id:string):Promise<unknown|undefined>;create(entity:string,tenantId:string,input:unknown,claims:Claims):Promise<unknown>;}
export interface Authenticator{verify(token:string):Promise<Claims>;}
export interface Authorizer{authorize(claims:Claims,permission:string):void;}
