# Step 8 Complete Test Plan

> Production baseline. Acceptance requires executed evidence from the target environment.

## Commands

Happy path, validation, state, rollback, audit/outbox, context, property policy and errors.

## Idempotency

First, exact replay, hash mismatch, concurrent duplicate, crashes around commit, response retrieval and expiry.

## Contracts

Ingress/egress schemas, unknown fields, formats/enums/status/content type/headers, compatibility diff, client smoke and fuzz.

## Security

BOLA/BOPLA, mass assignment, scope/domain/sensitivity, injection, size/page, methods/content types, malformed JWT and cross-tenant IDs.

## Resilience

Pool saturation, deadlock/retry, restart mid-command, failover, outbox backlog, JWKS outage.

## Exit

No generic writes; all commands traced; zero leakage; approved contract diff; concurrency pass; no unresolved high/critical.
