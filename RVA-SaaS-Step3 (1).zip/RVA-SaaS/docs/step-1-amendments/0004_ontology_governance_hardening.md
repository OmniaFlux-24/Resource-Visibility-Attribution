# Step 1 Amendment Pack

Included amendments:

1. Fact Definitions Governance
2. Metric Definitions Governance
3. Non-overlapping Temporal Facts
4. Resource Relationships
5. Immutable Evidence Policy
6. Actor Registry

## Status

Approved for inclusion in Step 1 architecture baseline.

## Notes

Implement as migration 0004_ontology_governance_hardening.
Do not modify migration 0003 in place.
