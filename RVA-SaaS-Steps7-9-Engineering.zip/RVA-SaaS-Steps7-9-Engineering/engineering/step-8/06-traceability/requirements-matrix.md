# Step 8 Traceability

> Production baseline. Acceptance requires executed evidence from the target environment.

## Matrix

| Requirement | Design | Implementation | Tests | Evidence |
|---|---|---|---|---|
| RVA-CMD-001 | command architecture | bus/handlers | unit/integration | command report |
| RVA-API-001 | runtime contract | middleware | ingress/egress/diff | contract report |
| RVA-AUT-001 | DTO policy | projector | BOPLA/mass assignment | auth report |
| RVA-IDM-001 | idempotency | coordinator/DB | replay/concurrency | DB report |
| RVA-AUD-001 | audit/outbox | transaction | rollback/tamper | audit report |

## Rule

A write endpoint is incomplete without all five rows linked to code, negative tests, evidence and rollback.
