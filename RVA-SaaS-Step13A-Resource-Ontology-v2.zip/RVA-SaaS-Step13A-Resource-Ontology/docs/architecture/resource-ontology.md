# Phase 13A Resource Ontology

```mermaid
flowchart LR
 T[Tenant] --> R[Resource identity]
 R --> F[Resource facets]
 R --> M[Source mappings]
 R --> E[Resource events]
 E --> C[Corrections and supersession]
 F --> Q[As known at T about effective U]
 E --> Q
```

`Resource` is stable canonical identity. Lifecycle, condition, availability, custody and classification are separate facet families. Facts use effective and recorded ranges. Corrections append new events and point to the corrected event; authoritative records are never overwritten.
