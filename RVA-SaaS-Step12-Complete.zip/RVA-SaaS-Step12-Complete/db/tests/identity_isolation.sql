\set ON_ERROR_STOP 1
-- Assumes Step 12 and Step 12.2 migrations and two synthetic tenants/principals.
SET ROLE rva_app;
BEGIN;
SELECT set_config('rva.tenant_id','11111111-1111-4111-8111-111111111111',true),set_config('rva.principal_id','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',true);
INSERT INTO rva.memberships(tenant_id,membership_id,principal_id,status,valid_from,allowed_domains,max_sensitivity,allowed_purposes) VALUES('11111111-1111-4111-8111-111111111111','cccccccc-cccc-4ccc-8ccc-cccccccccccc','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','ACTIVE',clock_timestamp(),ARRAY['FINANCIAL'],2,ARRAY['ASSURANCE']);
DO $$ BEGIN IF (SELECT count(*) FROM rva.memberships)<>1 THEN RAISE EXCEPTION 'membership isolation failed'; END IF; END $$;
DO $$ BEGIN
 BEGIN INSERT INTO rva.memberships(tenant_id,principal_id,status,valid_from) VALUES('22222222-2222-4222-8222-222222222222','bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb','ACTIVE',clock_timestamp()); RAISE EXCEPTION 'cross-tenant insert succeeded'; EXCEPTION WHEN insufficient_privilege THEN NULL; END;
END $$;
ROLLBACK;
RESET ROLE;
