# JWKS Rotation and Revocation Runbook

> Production baseline. Acceptance requires executed evidence from the target environment.

## Planned

Publish new key with old; run overlap tests; switch signing; watch failures; retain old through token lifetime/skew; remove old; run renewal tests.

## Emergency

Disable affected issuer/config; revoke sessions; preserve `kid`/request evidence; rotate dependent secrets; verify compromise is rejected; restore after approval.

## Rollback

Republish last known-good overlap and prior immutable configuration. Never accept all keys or extend token lifetime to mask failure.
