import http from 'k6/http';import {check,sleep} from 'k6';
const base=__ENV.RVA_STAGING_URL;const token=__ENV.RVA_TEST_TOKEN;
if(!base||!token)throw new Error('RVA_STAGING_URL and RVA_TEST_TOKEN required');
export const options={scenarios:{smoke:{executor:'constant-vus',vus:Number(__ENV.K6_VUS??10),duration:__ENV.K6_DURATION??'2m'}},thresholds:{http_req_failed:['rate<0.01'],http_req_duration:['p(95)<500','p(99)<1000'],checks:['rate>0.99']}};
export default function(){const r=http.get(`${base}/api/v1/resources`,{headers:{Authorization:`Bearer ${token}`,'X-Request-Id':`k6-${__VU}-${__ITER}`},tags:{operation:'list-resources'}});check(r,{'status 200':x=>x.status===200,'tenant header absent':x=>!String(x.body).includes(__ENV.RVA_OTHER_TENANT_SENTINEL??'__NEVER__')});sleep(1);}
