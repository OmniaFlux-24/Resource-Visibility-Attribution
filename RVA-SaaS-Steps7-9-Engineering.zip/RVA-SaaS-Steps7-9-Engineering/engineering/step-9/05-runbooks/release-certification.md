# Release Certification Runbook

> Production baseline. Acceptance requires executed evidence from the target environment.

## Prepare

Freeze release candidate; identify commit/version/environment; run quality/security/database/supply-chain jobs; deploy to isolated staging; seed synthetic tenants.

## Validate

Run contract/fuzz/DAST, performance and resilience; execute backup/restore; collect approvals; sanitize reports; generate hashes.

## Decide

Run evidence validator; investigate every failed/missing/stale gate; apply only permitted time-limited waivers; obtain required approvals; record GO/NO-GO.

## Release

Deploy attested artifact only; verify provenance; canary; monitor auth/RLS/errors/latency/queues; stop on rollback threshold.

## Close

Archive bundle and decision; record actual deployment digest; schedule post-release review.
