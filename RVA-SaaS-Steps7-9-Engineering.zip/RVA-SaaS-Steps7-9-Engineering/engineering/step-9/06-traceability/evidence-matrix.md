# Step 9 Evidence Matrix

> Production baseline. Acceptance requires executed evidence from the target environment.

## Matrix

| Gate | Priority | Evidence | Non-waivable |
|---|---|---|---|
| quality | P0 | lint/typecheck/unit/build | yes |
| postgres17 | P0 | migration/RLS/restore | yes |
| tenant-isolation | P0 | adversarial report | yes |
| security-sast | P0 | CodeQL/SAST | yes for high/critical |
| dependency | P0 | dependency/license report | yes for critical |
| jwks-rotation | P0 | rotation suite | yes |
| api-contract | P0 | runtime/diff report | yes |
| sbom-provenance | P0 | SBOM + attestation | yes |
| dast | P1 | ZAP/fuzz report | yes for high/critical |
| performance | P1 | k6 thresholds | release policy |
| resilience | P1 | fault reports | release policy |
| ai-governance | P1 | approvals + evaluation | yes if AI enabled |
| rollback | P0 | rehearsal report | yes |
