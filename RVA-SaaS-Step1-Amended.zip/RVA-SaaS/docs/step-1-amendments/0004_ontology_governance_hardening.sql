-- Architecture-approved migration specification
-- Fact definitions
CREATE TABLE public.fact_definitions (...);
-- Metric definitions
CREATE TABLE public.metric_definitions (...);
CREATE TABLE public.metric_allowed_units (...);
-- Temporal overlap protection
CREATE EXTENSION IF NOT EXISTS btree_gist;
-- Resource relationships
CREATE TABLE public.resource_relationships (...);
-- Immutable evidence triggers
CREATE FUNCTION public.prevent_evidence_mutation();
-- Actor registry
CREATE TABLE public.actors (...);
