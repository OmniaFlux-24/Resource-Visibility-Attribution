import { createServer, type Server, type ServerResponse } from 'node:http';
export interface HealthReport { readonly status: 'ok'; readonly service: string; readonly version: string; readonly recordedAt: string; }
export interface AppServerOptions { readonly serviceName?: string; readonly version?: string; readonly now?: () => Date; }
export function createAppServer(options: AppServerOptions = {}): Server {
  const service = options.serviceName ?? 'rva-app';
  const version = options.version ?? '0.0.0';
  const now = options.now ?? (() => new Date());
  return createServer((request, response) => {
    const path = new URL(request.url ?? '/', 'http://localhost').pathname;
    if (request.method === 'GET' && path === '/health') {
      sendJson(response, 200, { status: 'ok', service, version, recordedAt: now().toISOString() } satisfies HealthReport);
      return;
    }
    sendJson(response, 404, { error: 'not_found', method: request.method ?? 'GET', path });
  });
}
function sendJson(response: ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body);
  response.writeHead(status, {'content-type':'application/json; charset=utf-8','content-length':Buffer.byteLength(payload),'x-content-type-options':'nosniff','cache-control':'no-store'});
  response.end(payload);
}
