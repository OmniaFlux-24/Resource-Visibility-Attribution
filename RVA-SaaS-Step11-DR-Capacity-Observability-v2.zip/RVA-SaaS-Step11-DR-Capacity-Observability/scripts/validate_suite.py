#!/usr/bin/env python3
import json,re,sys,yaml
from pathlib import Path
root=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parents[1]).resolve();errors=[]
def fail(x): errors.append(x)
for p in root.rglob('*.json'):
 try: json.loads(p.read_text())
 except Exception as e: fail(f'Invalid JSON {p}: {e}')
for p in root.rglob('*.y*ml'):
 try: yaml.safe_load(p.read_text())
 except Exception as e: fail(f'Invalid YAML {p}: {e}')
# engineering completeness
for d in ('01-architecture','02-security','03-observability','04-dr','05-capacity','06-testing','07-runbooks','08-traceability','09-release','10-rollbacks'):
 p=root/'engineering/step-11'/d
 if not p.exists() or not list(p.rglob('*.md')): fail(f'Missing engineering section {d}')
# alert coverage
alerts=yaml.safe_load((root/'prometheus/rules/rva-alerts.yml').read_text())
runbooks={p.stem for p in (root/'engineering/step-11/07-runbooks').glob('*.md')}
for group in alerts.get('groups',[]):
 for rule in group.get('rules',[]):
  if 'alert' not in rule: continue
  labels=rule.get('labels',{}); ann=rule.get('annotations',{})
  for key in ('severity','service','team'):
   if not labels.get(key): fail(f"Alert {rule['alert']} missing label {key}")
  for key in ('summary','description','runbook_url'):
   if not ann.get(key): fail(f"Alert {rule['alert']} missing annotation {key}")
  rb=ann.get('runbook_url','').rstrip('/').split('/')[-1]
  if rb and rb not in runbooks: fail(f"Alert {rule['alert']} references missing runbook {rb}")
# prohibited labels/query content
for p in list((root/'prometheus').rglob('*.yml'))+list((root/'grafana/dashboards').glob('*.json')):
 text=p.read_text().lower()
 for token in ('tenant_id','user_id','email','request_id','raw_uri'):
  if re.search(r'by\s*\([^)]*\b'+re.escape(token)+r'\b',text): fail(f'High-cardinality label in {p}: {token}')
# grafana essentials
uids=set()
for p in (root/'grafana/dashboards').glob('*.json'):
 d=json.loads(p.read_text());
 if not d.get('uid') or not d.get('title') or not d.get('panels'): fail(f'Incomplete dashboard {p}')
 if d.get('uid') in uids: fail(f'Duplicate dashboard uid {d.get("uid")}')
 uids.add(d.get('uid'))
 for panel in d.get('panels',[]):
  if not panel.get('title') or not panel.get('targets'): fail(f'Incomplete panel in {p}')
# policy sanity
slo=json.loads((root/'slo-policy.json').read_text());cap=json.loads((root/'capacity-plan.json').read_text());dr=json.loads((root/'dr-policy.json').read_text())
if not 0<slo['availabilityObjective']<=1 or slo['latencyP95Ms']<=0: fail('Invalid SLO policy')
if not 0<cap['planningThresholdPercent']<cap['criticalThresholdPercent']<100: fail('Invalid capacity thresholds')
if dr['rpoMinutes']<=0 or dr['rtoMinutes']<=0 or not dr['nonWaivableChecks']: fail('Invalid DR policy')
if errors:
 print('\n'.join('ERROR: '+x for x in errors));sys.exit(1)
print(f'PASS: Step 11 suite valid; {len(uids)} dashboards; '+str(sum(len(g.get('rules',[])) for g in alerts.get('groups',[])))+' alerts')
