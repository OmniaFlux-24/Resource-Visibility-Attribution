# Step 7 acceptance gates

## Identity rotation

- Discovery starts from a configured HTTPS issuer and returned issuer matches exactly.
- JWKS origin is HTTPS and independently allowlisted.
- JWT header requires `alg=RS256`, `typ=JWT`, bounded `kid` and rejects embedded `jwk`/`jku`.
- Unknown `kid` triggers at most one refresh per cooldown; concurrent refreshes coalesce.
- Old and new keys work during overlap; removed keys fail after cache renewal.
- Duplicate kids, unsupported key type/use/algorithm, foreign origins and stale refresh failures fail closed.

## Authorization and quotas

- Scope, domain, sensitivity, read fields and write fields are enforced.
- Response projection excludes fields not explicitly allowed.
- Unknown write properties are rejected.
- Shared quota increments are atomic and tenant/principal/operation/window scoped.
- Request count, bytes, expensive operations, AI tokens and cost units use governed quota policies.

## AI governance

- All criteria in `AI-GOVERNANCE-ACCEPTANCE.md` pass.
- Active profiles require privacy and security approvals and remain human-reviewed.
- Evaluation data, thresholds and pass/fail result are immutable and versioned.
- Retention mode is explicit and never inferred from `store: false`.

## Release evidence

- P0 gates cannot be marked passed without artifact hash and evidence reference.
- CI quality, native PostgreSQL 17, isolation, restore, CodeQL, dependency review, SBOM and attestations pass.
