DROP POLICY IF EXISTS tenants_self_isolation ON public.tenants;
DROP TABLE IF EXISTS public.tenants;
DROP FUNCTION IF EXISTS public.rva_current_tenant();
