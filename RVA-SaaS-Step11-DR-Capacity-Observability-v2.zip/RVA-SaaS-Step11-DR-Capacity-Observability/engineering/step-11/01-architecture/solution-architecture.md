# Step 11 Solution Architecture

> Production engineering baseline. Runtime certification requires executed evidence from the target environment.

## Architecture

```mermaid
flowchart LR
 API[RVA API and Workers] --> M[Prometheus Metrics]
 PG[(PostgreSQL 17)] --> EX[Postgres Exporter]
 EX --> P[Prometheus]
 M --> P
 P --> AM[Alertmanager]
 P --> G[Grafana]
 AM --> ON[On-call Routing]
 G --> SRE[SRE Dashboards]
 B[Backup Service] --> V[Backup Verification]
 V --> DR[Restore Drill]
 DR --> EV[Certification Evidence]
 P --> EV
 G --> EV
 C[Capacity Tests] --> EV
 EV --> GO[Go No-Go Engine]
```

## Boundaries

Metrics must not contain tenant names, emails, tokens, evidence content or other high-cardinality customer values. Prometheus and Grafana sit on restricted management networks. Alert routing credentials are managed secrets.

## Availability

Monitoring is independently deployed from the application failure domain where practical. Alert evaluation, dashboard rendering and long-term evidence retention have separate health checks.

## Operations

Owners: SRE, Platform Engineering, Security Engineering, Database Engineering and the accountable service owner. Changes require review of architecture, security, test, rollback, traceability and operational impact. Production values for RTO, RPO, SLO and capacity require business approval.
