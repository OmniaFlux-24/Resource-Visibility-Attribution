# Step 8 Command and Contract Architecture

> Production baseline. Acceptance requires executed evidence from the target environment.

## Pipeline

OpenAPI request → authentication → property authorization → quota → idempotency → command → transaction/domain rules → audit/outbox → DTO projection → OpenAPI response.

## Architecture

```mermaid
flowchart LR
 H[HTTP]-->V[OpenAPI Request]
 V-->P[AuthZ and Field Policy]
 P-->Q[Quota]
 Q-->I[Idempotency]
 I-->B[Command Bus]
 B-->CH[Entity Handler]
 CH-->DB[(PostgreSQL RLS Transaction)]
 CH-->E[Audit and Outbox]
 DB-->D[DTO Projection]
 D-->R[OpenAPI Response]
 R-->H
```

## Rules

One immutable typed command per capability; explicit tenant/actor/request context; no dynamic client table/field names; state guards; deterministic errors; business/audit/outbox/idempotency commit together.

## NFRs

Bounded input/time, no raw rows, backwards-compatible v1, observable latency/failure, safe retry and forward-compatible migrations.
