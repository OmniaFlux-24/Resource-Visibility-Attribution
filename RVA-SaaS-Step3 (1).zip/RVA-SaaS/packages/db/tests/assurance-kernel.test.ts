import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { describe,expect,it } from 'vitest';
import { defaultMigrationsDir } from '../src/config.js';
const sql=async(name:string):Promise<string>=>readFile(path.join(defaultMigrationsDir,name),'utf8');
describe('Step 2 assurance kernel contracts',()=>{
 it('implements all deterministic outcomes',async()=>{const s=await sql('0005_assurance_kernel.up.sql'); for(const v of ['PASS','CANDIDATE','INSUFFICIENT_EVIDENCE','INVALID_INPUT','ERROR']) expect(s).toContain(`'${v}'`);});
 it('keeps evaluation inputs and calculation provenance',async()=>{const s=await sql('0005_assurance_kernel.up.sql'); for(const v of ['input_snapshot jsonb','input_hash char(64)','calculation_trace jsonb','definition_hash char(64)']) expect(s).toContain(v);});
 it('separates finding value stages',async()=>{const s=await sql('0005_assurance_kernel.up.sql'); for(const v of ['potential_exposure','validated_discrepancy','approved_recovery','prevented_recurrence']) expect(s).toContain(v);});
 it('forces RLS on six tenant assurance tables',async()=>{const s=await sql('0005_assurance_kernel.up.sql'); expect((s.match(/FORCE ROW LEVEL SECURITY/g)??[])).toHaveLength(6);});
 it('guards and records workflow transitions',async()=>{const s=await sql('0005_assurance_kernel.up.sql'); expect(s).toContain('allowed_finding_transitions'); expect(s).toContain('guard_finding_state_transition'); expect(s).toContain('finding_state_transitions');});
});
