BEGIN;
DROP TABLE IF EXISTS rva.authorization_decisions,rva.membership_permission_overrides,rva.membership_roles,rva.role_permissions,rva.permissions,rva.roles,rva.memberships,rva.external_identities;
DROP TYPE IF EXISTS rva.membership_status;
COMMIT;
