# Step 11 Certification Gates

> Production engineering baseline. Runtime certification requires executed evidence from the target environment.

## Mandatory

Prometheus config/rules/tests, Grafana provisioning/dashboards, metric privacy/cardinality, end-to-end alerting, backup/restore/RPO/RTO, capacity headroom, observability security, rollback rehearsal.

## GO

All mandatory gates pass with current release/environment-bound hashes and approvals.

## NO-GO

Missing evidence, tenant leak, alert route failure, failed restore, missed approved RPO/RTO, negative capacity headroom, dashboard/rule validation failure or rollback failure.

## Waiver

Tenant isolation, restore integrity and known critical security issues are non-waivable.
