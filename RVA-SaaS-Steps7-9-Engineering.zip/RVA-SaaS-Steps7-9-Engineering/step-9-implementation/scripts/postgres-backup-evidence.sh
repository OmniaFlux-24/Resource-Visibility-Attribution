#!/usr/bin/env bash
set -euo pipefail
: "${RVA_DATABASE_URL:?required}"
out="${1:-evidence/database}"; mkdir -p "$out"
pg_dump "$RVA_DATABASE_URL" --format=custom --no-owner --no-acl --file="$out/release.dump"
createdb "${RVA_RESTORE_DATABASE:-rva_release_restore}"
pg_restore --exit-on-error --no-owner --no-acl --dbname="${RVA_RESTORE_DATABASE:-rva_release_restore}" "$out/release.dump"
psql --dbname="${RVA_RESTORE_DATABASE:-rva_release_restore}" --no-psqlrc --tuples-only --command="SELECT current_setting('server_version_num'), count(*) FROM public.schema_migrations" > "$out/restore-proof.txt"
dropdb "${RVA_RESTORE_DATABASE:-rva_release_restore}"
sha256sum "$out/release.dump" "$out/restore-proof.txt" > "$out/sha256.txt"
echo "Logical backup and restore evidence complete"
