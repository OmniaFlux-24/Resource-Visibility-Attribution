# Step 7 Release Gates

> Production baseline. Acceptance requires executed evidence from the target environment.

## P0

Quality, native PostgreSQL 17, isolation, migration/rollback/reapply, restore, JWT/JWKS rotation and security scans.

## P1

Property authorization, quotas, AI governance/evaluation, SBOM, provenance and privacy/security approvals.

## Decision

Missing or failed P0 is NO-GO. Tenant isolation and critical vulnerability are non-waivable. Other waivers require owner, control, expiry and approval.
