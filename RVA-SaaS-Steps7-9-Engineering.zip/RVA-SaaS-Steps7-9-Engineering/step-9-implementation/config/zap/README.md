# ZAP staging scan safety

Active scans are allowed only against an isolated staging hostname explicitly approved in the deployment environment. Use synthetic tenants and least-privilege scanner credentials. The pipeline must reject production hosts. Sanitize reports before retention. ZAP's OpenAPI/API automation capability is used as a release signal, not a substitute for independent penetration testing.
