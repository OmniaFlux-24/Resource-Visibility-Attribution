#!/usr/bin/env bash
set -euo pipefail
command -v pg_isready >/dev/null || { echo 'PostgreSQL 17 client tools are required' >&2; exit 127; }
version="$(psql --version | awk '{print $3}')"
[[ "$version" == 17.* ]] || { echo "PostgreSQL 17 required, found $version" >&2; exit 1; }
export PGPASSWORD="${PGPASSWORD:-rva_test_only}"
export PGHOST="${PGHOST:-127.0.0.1}"
export PGPORT="${PGPORT:-5432}"
export PGUSER="${PGUSER:-rva_admin}"
export PGDATABASE="${PGDATABASE:-rva_test}"
export RVA_DATABASE_URL="postgres://${PGUSER}:${PGPASSWORD}@${PGHOST}:${PGPORT}/${PGDATABASE}"
for _ in {1..60}; do pg_isready -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d "$PGDATABASE" && break; sleep 1; done
pg_isready -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d "$PGDATABASE"
npm run migration:verify
npm run test:integration
pg_dump --schema-only --no-owner --no-privileges > schema.sql
createdb rva_restore
psql -v ON_ERROR_STOP=1 -d rva_restore < schema.sql
dropdb rva_restore
echo 'Native PostgreSQL 17 migration, isolation and restore harness PASSED'
