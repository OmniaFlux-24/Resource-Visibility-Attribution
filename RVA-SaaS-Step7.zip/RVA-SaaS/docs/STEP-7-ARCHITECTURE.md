# Step 7 Architecture: Identity Rotation, Policy Enforcement and AI Governance

## Purpose

Step 7 closes the highest-risk release gaps around key rotation, shared quotas, property authorization and governed AI use.

## Components

- Trusted OIDC discovery and JWKS cache with issuer/origin binding, bounded TTL, refresh cooldown, `kid` selection and controlled overlap.
- Policy decision layer combining scopes, domain, sensitivity, operation and permitted response/input fields.
- Shared quota ledger for request count, bytes, expensive operations, AI tokens and cost units.
- AI governance profiles containing tenant enablement, approved purposes/models, classifications, regions, retention mode, limits and mandatory review.
- AI evaluation records for quality, safety, refusal, injection resistance, schema conformity and regression thresholds.
- Release evidence registry for machine-verifiable gate outcomes.

## Non-authority rule

AI remains advisory. No profile, model output or evaluation can grant approval, execute a connector action, validate a finding or post a ValueEvent.
