# Phase 13A Acceptance Plan

- Migration up/down/reapply on PostgreSQL 17.
- Application role remains `NOSUPERUSER NOBYPASSRLS` and non-owner.
- No-context and malformed-context default denial.
- Cross-tenant resource, facet, mapping and event CRUD rejection.
- Resource event update/delete rejection.
- Bitemporal queries for as-recorded-at T and effective-at U.
- Correction/supersession lineage and source-hash verification.
- Independent facet coexistence, schema-version validation and invalid temporal range rejection.
- Backup restore followed by all isolation and lineage checks.
