# Identity and Authorization Flow

```mermaid
sequenceDiagram
 participant C as Client
 participant A as API
 participant O as OIDC/JWKS Validator
 participant I as Trusted IdP
 participant M as Membership Resolver
 participant Z as RBAC and ABAC
 participant D as PostgreSQL FORCE RLS
 C->>A: bearer token plus tenant selector
 A->>O: verify token
 O->>I: discovery/JWKS on bounded cache miss
 I-->>O: metadata and keys
 O-->>A: issuer-subject principal identity
 A->>M: resolve active membership for selected tenant
 M-->>A: membership attributes and role codes
 A->>Z: permission, domain, sensitivity, purpose, ownership
 Z-->>A: allow or deny with reason code
 A->>D: transaction-local tenant/principal context
 D-->>A: tenant-scoped result
```

The stable external identity key is `(issuer, subject)`. Email and display name are attributes, not identifiers. Tenant selectors never grant access.
