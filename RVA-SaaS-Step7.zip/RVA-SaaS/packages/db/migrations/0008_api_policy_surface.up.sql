CREATE TYPE public.api_version_state AS ENUM ('DRAFT','ACTIVE','DEPRECATED','RETIRED');
CREATE TABLE public.api_versions (
 tenant_id uuid NOT NULL,
 api_version_id uuid NOT NULL DEFAULT gen_random_uuid(),
 version_code text NOT NULL,
 openapi_hash char(64) NOT NULL,
 state public.api_version_state NOT NULL,
 published_at timestamptz,
 PRIMARY KEY(tenant_id,api_version_id),
 UNIQUE(tenant_id,version_code), FOREIGN KEY(tenant_id) REFERENCES public.tenants(tenant_id),
 CONSTRAINT api_version_hash CHECK(openapi_hash ~ '^[0-9a-f]{64}$'), CONSTRAINT api_publish_state CHECK((state='DRAFT' AND published_at IS NULL) OR (state<>'DRAFT' AND published_at IS NOT NULL))
);
CREATE TABLE public.api_idempotency_keys (
 tenant_id uuid NOT NULL,
 idempotency_id uuid NOT NULL DEFAULT gen_random_uuid(),
 request_key text NOT NULL,
 request_hash char(64) NOT NULL,
 response_hash char(64),
 expires_at timestamptz NOT NULL,
 PRIMARY KEY(tenant_id,idempotency_id),
 UNIQUE(tenant_id,request_key), FOREIGN KEY(tenant_id) REFERENCES public.tenants(tenant_id),
 CONSTRAINT idempotency_expiry CHECK(expires_at>clock_timestamp()), CONSTRAINT idempotency_request_hash CHECK(request_hash ~ '^[0-9a-f]{64}$')
);
CREATE TABLE public.authorization_policies (
 tenant_id uuid NOT NULL,
 policy_id uuid NOT NULL DEFAULT gen_random_uuid(),
 policy_code text NOT NULL,
 policy_document jsonb NOT NULL,
 version integer NOT NULL,
 PRIMARY KEY(tenant_id,policy_id),
 UNIQUE(tenant_id,policy_code,version), FOREIGN KEY(tenant_id) REFERENCES public.tenants(tenant_id), CONSTRAINT policy_version_positive CHECK(version>0)
);
ALTER TABLE public.api_versions ENABLE ROW LEVEL SECURITY; ALTER TABLE public.api_versions FORCE ROW LEVEL SECURITY;
ALTER TABLE public.api_idempotency_keys ENABLE ROW LEVEL SECURITY; ALTER TABLE public.api_idempotency_keys FORCE ROW LEVEL SECURITY;
ALTER TABLE public.authorization_policies ENABLE ROW LEVEL SECURITY; ALTER TABLE public.authorization_policies FORCE ROW LEVEL SECURITY;
CREATE POLICY api_versions_tenant ON public.api_versions USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY api_keys_tenant ON public.api_idempotency_keys USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY auth_policy_tenant ON public.authorization_policies USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());

CREATE INDEX api_idempotency_expiry_idx ON public.api_idempotency_keys(tenant_id,expires_at);
CREATE INDEX authorization_policy_lookup_idx ON public.authorization_policies(tenant_id,policy_code,version DESC);
