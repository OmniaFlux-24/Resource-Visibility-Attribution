export const resourceDomains = ['FINANCIAL','CONTRACTUAL','WORKFORCE','PHYSICAL','DIGITAL','ENERGY','COMMERCIAL','OPERATIONAL'] as const;
export type ResourceDomain = (typeof resourceDomains)[number];
export const measurementMethods = ['DIRECT','ESTIMATED','DERIVED'] as const;
export type MeasurementMethod = (typeof measurementMethods)[number];
export const dataQualities = ['VERIFIED','VALID','QUESTIONABLE','MISSING','CONTRADICTORY','STALE'] as const;
export type DataQuality = (typeof dataQualities)[number];
export interface AsKnownAt { readonly effectiveAt: string; readonly recordedAt: string; }
export interface ResourceIdentity { readonly tenantId: string; readonly resourceId: string; readonly canonicalUrn: string; readonly domain: ResourceDomain; readonly resourceType: string; }
export interface TypedMeasurement { readonly measurementId: string; readonly resourceId: string; readonly metricCode: string; readonly value: string; readonly unitCode: string; readonly method: MeasurementMethod; readonly quality: DataQuality; readonly uncertainty?: string; readonly effectiveAt: string; readonly recordedAt: string; }
export function isResourceDomain(value:string):value is ResourceDomain{return (resourceDomains as readonly string[]).includes(value);}
export const ruleOutcomes = ['PASS','CANDIDATE','INSUFFICIENT_EVIDENCE','INVALID_INPUT','ERROR'] as const;
export type RuleOutcome = (typeof ruleOutcomes)[number];
export const findingStates = ['DETECTED','TRIAGED','INVESTIGATING','VALIDATED','FALSE_POSITIVE','INSUFFICIENT_EVIDENCE','DISPUTED','APPROVAL_PENDING','APPROVED','REJECTED','CANCELLED','ACTION_IN_PROGRESS','PARTIAL','OUTCOME_PENDING','FAILED','VERIFIED','UNVERIFIED','REOPENED','CLOSED'] as const;
export type FindingState = (typeof findingStates)[number];
export interface RuleEvaluationContract { readonly evaluationId:string; readonly ruleId:string; readonly ruleVersion:number; readonly outcome:RuleOutcome; readonly inputHash:string; readonly effectiveAt:string; readonly evaluatedAt:string; }
export interface FindingContract { readonly findingId:string; readonly resourceId:string; readonly evaluationId:string; readonly state:FindingState; readonly observedValue?:string; readonly expectedValue?:string; readonly deltaValue?:string; readonly unitCode?:string; }
export const actionStates = ['DRAFT','READY','LEASED','EXECUTING','OUTCOME_UNKNOWN','SUCCEEDED','FAILED','CANCELLED','RECONCILED'] as const;
export type ActionState = (typeof actionStates)[number];
export const valueClassifications = ['RECOVERED_CASH','REALIZED_BENEFIT','PREVENTED_LOSS','NON_FINANCIAL'] as const;
export type ValueClassification = (typeof valueClassifications)[number];
export interface ApprovalGrantContract { readonly approvalId:string; readonly targetReference:string; readonly operation:string; readonly payloadHash:string; readonly policyVersion:string; readonly expiresAt:string; readonly maximumImpact?:string; readonly impactUnitCode?:string; }
export interface ControlledActionContract { readonly actionId:string; readonly approvalId?:string; readonly connectorCode:string; readonly payloadHash:string; readonly idempotencyKey:string; readonly state:ActionState; readonly dryRun:boolean; }
export interface ValueEventContract { readonly valueEventId:string; readonly economicEventKey:string; readonly classification:ValueClassification; readonly amount:string; readonly unitCode:string; readonly effectiveAt:string; readonly evidenceId:string; }
