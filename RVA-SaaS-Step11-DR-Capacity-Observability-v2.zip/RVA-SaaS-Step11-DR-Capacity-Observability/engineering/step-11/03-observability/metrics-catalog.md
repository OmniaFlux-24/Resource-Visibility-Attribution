# Metrics Catalog

> Production engineering baseline. Runtime certification requires executed evidence from the target environment.

## HTTP

`rva_http_requests_total`, `rva_http_request_duration_seconds_bucket`, `rva_http_in_flight_requests` with bounded route templates.

## Identity

`rva_jwt_validation_failures_total`, `rva_jwks_refresh_total`, `rva_jwks_refresh_failures_total`.

## Authorization

`rva_authorization_denials_total`, `rva_property_rejections_total`, `rva_tenant_isolation_violations_total`.

## Commands

`rva_command_total`, `rva_command_duration_seconds_bucket`, `rva_idempotency_replays_total`, `rva_outbox_backlog`.

## AI

`rva_ai_requests_total`, failures, refusals, policy denials, input/output tokens and cost units. Do not label prompts, model output or tenant identifiers.

## Database

Exporter metrics for availability, connections, locks, deadlocks, replication lag and transaction rates. Query text must not appear in labels.
