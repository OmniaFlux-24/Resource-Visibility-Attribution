# Step 8 Threat Model

> Production baseline. Acceptance requires executed evidence from the target environment.

## Threats

Mass assignment, BOLA/BOPLA, command confusion, workflow bypass, replay/duplicates, response overexposure, injection, races, audit omission, exhaustion and contract drift.

## Controls

Strict unknown-field rejection; entity commands; field allowlists; forced RLS; state guards; idempotency hash; allowlisted SQL; transaction audit/outbox; quota/timeouts; DTO plus egress validation.

## Abuse tests

System-field write; modified replay; cross-tenant ID; unauthorized transition; concurrent duplicate; oversized page/body; raw-row secret. Each remains an automated negative test.
