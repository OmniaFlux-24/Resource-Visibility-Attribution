import { pathToFileURL } from 'node:url';
import { Client } from 'pg';
import { resolveDatabaseUrl } from './config.js';
import { Migrator } from './migrator.js';
import { schemaFingerprint } from './schema-state.js';
export async function verifyMigrations(databaseUrl=resolveDatabaseUrl()):Promise<boolean>{
 const migrator=new Migrator(databaseUrl); const client=new Client({connectionString:databaseUrl}); await client.connect();
 try{
  await migrator.downAll();
  const baseline=await schemaFingerprint(client);
  const applied=await migrator.up(); const forward=await schemaFingerprint(client);
  const reverted=await migrator.downAll(); const rollback=await schemaFingerprint(client);
  if(rollback.sha256!==baseline.sha256) throw new Error('Rollback did not restore the pre-migration baseline');
  const reapplied=await migrator.up(); const second=await schemaFingerprint(client);
  if(second.sha256!==forward.sha256) throw new Error('Re-apply did not reproduce the applied schema');
  if(applied.length!==reverted.length||applied.length!==reapplied.length) throw new Error('Migration counts differ');
  return true;
 } finally {await client.end();}
}
if(process.argv[1]!==undefined&&import.meta.url===pathToFileURL(process.argv[1]).href){try{await verifyMigrations(); process.stdout.write('RESULT: migration verification PASSED\n');}catch(error){process.stderr.write(`${error instanceof Error?error.message:String(error)}\n`);process.exitCode=1;}}
