# Step 0 acceptance

Step 0 is accepted only when:

- dependency installation is reproducible;
- lint, format, type checking, unit tests and build pass;
- PostgreSQL 17 integration tests pass;
- rollback restores the actual pre-migration baseline;
- re-apply reproduces the first applied schema;
- migration operations serialize before reading migration state;
- tenant RLS fails closed under a restricted application role;
- no domain feature is represented as complete.
