import {Pool,type PoolClient} from 'pg';import type {Claims,Repository} from './types.js';
const configs:Record<string,{table:string;id:string;order:string}>={resources:{table:'resources',id:'resource_id',order:'recorded_at'},findings:{table:'findings',id:'finding_id',order:'created_at'},cases:{table:'cases',id:'case_id',order:'created_at'},actions:{table:'actions',id:'action_id',order:'created_at'},'value-events':{table:'value_events',id:'value_event_id',order:'recorded_at'}};
export class PostgresRepository implements Repository{
 constructor(private readonly pool:Pool){}
 private async tenant<T>(tenantId:string,fn:(client:PoolClient)=>Promise<T>):Promise<T>{const c=await this.pool.connect();try{await c.query('BEGIN');await c.query("SELECT set_config('rva.tenant_id',$1,true)",[tenantId]);const result=await fn(c);await c.query('COMMIT');return result;}catch(error){await c.query('ROLLBACK');throw error;}finally{c.release();}}
 async list(entity:string,tenantId:string):Promise<{items:unknown[]}>{const cfg=configs[entity];if(cfg===undefined)throw new Error('Unsupported entity');return this.tenant(tenantId,async c=>({items:(await c.query(`SELECT * FROM public.${cfg.table} ORDER BY ${cfg.order} DESC,${cfg.id} DESC LIMIT 101`)).rows.slice(0,100)}));}
 async get(entity:string,tenantId:string,id:string):Promise<unknown|undefined>{const cfg=configs[entity];if(cfg===undefined)throw new Error('Unsupported entity');return this.tenant(tenantId,async c=>(await c.query(`SELECT * FROM public.${cfg.table} WHERE ${cfg.id}=$1`,[id])).rows[0]);}
 async create(_entity:string,_tenantId:string,_input:unknown,_claims:Claims):Promise<never>{throw new Error('Entity-specific command handler required');}
}
