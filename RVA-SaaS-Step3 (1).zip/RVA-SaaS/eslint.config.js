import js from '@eslint/js';
import prettier from 'eslint-config-prettier';
import tseslint from 'typescript-eslint';
export default tseslint.config(
  { ignores: ['**/node_modules/**','**/dist/**','**/coverage/**','packages/db/migrations/**','docs/**'] },
  js.configs.recommended,
  { files: ['**/*.ts'], extends: [...tseslint.configs.recommendedTypeChecked], languageOptions: { parserOptions: { projectService: true, tsconfigRootDir: import.meta.dirname } }, rules: { '@typescript-eslint/consistent-type-imports':'error','@typescript-eslint/no-floating-promises':'error','@typescript-eslint/require-await':'error','@typescript-eslint/no-non-null-assertion':'error' } },
  prettier,
);
