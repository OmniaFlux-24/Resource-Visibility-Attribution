import { readdir, readFile } from 'node:fs/promises';
import path from 'node:path';
const dir='packages/db/migrations';
const files=await readdir(dir); const ups=files.filter(x=>x.endsWith('.up.sql')).map(x=>x.slice(0,-7)); const downs=new Set(files.filter(x=>x.endsWith('.down.sql')).map(x=>x.slice(0,-9)));
for(const name of ups) if(!downs.has(name)) throw new Error(`Missing rollback for ${name}`);
for(const file of files.filter(x=>x.endsWith('.sql'))){const sql=await readFile(path.join(dir,file),'utf8'); if(sql.includes('(...)')||/\bTODO\b|\bunimplemented\b/i.test(sql)) throw new Error(`Placeholder in ${file}`);}
console.log(`Static production checks PASSED (${ups.length} migration pairs)`);
