# PostgreSQL 17 Acceptance Runbook

## Gate 1: Apply Migrations
Execute all Step 12 migrations in order and record output.

## Gate 2: RLS Validation
Verify application role remains NOSUPERUSER and NOBYPASSRLS.

## Gate 3: Tenant Isolation
Run tenant_isolation.sql and identity_isolation.sql.

## Gate 4: Rollback
Execute all down migrations in reverse order.

## Gate 5: Reapply
Reapply all migrations and verify idempotent seed behavior.

## Gate 6: Backup/Restore
Restore backup to clean PostgreSQL 17 instance and rerun isolation checks.

## Exit Criteria
All SQL gates pass and evidence is retained.
