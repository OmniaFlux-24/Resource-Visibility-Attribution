#!/usr/bin/env python3
import re,sys
from pathlib import Path
r=Path(sys.argv[1] if len(sys.argv)>1 else '.');up=(r/'db/migrations/0010_resource_ontology.up.sql').read_text();down=(r/'db/migrations/0010_resource_ontology.down.sql').read_text();e=[]
def need(x,m):
 if not x:e.append(m)
for t in ('resources','resource_source_mappings','resource_facets','resource_events'):
 need(f'CREATE TABLE rva.{t}' in up,'missing table '+t);need(f'ALTER TABLE rva.{t} ENABLE ROW LEVEL SECURITY' in up,'missing enable RLS '+t);need(f'ALTER TABLE rva.{t} FORCE ROW LEVEL SECURITY' in up,'missing force RLS '+t);need(re.search(rf'CREATE POLICY \w+ ON rva\.{t}',up),'missing policy '+t);need(f'DROP TABLE IF EXISTS rva.{t}' in down,'missing rollback '+t)
for x in ('PRIMARY KEY(tenant_id,resource_id)','FOREIGN KEY(tenant_id,resource_id)','GENERATED ALWAYS AS (tstzrange(recorded_at,NULL','resource_events_append_only','resource_facets_append_only','CREATE EXTENSION IF NOT EXISTS btree_gist','NOBYPASSRLS'):
 need(x in (up+''.join(p.read_text() for p in r.rglob('*.md'))),'missing control '+x)
need((r/'tickets/PHASE-13A-TICKETS.md').stat().st_size>5000,'tickets incomplete');need((r/'tickets/BITEMPORAL-QUERY-REPOSITORY-TICKETS.md').stat().st_size>3000,'query tickets incomplete');need((r/'runbooks/PHASE-13A-ROLLBACK-RUNBOOK.md').stat().st_size>1000,'rollback incomplete');need((r/'contracts/openapi.yaml').stat().st_size>10000,'OpenAPI incomplete');need((r/'scripts/run_postgres17_acceptance.sh').exists(),'native runner missing');need((r/'db/tests/phase13a_bitemporal.sql').exists(),'bitemporal native test missing');need((r/'src/repositories/resource-query-repository.mjs').stat().st_size>5000,'repository incomplete');need((r/'tests/openapi_contract_test.py').stat().st_size>2000,'contract tests incomplete');need((r/'.github/workflows/phase13a-ci.yml').stat().st_size>1000,'CI job incomplete')
if e:print('\n'.join('ERROR: '+x for x in e));sys.exit(1)
print('PASS: Phase 13A static gate; 4 tenant tables; bitemporal ranges; RLS and rollback present')
