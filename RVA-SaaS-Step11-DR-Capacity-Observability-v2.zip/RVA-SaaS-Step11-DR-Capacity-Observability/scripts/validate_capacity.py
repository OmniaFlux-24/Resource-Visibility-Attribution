#!/usr/bin/env python3
import json,sys
from pathlib import Path
plan=json.loads(Path(sys.argv[1]).read_text());ev=json.loads(Path(sys.argv[2]).read_text());errors=[]
for k in ('release','measuredAt','resources','forecasts','ownerApproval'):
 if k not in ev: errors.append('missing '+k)
if not errors:
 for name,v in ev['resources'].items():
  if not 0<=v<=100: errors.append(f'{name} invalid utilisation')
  elif v>=plan['criticalThresholdPercent']: errors.append(f'{name} at critical utilisation {v}%')
 for m in plan['forecastMonths']:
  x=ev['forecasts'].get(str(m))
  if x is None: errors.append(f'missing {m}-month forecast')
  elif x['peakUtilisationPercent']>=plan['criticalThresholdPercent']: errors.append(f'{m}-month forecast exceeds critical threshold')
 if not ev['ownerApproval']: errors.append('owner approval missing')
print('NO-GO: '+'; '.join(errors) if errors else 'PASS: capacity evidence meets policy');sys.exit(1 if errors else 0)
