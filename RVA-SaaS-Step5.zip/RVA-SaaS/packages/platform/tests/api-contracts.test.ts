import {describe,it,expect} from 'vitest';
import {validateApiVersion} from '../src/api-contracts.js';
describe('api contracts',()=>{
 it('accepts versioned APIs',()=>expect(()=>validateApiVersion('v1')).not.toThrow());
 it('rejects invalid versions',()=>expect(()=>validateApiVersion('latest')).toThrow());
});
