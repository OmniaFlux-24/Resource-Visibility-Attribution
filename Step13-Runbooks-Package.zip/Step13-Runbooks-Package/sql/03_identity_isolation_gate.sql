SET ROLE rva_app;
SELECT count(*) FROM rva.memberships;
RESET ROLE;
