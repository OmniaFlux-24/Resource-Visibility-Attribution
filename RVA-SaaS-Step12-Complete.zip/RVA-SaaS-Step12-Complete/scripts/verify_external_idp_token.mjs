import {OidcJwtValidator} from '../src/identity/jwt-validator.mjs';
const {RVA_OIDC_ISSUER:issuer,RVA_OIDC_AUDIENCE:audience,RVA_OIDC_TOKEN:token,RVA_OIDC_ALLOWED_JWKS_ORIGINS:origins}=process.env;
if(!issuer||!audience||!token)throw new Error('RVA_OIDC_ISSUER, RVA_OIDC_AUDIENCE and RVA_OIDC_TOKEN are required');
const validator=new OidcJwtValidator({issuer,audience,allowedJwksOrigins:origins?origins.split(','):[new URL(issuer).origin]});
const result=await validator.verify(token);console.log(JSON.stringify({verified:true,issuer:result.issuer,subjectHash:await crypto.subtle.digest('SHA-256',new TextEncoder().encode(result.subject)).then(x=>Buffer.from(x).toString('hex')),expiresAt:result.expiresAt}));
