# Step 2 acceptance gates

1. Step 1 hardening migration is executable and reversible.
2. Baselines and rules are versioned and effective-dated.
3. Evaluation outcomes support PASS, CANDIDATE, INSUFFICIENT_EVIDENCE, INVALID_INPUT and ERROR.
4. Evaluation inputs, hashes and calculation traces are immutable.
5. One evaluation can produce no more than one finding.
6. Findings preserve resource, evaluation, evidence and actor lineage.
7. Value stages remain separate and no realised value is stored on findings.
8. Finding transitions are allowlisted, reasoned, actor-attributed and immutable.
9. Every tenant-owned Step 2 table has composite tenant keys, forced RLS and tenant-leading indexes.
10. Apply, rollback and reapply reproduce their corresponding schema fingerprints.
