# Step 7 Complete Test Plan

> Production baseline. Acceptance requires executed evidence from the target environment.

## Identity

Valid key; old/new overlap; removal after TTL; unknown key refresh/cooldown; concurrent coalescing; issuer/origin mismatch; duplicate key; wrong type/use/algorithm; embedded key; claim/lifetime failures; timeout and malformed metadata.

## Authorization

Scope/domain/sensitivity; read projection; unknown writes; cross-tenant IDs; missing/malformed context; privileged bypass; response field snapshots.

## Quota

First/exact/over limit; concurrent consumers; tenant/principal/operation/window separation; overflow, rollback and cleanup.

## AI

Disabled default; approvals; purpose/model/classification/region drift; size/token/cost limits; schema; refusal/timeout/moderation; injection corpus; review and regression thresholds.

## Exit

All P0 pass, zero isolation failures, no unresolved high/critical risk, migrations/restore pass, evidence hashed and retained.
