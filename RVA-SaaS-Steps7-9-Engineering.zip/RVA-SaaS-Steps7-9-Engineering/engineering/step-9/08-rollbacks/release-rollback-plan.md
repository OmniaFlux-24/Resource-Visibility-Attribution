# Step 9 Release Rollback Plan

> Production baseline. Acceptance requires executed evidence from the target environment.

## Triggers

Canary SLO breach, authentication/authorization failure, tenant anomaly, corruption/duplicate action, security alert, queue runaway or incompatible schema.

## Prepare

Last attested artifact, backward-compatible DB plan, emergency stops, reconciler, communication tree, restore point and tested commands.

## Execute

Stop new writes/actions; route traffic to prior artifact; preserve evidence; reconcile unknown outcomes/outbox; forward-fix DB unless proven safe down migration; validate RLS/contracts/invariants; gradually reopen.

## Evidence

Timeline, trigger metrics, deployment digests, commands, database state, reconciliation, validation and approvals.
