# Step 9 Security Model

> Production baseline. Acceptance requires executed evidence from the target environment.

## Threats

Forged evidence, report substitution, reuse from another release/environment, expired waiver, CI compromise, scanner credential leakage, destructive scan against production, metric manipulation and approver collusion.

## Controls

OIDC-attested builds, SHA-256 manifests, release/environment binding, protected environments, least privilege, managed secrets, staging allowlist, evidence retention, branch protection, non-waivable gates and separation of duties.

## DAST safety

Active scan target must match configured staging allowlist and include explicit approval marker. Scanner account has least privilege and disposable test data. Production active target is rejected.

## Residual risk

Tool false negatives and compromised trusted infrastructure require independent penetration tests, manual review and monitoring.
