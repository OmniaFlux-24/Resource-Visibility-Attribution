#!/usr/bin/env python3
import json,re,sys
from pathlib import Path
r=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve();e=[]
def need(c,m):
 if not c:e.append(m)
ups=sorted((r/'db/migrations').glob('*.up.sql'));downs=sorted((r/'db/migrations').glob('*.down.sql'));sql='\n'.join(p.read_text() for p in ups)
need(len(ups)==4 and len(downs)==4,'expected four paired migrations')
need({p.name.replace('.up.sql','') for p in ups}=={p.name.replace('.down.sql','') for p in downs},'migration mismatch')
for t in ('principals','audit_events','evidence_objects','external_identities','memberships','roles','role_permissions','membership_roles','membership_permission_overrides','authorization_decisions'):
 need(f'ALTER TABLE rva.{t} ENABLE ROW LEVEL SECURITY' in sql,f'{t} enable RLS missing');need(f'ALTER TABLE rva.{t} FORCE ROW LEVEL SECURITY' in sql,f'{t} force RLS missing');need(re.search(rf'CREATE POLICY \w+ ON rva\.{t}',sql),f'{t} policy missing')
for f in ('src/identity/jwt-validator.mjs','src/identity/postgres-membership-repository.mjs','src/authorization/abac.mjs','src/authorization/postgres-decision-repository.mjs','src/http/authentication-middleware.mjs','src/http/protected-handler.mjs','docs/adrs/ADR-001-tenant-isolation.md','STEP-12-IMPLEMENTATION-BACKLOG.md','STEP-12-COMPLETION-MATRIX.md','FINAL-DEPLOYMENT-CHECKLIST.md'):
 need((r/f).exists() and (r/f).stat().st_size>200,'missing/incomplete '+f)
need('NOBYPASSRLS' in sql and 'NOSUPERUSER' in sql,'safe app role missing')
need('authorization_decisions_append_only' in sql and 'audit_append_only' in sql,'append-only controls missing')
for p in r.rglob('*.json'):
 try:json.loads(p.read_text())
 except Exception as x:e.append(f'invalid JSON {p}: {x}')
if e:print('\n'.join('ERROR: '+x for x in e));sys.exit(1)
print('PASS: integrated Step 12 static gate; 4 migration pairs; 10 FORCE-RLS tenant tables')
