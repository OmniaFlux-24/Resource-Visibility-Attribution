# Step 7 Data Model

> Production baseline. Acceptance requires executed evidence from the target environment.

## Tables

Identity-provider configurations; quota policies/counters; access-policy versions; AI-governance profiles/evaluations; release-gate evidence.

## Invariants

Composite tenant keys, forced RLS, immutable policy versions, HTTPS issuers, bounded cache/cooldown, positive quotas, enabled AI requires privacy/security approval and human review, passed gate requires hash/evidence reference.

## Retention

Expire counters after audit window; retain governance and evidence per compliance; keep raw prompts/results out of ordinary logs.

## Migration

Forward and down tested in staging. Prefer forward repair after data exists. Inspect DDL locks and preserve backup/restore evidence.
