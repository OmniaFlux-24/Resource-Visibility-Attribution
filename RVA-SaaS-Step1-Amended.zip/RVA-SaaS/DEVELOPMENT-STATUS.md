# Development status

## Step 0 implemented

- Modular-monolith TypeScript workspace
- HTTP host and liveness contract
- PostgreSQL reversible migration harness
- Whole-operation advisory locking
- Baseline-aware migration verification
- Tenant isolation root with forced RLS

## Step 1 implemented

- Stable ontology requirement register
- Shared TypeScript contracts for all eight domains
- Tenant-scoped canonical resources
- Content-addressed evidence metadata
- Temporal source mappings
- Bitemporal resource facts with supersession
- Parameterized effective-time and recorded-time reconstruction
- Governed, decimal-safe measurements and units
- Forced RLS on all tenant-owned ontology tables
- Reversible Step 1 migration and contract tests

## Explicitly not yet implemented

Findings, baselines, rule execution, cases, approvals, actions, ValueEvents, connectors, UI workspaces and domain engines remain outside Step 1.

## Verification status for this package

- JSON/package manifest parsing: passed
- Static tenant-key, RLS, temporal-function and rollback coverage checks: passed
- ZIP integrity: passed during packaging
- Dependency installation: incomplete because the environment timed out while accessing the package registry
- Typecheck, unit tests and build: not run because dependency installation did not complete
- Live PostgreSQL 17 migration and adversarial RLS tests: not run because no local PostgreSQL service was available

No unexecuted gate is represented as passing.
