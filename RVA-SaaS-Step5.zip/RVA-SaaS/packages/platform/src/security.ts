import { createHash, createHmac, timingSafeEqual } from 'node:crypto';
export function sha256Hex(value:string|Buffer):string{return createHash('sha256').update(value).digest('hex');}
export function canonicalJson(value:unknown):string{
 if(value===null||typeof value!=='object'){const encoded=JSON.stringify(value);if(encoded===undefined)throw new Error('Unsupported JSON value');return encoded;}
 if(Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
 const record=value as Record<string,unknown>; return `{${Object.keys(record).sort().map(k=>`${JSON.stringify(k)}:${canonicalJson(record[k])}`).join(',')}}`;
}
export function payloadHash(value:unknown):string{return sha256Hex(canonicalJson(value));}
export function signHmac(secret:string,message:string):string{return createHmac('sha256',secret).update(message).digest('hex');}
export function verifyHmac(secret:string,message:string,signature:string):boolean{
 if(!/^[0-9a-f]{64}$/i.test(signature)) return false; const expected=Buffer.from(signHmac(secret,message),'hex'); const supplied=Buffer.from(signature,'hex'); return expected.length===supplied.length&&timingSafeEqual(expected,supplied);
}
