# External Staging IdP Rotation Test

This runbook requires an approved staging issuer and two short-lived access tokens. Do not place tokens in files or command history.

1. Export `RVA_OIDC_ISSUER`, `RVA_OIDC_AUDIENCE`, `RVA_OIDC_ALLOWED_JWKS_ORIGINS` and secret-injected `RVA_OIDC_TOKEN` for a token signed by the current key.
2. Run `node scripts/verify_external_idp_token.mjs` and retain sanitized output.
3. Publish a new signing key alongside the old key using the IdP's approved rotation process.
4. Obtain a new token and verify it. Reverify the still-unexpired old token during the approved overlap.
5. After maximum token lifetime plus allowed clock skew, remove the old key. Verify a new token succeeds and the old-key token is rejected.
6. Test a temporary JWKS outage in a controlled staging window. Cached known keys may work only within cache policy; unknown keys must fail closed.
7. Retain discovery/JWKS request metadata, key IDs, timestamps and pass/fail evidence without retaining bearer tokens.

This package cannot execute this runbook without the actual issuer, tokens and authorised provider controls.
