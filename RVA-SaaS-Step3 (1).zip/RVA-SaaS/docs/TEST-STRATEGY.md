# Production test strategy

## Required on every step

- Manifest, formatting, lint, strict typecheck, unit tests and build.
- Clean PostgreSQL 17 apply, rollback and reapply fingerprint.
- Upgrade test from the previous packaged step.
- Restricted-role RLS tests for read, insert, update, delete and foreign-key inference.
- Concurrent transaction tests for unique events, allocation totals, leases and migration serialization.
- Invalid state transition and immutable-record mutation tests.
- Failure injection for timeout, retry, expired approval, emergency stop and unknown external outcome.
- Decimal boundary, negative, precision and unit compatibility tests.
- Restore drill in deployment environment before production release.
- SAST, dependency audit, secret scan, SBOM and signed artifact checks in release CI.

## Release rule

A packaged step may be source-complete while release-blocked. Production-ready requires all required automated checks to pass and operational evidence to be retained.
