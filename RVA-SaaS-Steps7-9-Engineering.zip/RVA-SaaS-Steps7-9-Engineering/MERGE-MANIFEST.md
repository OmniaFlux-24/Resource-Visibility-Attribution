# Merge Manifest

Copy `engineering/step-7`, `engineering/step-8`, `engineering/step-9` to the repository. Copy the content of `step-9-implementation` to matching repository paths after review. Supply managed secrets and isolated staging. Pin external actions/tool versions under organization policy.
