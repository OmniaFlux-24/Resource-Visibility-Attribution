# Step 12 Final Deployment Checklist

- [ ] Run all four migrations on native PostgreSQL 17.
- [ ] Assert `rva_app` is non-owner, `NOSUPERUSER` and `NOBYPASSRLS`.
- [ ] Run tenant and identity isolation SQL as the application role.
- [ ] Run down migrations in reverse order against a disposable database and reapply.
- [ ] Restore a database backup and rerun RLS assertions.
- [ ] Configure approved HTTPS issuer, audience and JWKS origins.
- [ ] Execute external old/new key overlap, retirement and outage runbook.
- [ ] Integrate middleware into the selected HTTP framework without logging bearer tokens.
- [ ] Persist authentication audit and authorization decisions transactionally.
- [ ] Configure step-up/MFA for high-impact permissions.
- [ ] Validate queue, cache, object storage and export tenant namespaces.
- [ ] Run SAST, dependency review, SBOM, DAST and independent tenant-isolation testing.
- [ ] Verify metrics, alerts, runbooks, backup/restore and rollback evidence.
- [ ] Obtain Security, Data, Platform and CTO release approval.
