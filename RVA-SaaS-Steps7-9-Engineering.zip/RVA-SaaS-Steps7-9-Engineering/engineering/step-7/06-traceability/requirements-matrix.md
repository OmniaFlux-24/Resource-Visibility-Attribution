# Step 7 Traceability

> Production baseline. Acceptance requires executed evidence from the target environment.

## Matrix

| Requirement | Design | Implementation | Tests | Evidence |
|---|---|---|---|---|
| RVA-IDN-002 | JWKS design | JWKS verifier | rotation suite | identity report |
| RVA-AUT-001 | field policy | policy evaluator | BOPLA suite | auth report |
| RVA-QTA-001 | atomic quotas | quota store | concurrency | PG report |
| RVA-AIG-001 | AI profiles | governance guard | governance/eval | approvals/evaluation |
| RVA-TEN-001 | tenant isolation | FORCE RLS | adversarial PG17 | isolation report |

## Rule

Requirement, design, code, negative tests, evidence and rollback impact change together.
