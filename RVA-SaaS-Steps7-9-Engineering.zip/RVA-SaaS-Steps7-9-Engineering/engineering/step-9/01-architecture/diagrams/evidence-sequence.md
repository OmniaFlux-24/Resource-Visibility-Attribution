# Release Evidence Sequence

> Production baseline. Acceptance requires executed evidence from the target environment.

## Sequence

```mermaid
sequenceDiagram
 participant W as CI Workflows
 participant C as Collector
 participant V as Validator
 participant D as Decision Engine
 participant A as Approvers
 participant R as Release Registry
 W->>C: reports and artifact digests
 C->>V: signed evidence manifest
 V->>V: schema/hash/release/environment/freshness
 V-->>D: normalized gate states
 D->>D: apply non-waivable and waiver policy
 D-->>A: proposed GO or NO-GO
 A->>D: independent approvals where required
 D->>R: immutable decision and evidence hashes
 D-->>W: release allowed or blocked
```
