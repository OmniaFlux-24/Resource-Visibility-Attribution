#!/usr/bin/env python3
import json,re,sys
from pathlib import Path
r=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve();e=[]
def need(c,m):
 if not c:e.append(m)
ups=sorted((r/'db/migrations').glob('*.up.sql'));downs=sorted((r/'db/migrations').glob('*.down.sql'));sql='\n'.join(p.read_text() for p in ups)
need({p.name.replace('.up.sql','') for p in ups}=={p.name.replace('.down.sql','') for p in downs},'migration pairs mismatch')
for t in ('external_identities','memberships','roles','role_permissions','membership_roles','membership_permission_overrides','authorization_decisions'):
 need(f'ALTER TABLE rva.{t} ENABLE ROW LEVEL SECURITY' in sql,f'{t} missing ENABLE RLS');need(f'ALTER TABLE rva.{t} FORCE ROW LEVEL SECURITY' in sql,f'{t} missing FORCE RLS');need(re.search(rf'CREATE POLICY \w+ ON rva\.{t}',sql),f'{t} missing policy')
for x in ('PRIMARY KEY(tenant_id','FOREIGN KEY(tenant_id,principal_id)','FOREIGN KEY(tenant_id,membership_id)','FOREIGN KEY(tenant_id,role_id)'):need(x in sql,'missing composite tenant control '+x)
need('authorization_decisions_append_only' in sql,'authorization decisions not append-only')
cat=(r/'src/authorization/catalog.mjs').read_text();abac=(r/'src/authorization/abac.mjs').read_text();jwt=(r/'src/identity/jwt-validator.mjs').read_text()
for role in ('PLATFORM_ADMIN','TENANT_ADMIN','INVESTIGATOR','APPROVER','VIEWER','CONNECTOR_OPERATOR'):need(role in cat,'missing role '+role)
for permission in ('approval:decide','action:execute','value-event:verify','identity:admin','connector:admin'):need(permission in abac,'high impact ABAC missing '+permission)
for marker in ("header.alg!=='RS256'","header.typ!=='at+jwt'",'header.jku!==undefined','payload.iss!==this.issuer','aud.includes(this.o.audience)','JWT expired','Duplicate JWKS kid','JWKS origin rejected'):need(marker in jwt,'JWT control missing '+marker)
for p in r.rglob('*.json'):
 try:json.loads(p.read_text())
 except Exception as x:e.append(f'invalid JSON {p}: {x}')
for f in ('src/http/authentication-middleware.mjs','EXTERNAL-IDP-ROTATION-RUNBOOK.md','POSTGRESQL-TEST-STATUS.md','docs/security/control-model.md','docs/testing/test-plan.md','docs/runbooks/identity-outage.md','docs/traceability/requirements.md','tests/jwt.test.mjs','tests/authorization.test.mjs'):
 need((r/f).exists() and (r/f).stat().st_size>300,'missing/incomplete '+f)
if e:print('\n'.join('ERROR: '+x for x in e));sys.exit(1)
print(f'PASS: Step 12.2 static validation; {len(ups)} migration pairs; 7 forced-RLS identity tables')
