CREATE TYPE public.api_version_state AS ENUM ('DRAFT','ACTIVE','DEPRECATED','RETIRED');
CREATE TABLE public.api_versions (
 tenant_id uuid NOT NULL,
 api_version_id uuid NOT NULL DEFAULT gen_random_uuid(),
 version_code text NOT NULL,
 openapi_hash char(64) NOT NULL,
 state public.api_version_state NOT NULL,
 published_at timestamptz,
 PRIMARY KEY(tenant_id,api_version_id),
 UNIQUE(tenant_id,version_code)
);
CREATE TABLE public.api_idempotency_keys (
 tenant_id uuid NOT NULL,
 idempotency_id uuid NOT NULL DEFAULT gen_random_uuid(),
 request_key text NOT NULL,
 request_hash char(64) NOT NULL,
 response_hash char(64),
 expires_at timestamptz NOT NULL,
 PRIMARY KEY(tenant_id,idempotency_id),
 UNIQUE(tenant_id,request_key)
);
CREATE TABLE public.authorization_policies (
 tenant_id uuid NOT NULL,
 policy_id uuid NOT NULL DEFAULT gen_random_uuid(),
 policy_code text NOT NULL,
 policy_document jsonb NOT NULL,
 version integer NOT NULL,
 PRIMARY KEY(tenant_id,policy_id),
 UNIQUE(tenant_id,policy_code,version)
);
ALTER TABLE public.api_versions ENABLE ROW LEVEL SECURITY; ALTER TABLE public.api_versions FORCE ROW LEVEL SECURITY;
ALTER TABLE public.api_idempotency_keys ENABLE ROW LEVEL SECURITY; ALTER TABLE public.api_idempotency_keys FORCE ROW LEVEL SECURITY;
ALTER TABLE public.authorization_policies ENABLE ROW LEVEL SECURITY; ALTER TABLE public.authorization_policies FORCE ROW LEVEL SECURITY;
CREATE POLICY api_versions_tenant ON public.api_versions USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY api_keys_tenant ON public.api_idempotency_keys USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
CREATE POLICY auth_policy_tenant ON public.authorization_policies USING(tenant_id=public.rva_current_tenant()) WITH CHECK(tenant_id=public.rva_current_tenant());
