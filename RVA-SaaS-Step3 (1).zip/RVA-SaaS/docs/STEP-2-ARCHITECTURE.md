# Step 2: Assurance Kernel

## Scope

Step 2 implements shared deterministic assurance contracts only:

- versioned baselines;
- versioned deterministic rule definitions;
- immutable reproducible evaluations;
- findings with complete measurement/value-stage separation;
- evidence associations;
- guarded workflow state history.

It does not implement cases, approvals, external actions, ValueEvents, AI extraction, connectors or domain-specific rules.

## Design controls included up front

- Every rule version has an effective period, owner, required inputs, output schema, deterministic expression, exceptions, severity and definition hash.
- Every evaluation stores exact input snapshot/hash, rule version reference, baseline reference, calculation trace, actor, effective time and evaluation time.
- Missing, invalid and failed evaluations are first-class outcomes and cannot silently become confirmed findings.
- An evaluation produces at most one finding.
- Findings separate potential exposure, validated discrepancy, approved recovery and prevented recurrence. Realised benefit remains outside findings and belongs to the future ValueEvent ledger.
- Evaluation and transition history are immutable.
- State changes require an approved transition plus transition-history evidence in the same transaction.
- All tenant-owned tables use composite keys, forced RLS and tenant-leading indexes.

## Pre-Step 3 recommendations already accounted for

- Case aggregation belongs in the next workflow layer, not inside findings.
- Approval authorisation must bind exact payload, policy version, limit and expiry.
- ValueEvents must remain independent from findings.
- Rules should be executed by an allowlisted interpreter, never dynamic SQL or arbitrary code from `deterministic_expression`.
- Rule JSON schemas require application-layer JSON Schema validation before persistence until database validation is deliberately introduced.
- Partitioning remains an ADR-triggered optimisation based on measured volume.
