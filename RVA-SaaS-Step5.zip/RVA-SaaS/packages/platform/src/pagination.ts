import { signHmac, verifyHmac } from './security.js';
export interface Cursor{readonly sortValue:string;readonly id:string;readonly version:1;}
export function encodeCursor(cursor:Cursor,secret:string):string{const body=Buffer.from(JSON.stringify(cursor)).toString('base64url');return `${body}.${signHmac(secret,body)}`;}
export function decodeCursor(token:string,secret:string):Cursor{const [body,signature,...rest]=token.split('.');if(body===undefined||signature===undefined||rest.length>0||!verifyHmac(secret,body,signature))throw new Error('Invalid cursor');const value=JSON.parse(Buffer.from(body,'base64url').toString('utf8')) as Cursor;if(value.version!==1||typeof value.id!=='string'||typeof value.sortValue!=='string')throw new Error('Invalid cursor payload');return value;}
