SET ROLE rva_app;
SELECT current_setting('rva.tenant_id', true);
-- Execute tenant isolation assertions here.
RESET ROLE;
