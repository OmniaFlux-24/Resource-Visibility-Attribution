# Step 12.2 Development Status

## Implemented and locally verified

- Tenant-scoped external identities keyed by issuer and subject.
- Effective-dated memberships with status, domains, sensitivity and purposes.
- Tenant-scoped roles, role permissions, membership roles and direct overrides.
- Append-only authorization decision records.
- Forced RLS on seven identity/authorization tables.
- Twenty-five named permissions and six baseline roles.
- Deny precedence for direct permission overrides.
- ABAC restrictions for domain, sensitivity, purpose, ownership, active membership and step-up.
- OIDC discovery issuer binding and JWKS origin allowlist.
- RS256 and `at+jwt` pinning, RSA signing-key filtering and duplicate `kid` rejection.
- Signature, issuer, audience, subject, expiry, not-before and issued-at checks.
- Rejection of token-controlled `jku`, `jwk` and `x5u` key sources.
- JWKS caching, overlap rotation, unknown-key refresh and refresh coalescing.
- Membership resolver contract.
- Static validator, CI template, PostgreSQL adversarial test and engineering documentation.

## Passed locally

- Nine identity and authorization unit/security tests.
- Static validation of migration pairs, composite keys, forced RLS, policies, append-only decisions, role catalogue, high-impact ABAC and JWT controls.

## Runtime evidence still required

- Merge and migration execution after the Step 12 base schema.
- Native PostgreSQL 17 up/down/reapply and RLS test.
- Live OIDC provider discovery, key rotation and outage test.
- Repository implementation for membership resolution.
- API middleware integration and audit-decision persistence.
- MFA/step-up provider integration, SAML and session lifecycle.
- Independent security review and penetration testing.

## Release decision

NO-GO until all P0 runtime integration evidence exists.
