#!/usr/bin/env python3
import json,sys
from datetime import datetime,timezone
from pathlib import Path
p=Path(sys.argv[1]);policy=json.loads(Path(sys.argv[2]).read_text());e=json.loads(p.read_text());errors=[]
for k in ('release','environment','backupCreatedAt','restoreStartedAt','restoreCompletedAt','checks','approvers'):
 if k not in e: errors.append('missing '+k)
def dt(x): return datetime.fromisoformat(x.replace('Z','+00:00'))
if not errors:
 rpo=(dt(e['restoreStartedAt'])-dt(e['backupCreatedAt'])).total_seconds()/60
 rto=(dt(e['restoreCompletedAt'])-dt(e['restoreStartedAt'])).total_seconds()/60
 if rpo>policy['rpoMinutes']: errors.append(f'RPO {rpo:.1f} exceeds {policy["rpoMinutes"]}')
 if rto>policy['rtoMinutes']: errors.append(f'RTO {rto:.1f} exceeds {policy["rtoMinutes"]}')
 for c in policy['nonWaivableChecks']:
  if e['checks'].get(c)!='PASSED': errors.append(f'check {c} not passed')
 if len(set(e['approvers']))<2: errors.append('two independent approvers required')
print('NO-GO: '+'; '.join(errors) if errors else 'PASS: DR evidence meets policy');sys.exit(1 if errors else 0)
