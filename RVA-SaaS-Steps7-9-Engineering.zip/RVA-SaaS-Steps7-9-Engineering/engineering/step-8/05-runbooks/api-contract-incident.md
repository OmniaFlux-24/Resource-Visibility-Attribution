# Command and Contract Incident Runbook

> Production baseline. Acceptance requires executed evidence from the target environment.

## Detect

Validation failures, 409/422/500 elevation, duplicate commands, audit/outbox mismatch, DTO leak or contract alert.

## Contain

Disable command, preserve safe reads, retain IDs/idempotency evidence, stop unknown-outcome replay.

## Recover

Deploy prior attested contract/handler; reconcile idempotency/domain/audit/outbox; replay only proven uncommitted; validate RLS and DTO projection.

## Close

Root cause, affected tenants, correction, version decision and regression test.
